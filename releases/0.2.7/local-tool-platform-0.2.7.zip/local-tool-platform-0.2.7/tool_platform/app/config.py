from __future__ import annotations

import json
from pathlib import Path


PLATFORM_VERSION = "0.2.7"
BASE_DIR = Path(__file__).resolve().parents[1]
WORKSPACE_DIR = BASE_DIR.parent
RUNTIME_DIR = BASE_DIR / "runtime"
LOG_DIR = RUNTIME_DIR / "logs"
DB_PATH = RUNTIME_DIR / "platform.db"
SETTINGS_PATH = RUNTIME_DIR / "settings.json"
TOOLS_DIR = BASE_DIR / "tools"
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"


DEFAULT_SETTINGS = {
    "server": {
        "manifest_url": "",
        "auto_check_updates": True,
        "last_update_check": {
            "checked_at": "",
            "ok": False,
            "has_update": False,
            "current_version": PLATFORM_VERSION,
            "latest_version": "",
            "download_url": "",
            "release_notes": "",
            "published_at": "",
            "tools_bundle_version": "",
            "minimum_supported_version": "",
            "error": "",
        },
    },
    "runtime": {
        "max_concurrent_jobs": 1,
        "default_output_strategy": "tool-default",
    },
    "automation": {
        "enabled": False,
        "watch_directories": [],
        "schedules": [],
    },
}


def ensure_runtime_dirs() -> None:
    for path in (RUNTIME_DIR, LOG_DIR):
        path.mkdir(parents=True, exist_ok=True)


def load_settings() -> dict:
    ensure_runtime_dirs()
    if not SETTINGS_PATH.exists():
        SETTINGS_PATH.write_text(json.dumps(DEFAULT_SETTINGS, ensure_ascii=False, indent=2), encoding="utf-8")
        return DEFAULT_SETTINGS.copy()
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        data = {}

    merged = json.loads(json.dumps(DEFAULT_SETTINGS, ensure_ascii=False))
    for key, value in data.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key].update(value)
        else:
            merged[key] = value
    return merged


def save_settings(data: dict) -> None:
    ensure_runtime_dirs()
    SETTINGS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
