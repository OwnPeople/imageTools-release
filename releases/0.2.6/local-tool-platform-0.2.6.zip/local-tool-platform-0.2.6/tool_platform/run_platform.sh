#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"
PYTHON_BIN="${PYTHON:-python3}"
NEEDS_SETUP_FLAG="$SCRIPT_DIR/runtime/.needs_setup"
OPEN_BROWSER="${OPEN_BROWSER:-0}"
PLATFORM_URL="${PLATFORM_URL:-http://127.0.0.1:8765}"

if [ -x "$SCRIPT_DIR/update_from_git.sh" ]; then
  "$SCRIPT_DIR/update_from_git.sh" || true
fi

if [ ! -x "$VENV_DIR/bin/python" ]; then
  echo "Virtualenv not found. Running bootstrap setup..."
  "$SCRIPT_DIR/bootstrap_setup.sh"
fi

if [ -f "$SCRIPT_DIR/update_from_http.py" ]; then
  "$VENV_DIR/bin/python" "$SCRIPT_DIR/update_from_http.py" || true
fi

if [ -f "$NEEDS_SETUP_FLAG" ]; then
  echo "Code was updated. Refreshing local environment..."
  "$SCRIPT_DIR/bootstrap_setup.sh"
  rm -f "$NEEDS_SETUP_FLAG"
fi

if [ "$OPEN_BROWSER" = "1" ]; then
  (
    sleep 2
    if command -v open >/dev/null 2>&1; then
      open "$PLATFORM_URL"
    elif command -v xdg-open >/dev/null 2>&1; then
      xdg-open "$PLATFORM_URL"
    fi
  ) &
fi

exec "$VENV_DIR/bin/python" -m uvicorn app.main:app --app-dir "$SCRIPT_DIR" --host 127.0.0.1 --port 8765
