from __future__ import annotations

import os
import platform
import subprocess
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog
from typing import Optional


def pick_directory(initial_dir: Optional[str] = None) -> str:
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    chosen = filedialog.askdirectory(initialdir=initial_dir or os.getcwd(), mustexist=True)
    root.destroy()
    return chosen


def open_path(path: Path) -> None:
    system = platform.system()
    if system == "Darwin":
        subprocess.Popen(["open", str(path)])
        return
    if system == "Windows":
        os.startfile(str(path))  # type: ignore[attr-defined]
        return
    subprocess.Popen(["xdg-open", str(path)])


def open_external(target: str) -> None:
    if target.startswith("http://") or target.startswith("https://"):
        webbrowser.open(target)
        return
    open_path(Path(target).expanduser().resolve())
