from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import TOOLS_DIR, WORKSPACE_DIR


def is_gf7_scene_dir(path: Path) -> bool:
    if not path.is_dir():
        return False
    pans = sorted(path.glob("*-BWDPAN.tiff"))
    muxes = sorted(path.glob("*-BWDMUX.tiff"))
    return len(pans) == 1 and len(muxes) == 1


def find_gf7_scenes(root: Path) -> List[Path]:
    if is_gf7_scene_dir(root):
        return [root]
    if not root.is_dir():
        return []
    return sorted(path for path in root.iterdir() if is_gf7_scene_dir(path))


TIFF_SUFFIXES = {".tif", ".tiff"}


def is_tiff_mosaic_dir(path: Path) -> bool:
    if not path.is_dir():
        return False
    tiff_count = sum(1 for item in path.iterdir() if item.is_file() and item.suffix.lower() in TIFF_SUFFIXES)
    return tiff_count >= 2


def find_tiff_mosaic_dirs(root: Path) -> List[Path]:
    if is_tiff_mosaic_dir(root):
        return [root]
    if not root.is_dir():
        return []
    return sorted(path for path in root.iterdir() if is_tiff_mosaic_dir(path))


@dataclass
class ToolDefinition:
    tool_id: str
    name: str
    description: str
    input_hint: str
    detector: str
    command: List[str]
    output_dir_name: str
    output_dir_template: str
    output_glob: str
    auto_batch_flag: str
    options: List[Dict[str, Any]]
    source_path: Path

    def _format_value(self, value: str, input_path: Path, output_path: Optional[Path] = None) -> str:
        return value.format(
            workspace_dir=str(WORKSPACE_DIR),
            input_path=str(input_path),
            input_name=input_path.name,
            input_parent=str(input_path.parent),
            output_path=str(output_path) if output_path else "",
        )

    def build_command(self, input_path: Path, options: Dict[str, Any], output_path: Optional[Path] = None) -> List[str]:
        output_path = output_path or self.resolve_output_dir(input_path)
        command = [
            self._format_value(item, input_path, output_path)
            for item in self.command
        ]
        if self.auto_batch_flag and self.needs_auto_batch(input_path):
            command.append(self.auto_batch_flag)
        for option in self.options:
            value = options.get(option["id"], option.get("default"))
            option_type = option.get("type", "boolean")
            cli_flag = option.get("cli_flag")
            if not cli_flag:
                continue
            if option_type == "boolean":
                if bool(value):
                    command.append(cli_flag)
            else:
                if value not in (None, ""):
                    command.extend([cli_flag, str(value)])
        return command

    def build_environment(self, options: Dict[str, Any]) -> Dict[str, str]:
        environment: Dict[str, str] = {}
        for option in self.options:
            env_var = option.get("env_var")
            if not env_var:
                continue
            value = options.get(option["id"], option.get("default"))
            option_type = option.get("type", "boolean")
            if option_type == "boolean":
                environment[env_var] = "1" if bool(value) else "0"
            elif value not in (None, ""):
                environment[env_var] = str(value)
        return environment

    def needs_auto_batch(self, input_path: Path) -> bool:
        if self.detector != "gf7_scene" or is_gf7_scene_dir(input_path):
            return False
        return bool(find_gf7_scenes(input_path))

    def supports_input(self, input_path: Path) -> bool:
        if self.detector == "gf7_scene":
            return is_gf7_scene_dir(input_path) or bool(find_gf7_scenes(input_path))
        if self.detector == "tiff_mosaic_dir":
            return is_tiff_mosaic_dir(input_path)
        return input_path.exists()

    def input_error_message(self) -> str:
        if self.detector == "gf7_scene":
            return "请选择 GF7 场景目录，或包含 GF7 场景子目录的父目录。场景目录需要同时包含 *-BWDPAN.tiff 和 *-BWDMUX.tiff。"
        if self.detector == "tiff_mosaic_dir":
            return "请选择包含至少两张 .tif/.tiff 文件的目录。"
        return "输入目录不符合当前工具要求。"

    def resolve_output_dir(self, input_path: Path) -> Path:
        if self.needs_auto_batch(input_path):
            return input_path
        if self.output_dir_template:
            return Path(self._format_value(self.output_dir_template, input_path))
        return input_path / self.output_dir_name


class ToolRegistry:
    def __init__(self, tools_dir: Path = TOOLS_DIR) -> None:
        self.tools_dir = tools_dir
        self._tools = self._load_tools()

    def _load_tools(self) -> Dict[str, ToolDefinition]:
        tools: Dict[str, ToolDefinition] = {}
        for path in sorted(self.tools_dir.glob("*/tool.json")):
            data = json.loads(path.read_text(encoding="utf-8"))
            tool = ToolDefinition(
                tool_id=data["id"],
                name=data["name"],
                description=data["description"],
                input_hint=data.get("input_hint", ""),
                detector=data.get("detector", ""),
                command=data["command"],
                output_dir_name=data.get("output_dir_name", ""),
                output_dir_template=data.get("output_dir_template", ""),
                output_glob=data.get("output_glob", ""),
                auto_batch_flag=data.get("auto_batch_flag", ""),
                options=data.get("options", []),
                source_path=path,
            )
            tools[tool.tool_id] = tool
        return tools

    def list_tools(self) -> List[ToolDefinition]:
        return list(self._tools.values())

    def get(self, tool_id: str) -> ToolDefinition:
        if tool_id not in self._tools:
            raise KeyError(f"Unknown tool: {tool_id}")
        return self._tools[tool_id]

    def scan_inputs(self, tool_id: str, root: Path) -> List[Path]:
        tool = self.get(tool_id)
        if tool.detector == "gf7_scene":
            return find_gf7_scenes(root)
        if tool.detector == "tiff_mosaic_dir":
            return find_tiff_mosaic_dirs(root)
        return []

    def validate_input(self, tool_id: str, input_path: Path) -> tuple[bool, str]:
        tool = self.get(tool_id)
        if not input_path.exists():
            return False, "Input path does not exist"
        if not tool.supports_input(input_path):
            return False, tool.input_error_message()
        return True, ""
