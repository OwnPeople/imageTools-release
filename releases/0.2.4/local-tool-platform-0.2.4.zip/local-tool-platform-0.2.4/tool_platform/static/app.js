const state = {
  tools: [],
  selectedToolId: null,
  scannedItems: [],
  selectedTaskId: null,
  gitUpdate: null,
};

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Request failed: ${response.status}`);
  }
  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }
  return response.text();
}

function selectedTool() {
  return state.tools.find((tool) => tool.id === state.selectedToolId) || null;
}

function getInputPath() {
  return document.getElementById("input-path").value.trim();
}

function renderInputHint() {
  const tool = selectedTool();
  document.getElementById("input-path").placeholder = tool?.input_hint || "/Users/.../输入目录";
}

function toolOptionValues() {
  const tool = selectedTool();
  const options = {};
  if (!tool) {
    return options;
  }
  for (const option of tool.options || []) {
    const element = document.getElementById(`option-${option.id}`);
    if (!element) {
      continue;
    }
    if (option.type === "boolean") {
      options[option.id] = element.checked;
    } else {
      options[option.id] = element.value;
    }
  }
  return options;
}

function renderTools() {
  const container = document.getElementById("tools-list");
  container.innerHTML = "";
  for (const tool of state.tools) {
    const card = document.createElement("div");
    card.className = `tool-card ${tool.id === state.selectedToolId ? "active" : ""}`;
    card.innerHTML = `
      <div class="task-card-top">
        <div>
          <strong>${tool.name}</strong>
          <p class="task-message">${tool.description}</p>
        </div>
        <button type="button" class="secondary">${tool.id === state.selectedToolId ? "已选择" : "选择"}</button>
      </div>
    `;
    card.querySelector("button").addEventListener("click", () => {
      state.selectedToolId = tool.id;
      renderTools();
      renderOptions();
      renderInputHint();
    });
    container.appendChild(card);
  }
}

function renderOptions() {
  const container = document.getElementById("options-block");
  const tool = selectedTool();
  container.innerHTML = "";
  if (!tool) {
    return;
  }
  renderInputHint();
  for (const option of tool.options || []) {
    if (option.type === "boolean") {
      const row = document.createElement("label");
      row.className = "checkbox-row";
      row.innerHTML = `
        <input id="option-${option.id}" type="checkbox" ${option.default ? "checked" : ""}>
        <span>${option.label}</span>
      `;
      container.appendChild(row);
      continue;
    }
    const field = document.createElement("label");
    field.className = "field";
    field.innerHTML = `
      <span>${option.label}</span>
      <input id="option-${option.id}" type="text" value="${option.default ?? ""}">
    `;
    container.appendChild(field);
  }
}

function renderScanResults() {
  document.getElementById("scan-count").textContent = String(state.scannedItems.length);
  const list = document.getElementById("scan-list");
  list.innerHTML = "";
  for (const item of state.scannedItems) {
    const li = document.createElement("li");
    li.className = "scan-item";
    li.textContent = item;
    list.appendChild(li);
  }
}

function taskActions(task) {
  const actions = [];
  actions.push(`<button type="button" data-task-log="${task.id}">查看日志</button>`);
  if (task.output_path && (task.status === "SUCCESS" || task.status === "FAILED")) {
    actions.push(`<button type="button" class="secondary" data-open-path="${task.output_path}">打开结果目录</button>`);
  }
  return actions.join("");
}

function renderTasks(tasks) {
  const container = document.getElementById("tasks-list");
  container.innerHTML = "";
  for (const task of tasks) {
    const card = document.createElement("div");
    card.className = "task-card";
    card.innerHTML = `
      <div class="task-card-top">
        <div>
          <strong>${task.tool_id}</strong>
          <p class="task-path">${task.input_path}</p>
        </div>
        <span class="task-status ${task.status}">${task.status}</span>
      </div>
      <div class="task-card-bottom">
        <p class="task-message">${task.message || ""}</p>
        <span>${task.created_at}</span>
      </div>
      <div class="task-actions">${taskActions(task)}</div>
    `;
    card.addEventListener("click", (event) => {
      if (event.target.dataset.openPath || event.target.dataset.taskLog) {
        return;
      }
      loadLog(task.id);
    });
    for (const button of card.querySelectorAll("[data-task-log]")) {
      button.addEventListener("click", () => loadLog(button.dataset.taskLog));
    }
    for (const button of card.querySelectorAll("[data-open-path]")) {
      button.addEventListener("click", async () => {
        await api("/api/open-path", {
          method: "POST",
          body: JSON.stringify({ path: button.dataset.openPath }),
        });
      });
    }
    container.appendChild(card);
  }
}

async function loadLog(taskId) {
  state.selectedTaskId = taskId;
  document.getElementById("log-title").textContent = `任务 ${taskId}`;
  const text = await api(`/api/tasks/${taskId}/log`);
  document.getElementById("log-viewer").textContent = text || "日志还没产生。";
}

async function refreshTasks() {
  const tasks = await api("/api/tasks");
  renderTasks(tasks);
  if (state.selectedTaskId) {
    try {
      await loadLog(state.selectedTaskId);
    } catch (error) {
      console.warn(error);
    }
  }
}

async function loadSystem() {
  const system = await api("/api/system");
  document.getElementById("platform-version").textContent = system.version;
  document.getElementById("tools-count").textContent = String(system.tools_count);
  document.getElementById("runtime-status").textContent = "正常";
  state.gitUpdate = system.git_update || null;
  renderGitUpdateStatus();
}

async function loadTools() {
  state.tools = await api("/api/tools");
  if (!state.selectedToolId && state.tools.length > 0) {
    state.selectedToolId = state.tools[0].id;
  }
  renderTools();
  renderOptions();
}

async function submitOne() {
  if (!state.selectedToolId) {
    alert("请先选择工具");
    return;
  }
  const inputPath = getInputPath();
  if (!inputPath) {
    alert("请先填写输入目录");
    return;
  }
  await api("/api/tasks", {
    method: "POST",
    body: JSON.stringify({
      tool_id: state.selectedToolId,
      input_path: inputPath,
      options: toolOptionValues(),
    }),
  });
  await refreshTasks();
}

async function scanInputs() {
  if (!state.selectedToolId) {
    alert("请先选择工具");
    return;
  }
  const rootPath = getInputPath();
  if (!rootPath) {
    alert("请先填写父目录");
    return;
  }
  const result = await api("/api/scan", {
    method: "POST",
    body: JSON.stringify({
      tool_id: state.selectedToolId,
      root_path: rootPath,
    }),
  });
  state.scannedItems = result.items || [];
  renderScanResults();
}

async function submitBatch() {
  if (!state.selectedToolId) {
    alert("请先选择工具");
    return;
  }
  if (state.scannedItems.length === 0) {
    alert("先扫描出有效场景，再批量入队");
    return;
  }
  await api("/api/tasks/batch", {
    method: "POST",
    body: JSON.stringify({
      tool_id: state.selectedToolId,
      input_paths: state.scannedItems,
      options: toolOptionValues(),
    }),
  });
  await refreshTasks();
}

async function pickFolder() {
  const result = await api("/api/pick-folder", {
    method: "POST",
    body: JSON.stringify({ initial_dir: getInputPath() || "/" }),
  });
  if (result.path) {
    document.getElementById("input-path").value = result.path;
  }
}

function formatDateTime(value) {
  if (!value) {
    return "-";
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }
  return date.toLocaleString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function renderGitUpdateStatus() {
  const status = state.gitUpdate || {};
  const stateText = status.message || "启动时会自动检查更新。";
  document.getElementById("app-version").textContent = document.getElementById("platform-version").textContent || "-";
  document.getElementById("update-status-text").textContent = stateText;
  document.getElementById("update-checked-at").textContent = formatDateTime(status.last_checked_at);
}

async function main() {
  await loadSystem();
  await loadTools();
  await refreshTasks();

  document.getElementById("submit-one-btn").addEventListener("click", submitOne);
  document.getElementById("scan-btn").addEventListener("click", scanInputs);
  document.getElementById("submit-batch-btn").addEventListener("click", submitBatch);
  document.getElementById("pick-folder-btn").addEventListener("click", pickFolder);

  setInterval(refreshTasks, 3000);
}

main().catch((error) => {
  console.error(error);
  alert(`启动失败：${error.message}`);
});
