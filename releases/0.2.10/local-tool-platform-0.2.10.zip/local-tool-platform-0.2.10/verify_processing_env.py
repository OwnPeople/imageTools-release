#!/usr/bin/env python3
from __future__ import annotations

import importlib
import sys


REQUIRED_MODULES = ("cv2", "numpy", "PIL", "rasterio")


def main() -> int:
    missing: list[str] = []
    for module_name in REQUIRED_MODULES:
        try:
            module = importlib.import_module(module_name)
        except Exception as exc:
            missing.append(f"{module_name}: {exc}")
            continue
        version = getattr(module, "__version__", "unknown")
        print(f"{module_name}: OK ({version})")

    if not missing:
        print("Processing environment is ready.")
        return 0

    print("Processing environment is not ready.", file=sys.stderr)
    for item in missing:
        print(f"  - {item}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
