#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_DIR="$ROOT_DIR/dist"
if [[ -n "${PACKAGE_VERSION:-}" ]]; then
  PACKAGE_NAME="local-tool-platform-$PACKAGE_VERSION"
else
  PACKAGE_NAME="local-tool-platform-$(date +%Y%m%d-%H%M%S)"
fi
STAGE_DIR="$DIST_DIR/$PACKAGE_NAME"
ZIP_PATH="$DIST_DIR/$PACKAGE_NAME.zip"

rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR/tool_platform" "$DIST_DIR"

copy_file() {
  local source="$1"
  if [[ -e "$ROOT_DIR/$source" ]]; then
    cp "$ROOT_DIR/$source" "$STAGE_DIR/$source"
  fi
}

copy_dir() {
  local source="$1"
  if [[ -d "$ROOT_DIR/$source" ]]; then
    mkdir -p "$(dirname "$STAGE_DIR/$source")"
    rsync -a \
      --exclude '__pycache__/' \
      --exclude '*.pyc' \
      --exclude '.DS_Store' \
      "$ROOT_DIR/$source/" "$STAGE_DIR/$source/"
  fi
}

copy_file "run_gf7_clean.sh"
copy_file "run_mosaic_all.sh"
copy_file "rebuild_gf7_truecolor_clean.py"
copy_file "mosaic_gf2_batch.py"
copy_file "mosaic_gf2_geotiffs.py"
copy_file "mosaic_tiffs_hierarchical.py"
copy_file "postprocess_mosaic_color_fill.py"
copy_file "diagnose_mosaic_seams.py"
copy_file "verify_processing_env.py"
copy_file "启动本地工具平台.bat"
copy_file "TOOL_PLATFORM_ARCHITECTURE.md"
copy_file "RELEASE_WORKFLOW.md"
copy_file "GIT_UPDATE_WORKFLOW.md"
copy_file "FOOLPROOF_DEPLOYMENT.md"
copy_file "package_tool_platform.sh"
copy_file "make_release.sh"
copy_file "make_macos_app.sh"

copy_file "tool_platform/README.md"
copy_file "tool_platform/requirements.txt"
copy_file "tool_platform/requirements-processing.txt"
copy_file "tool_platform/bootstrap_setup.sh"
copy_file "tool_platform/setup_platform.sh"
copy_file "tool_platform/update_from_git.sh"
copy_file "tool_platform/update_from_http.py"
copy_file "tool_platform/run_platform.sh"
copy_file "tool_platform/run_platform_windows.ps1"
copy_file "tool_platform/UPDATE_MANIFEST_EXAMPLE.json"
copy_dir "tool_platform/app"
copy_dir "tool_platform/static"
copy_dir "tool_platform/templates"
copy_dir "tool_platform/tools"

chmod +x "$STAGE_DIR/run_gf7_clean.sh" "$STAGE_DIR/run_mosaic_all.sh"
chmod +x "$STAGE_DIR/tool_platform/bootstrap_setup.sh" "$STAGE_DIR/tool_platform/setup_platform.sh" "$STAGE_DIR/tool_platform/update_from_git.sh" "$STAGE_DIR/tool_platform/run_platform.sh"

rm -f "$ZIP_PATH"
(
  cd "$DIST_DIR"
  zip -qr "$ZIP_PATH" "$PACKAGE_NAME"
)

echo "Package created: $ZIP_PATH"
