#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Sequence, Tuple

import numpy as np
import cv2

try:
    import rasterio
    from rasterio import Affine
    from rasterio.errors import RasterioIOError
    from rasterio.enums import Resampling
    from rasterio.vrt import WarpedVRT
    from rasterio.warp import transform_bounds
    from rasterio.windows import Window, transform as window_transform
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "This script requires rasterio. On this machine you can usually run it with "
        "/opt/anaconda3/bin/python mosaic_gf2_geotiffs.py ..."
    ) from exc


@dataclass
class SourceInfo:
    path: Path
    crs: object
    width: int
    height: int
    count: int
    dtype: str
    transform: Affine
    bounds: Tuple[float, float, float, float]
    res: Tuple[float, float]
    pixel_area: float


@dataclass
class SourceRuntime:
    info: SourceInfo
    dataset: object
    vrt: object
    pixel_matrix: np.ndarray
    band_gain: np.ndarray | None = None
    band_offset: np.ndarray | None = None
    read_error_count: int = 0
    warned_read_error: bool = False
    last_read_error: str = ""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Mosaic GF-2 GeoTIFF files onto one aligned output grid without introducing manual spatial offsets."
    )
    parser.add_argument(
        "input_dir",
        nargs="?",
        default="/Users/jun/Documents/map/高分2号镶嵌测试",
        help="Folder containing source tif/tiff files",
    )
    parser.add_argument(
        "--output",
        default="",
        help="Output mosaic path; default is <input_dir>/GF2_truecolor_mosaic.tif",
    )
    parser.add_argument(
        "--pattern",
        default="*.tif",
        help="Input glob pattern inside input_dir",
    )
    parser.add_argument(
        "--reference",
        default="auto",
        help="Reference grid source: auto, finest, or an exact input filename",
    )
    parser.add_argument(
        "--method",
        choices=("first", "last", "blend"),
        default="blend",
        help="Overlap rule: first keeps the first source pixel, last lets later sources overwrite, blend averages overlap",
    )
    parser.add_argument(
        "--resampling",
        choices=("nearest", "bilinear", "cubic"),
        default="bilinear",
        help="Resampling used when aligning onto the target grid",
    )
    parser.add_argument(
        "--register-mode",
        choices=("none", "translation", "affine"),
        default="affine",
        help="Estimate image-space registration against the reference source before mosaicking",
    )
    parser.add_argument(
        "--register-max-size",
        type=int,
        default=2800,
        help="Longest side of the overlap sample used for automatic registration",
    )
    parser.add_argument(
        "--tile-size",
        type=int,
        default=1024,
        help="Processing tile size in output pixels",
    )
    parser.add_argument(
        "--compress",
        choices=("lzw", "deflate"),
        default="lzw",
        help="GeoTIFF compression",
    )
    parser.add_argument(
        "--ignore-read-errors",
        action="store_true",
        help="If a source tile cannot be decoded, treat that source window as empty instead of aborting the whole run",
    )
    parser.add_argument(
        "--build-overviews",
        action="store_true",
        help="Build overview pyramids after writing the mosaic",
    )
    parser.add_argument(
        "--skip-crop",
        action="store_true",
        help="Do not crop empty outer borders after mosaicking",
    )
    parser.add_argument(
        "--skip-preview",
        action="store_true",
        help="Do not create a JPEG preview after the mosaic finishes",
    )
    parser.add_argument(
        "--preview-max-size",
        type=int,
        default=2400,
        help="Longest side of the JPEG preview in pixels",
    )
    parser.add_argument(
        "--preview-quality",
        type=int,
        default=90,
        help="JPEG preview quality from 1 to 100",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite the output if it already exists",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only print the mosaic plan, do not write the output",
    )
    return parser.parse_args()


def discover_inputs(input_dir: Path, pattern: str, output_path: Path) -> List[Path]:
    paths = sorted(path.resolve() for path in input_dir.glob(pattern) if path.is_file())
    if output_path.exists():
        output_resolved = output_path.resolve()
        paths = [path for path in paths if path != output_resolved]
    if len(paths) < 2:
        raise FileNotFoundError(
            f"Need at least two input TIFF files under {input_dir}, but found {len(paths)}."
        )
    return paths


def inspect_sources(paths: Sequence[Path]) -> List[SourceInfo]:
    sources: List[SourceInfo] = []
    for path in paths:
        with rasterio.open(path) as ds:
            if ds.count < 3:
                raise ValueError(f"{path.name} has only {ds.count} band(s); expected at least 3 RGB bands.")
            if ds.crs is None:
                raise ValueError(f"{path.name} has no CRS.")
            resx = abs(float(ds.res[0]))
            resy = abs(float(ds.res[1]))
            sources.append(
                SourceInfo(
                    path=path,
                    crs=ds.crs,
                    width=ds.width,
                    height=ds.height,
                    count=ds.count,
                    dtype=str(ds.dtypes[0]),
                    transform=ds.transform,
                    bounds=(ds.bounds.left, ds.bounds.bottom, ds.bounds.right, ds.bounds.top),
                    res=(resx, resy),
                    pixel_area=resx * resy,
                )
            )
    return sources


def choose_reference(sources: Sequence[SourceInfo], reference_arg: str) -> SourceInfo:
    reference_arg = reference_arg.strip()
    if reference_arg in ("", "auto", "finest"):
        return min(sources, key=lambda item: (item.pixel_area, item.path.name))
    for source in sources:
        if source.path.name == reference_arg or str(source.path) == reference_arg:
            return source
    raise FileNotFoundError(f"Reference source not found: {reference_arg}")


def align_floor(value: float, origin: float, step: float) -> float:
    return origin + math.floor((value - origin) / step) * step


def align_ceil(value: float, origin: float, step: float) -> float:
    return origin + math.ceil((value - origin) / step) * step


def compute_target_grid(sources: Sequence[SourceInfo], reference: SourceInfo) -> Tuple[Affine, int, int, object]:
    union_left = None
    union_bottom = None
    union_right = None
    union_top = None

    for source in sources:
        if source.crs == reference.crs:
            left, bottom, right, top = source.bounds
        else:
            left, bottom, right, top = transform_bounds(
                source.crs,
                reference.crs,
                *source.bounds,
                densify_pts=21,
            )
        union_left = left if union_left is None else min(union_left, left)
        union_bottom = bottom if union_bottom is None else min(union_bottom, bottom)
        union_right = right if union_right is None else max(union_right, right)
        union_top = top if union_top is None else max(union_top, top)

    assert union_left is not None
    assert union_bottom is not None
    assert union_right is not None
    assert union_top is not None

    resx, resy = reference.res
    origin_x = reference.transform.c
    origin_y = reference.transform.f

    left = align_floor(union_left, origin_x, resx)
    right = align_ceil(union_right, origin_x, resx)
    top = align_ceil(union_top, origin_y, resy)
    bottom = align_floor(union_bottom, origin_y, resy)

    width = int(round((right - left) / resx))
    height = int(round((top - bottom) / resy))
    if width <= 0 or height <= 0:
        raise ValueError("Computed target grid is empty.")

    transform = Affine(resx, 0.0, left, 0.0, -resy, top)
    return transform, width, height, reference.crs


def gtiff_block_size(size: int) -> int:
    if size >= 512:
        return 512
    rounded = max(16, int(math.ceil(size / 16.0) * 16))
    return rounded


def print_plan(
    input_dir: Path,
    output_path: Path,
    preview_path: Path,
    sources: Sequence[SourceInfo],
    reference: SourceInfo,
    transform: Affine,
    width: int,
    height: int,
) -> None:
    print(f"Input folder:   {input_dir}")
    print(f"Output mosaic:  {output_path}")
    print(f"Preview image:  {preview_path}")
    print(f"Reference grid: {reference.path.name}")
    print(f"Target CRS:     {reference.crs}")
    print(f"Target size:    {width} x {height}")
    print(f"Target res:     ({transform.a:.15f}, {abs(transform.e):.15f})")
    print(f"Target origin:  ({transform.c:.9f}, {transform.f:.9f})")
    print("Sources:")
    for source in sources:
        left, bottom, right, top = source.bounds
        print(
            "  - "
            f"{source.path.name} | size={source.width}x{source.height} | "
            f"res=({source.res[0]:.15f}, {source.res[1]:.15f}) | "
            f"bounds=({left:.6f}, {bottom:.6f}, {right:.6f}, {top:.6f})"
        )


def build_output_profile(reference: SourceInfo, transform: Affine, width: int, height: int, compress: str) -> dict:
    profile = {
        "driver": "GTiff",
        "width": width,
        "height": height,
        "count": 3,
        "dtype": reference.dtype,
        "crs": reference.crs,
        "transform": transform,
        "compress": compress,
        "tiled": True,
        "blockxsize": gtiff_block_size(width),
        "blockysize": gtiff_block_size(height),
        "interleave": "pixel",
        "photometric": "RGB",
        "BIGTIFF": "YES",
    }
    if compress == "deflate":
        profile["predictor"] = 2
    return profile


def iter_windows(width: int, height: int, tile_size: int) -> Sequence[Window]:
    for row_off in range(0, height, tile_size):
        row_size = min(tile_size, height - row_off)
        for col_off in range(0, width, tile_size):
            col_size = min(tile_size, width - col_off)
            yield Window(col_off=col_off, row_off=row_off, width=col_size, height=row_size)


def build_overviews(output_path: Path) -> None:
    factors = [2, 4, 8, 16]
    with rasterio.open(output_path, "r+") as ds:
        ds.build_overviews(factors, Resampling.average)
        ds.update_tags(ns="rio_overview", resampling="average")


def find_valid_data_window(dataset: rasterio.io.DatasetReader) -> Window | None:
    min_row = dataset.height
    min_col = dataset.width
    max_row = 0
    max_col = 0
    found = False

    for _, window in dataset.block_windows(1):
        mask = dataset.dataset_mask(window=window)
        if not np.any(mask > 0):
            continue
        ys, xs = np.where(mask > 0)
        min_row = min(min_row, int(window.row_off) + int(ys.min()))
        min_col = min(min_col, int(window.col_off) + int(xs.min()))
        max_row = max(max_row, int(window.row_off) + int(ys.max()) + 1)
        max_col = max(max_col, int(window.col_off) + int(xs.max()) + 1)
        found = True

    if not found:
        return None
    return Window(
        col_off=min_col,
        row_off=min_row,
        width=max_col - min_col,
        height=max_row - min_row,
    )


def crop_output_to_data(output_path: Path, tile_size: int) -> None:
    with rasterio.open(output_path) as src:
        data_window = find_valid_data_window(src)
        if data_window is None:
            raise RuntimeError("The mosaic contains no valid pixels.")
        if (
            int(data_window.col_off) == 0
            and int(data_window.row_off) == 0
            and int(data_window.width) == src.width
            and int(data_window.height) == src.height
        ):
            print("Crop to data: output already tightly bounded.")
            return

        profile = src.profile.copy()
        profile.update(
            width=int(data_window.width),
            height=int(data_window.height),
            transform=window_transform(data_window, src.transform),
            blockxsize=gtiff_block_size(int(data_window.width)),
            blockysize=gtiff_block_size(int(data_window.height)),
            BIGTIFF="YES",
        )
        temp_path = output_path.with_name(output_path.stem + "_cropped_tmp.tif")
        if temp_path.exists():
            temp_path.unlink()

        print(
            "Crop to data: "
            f"col={int(data_window.col_off)}, row={int(data_window.row_off)}, "
            f"width={int(data_window.width)}, height={int(data_window.height)}"
        )

        with rasterio.open(temp_path, "w", **profile) as dst:
            for window in iter_windows(int(data_window.width), int(data_window.height), tile_size):
                source_window = Window(
                    col_off=int(data_window.col_off) + int(window.col_off),
                    row_off=int(data_window.row_off) + int(window.row_off),
                    width=int(window.width),
                    height=int(window.height),
                )
                data = src.read(window=source_window)
                mask = src.dataset_mask(window=source_window)
                dst.write(data, window=window)
                dst.write_mask(mask, window=window)

    output_path.unlink()
    temp_path.replace(output_path)


def identity_pixel_matrix() -> np.ndarray:
    return np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32)


def source_bounds_in_target_crs(source: SourceInfo, target_crs: object) -> Tuple[float, float, float, float]:
    if source.crs == target_crs:
        return source.bounds
    left, bottom, right, top = transform_bounds(
        source.crs,
        target_crs,
        *source.bounds,
        densify_pts=21,
    )
    return left, bottom, right, top


def bounds_to_window(bounds: Tuple[float, float, float, float], transform: Affine, width: int, height: int) -> Window:
    inv = ~transform
    left, bottom, right, top = bounds
    col0, row0 = inv * (left, top)
    col1, row1 = inv * (right, bottom)
    col_off = max(0, int(math.floor(min(col0, col1))))
    row_off = max(0, int(math.floor(min(row0, row1))))
    col_end = min(width, int(math.ceil(max(col0, col1))))
    row_end = min(height, int(math.ceil(max(row0, row1))))
    return Window(col_off=col_off, row_off=row_off, width=max(0, col_end - col_off), height=max(0, row_end - row_off))


def overlap_bounds_in_target_crs(sources: Sequence[SourceInfo], target_crs: object) -> Tuple[float, float, float, float]:
    overlap_left = None
    overlap_bottom = None
    overlap_right = None
    overlap_top = None
    for source in sources:
        left, bottom, right, top = source_bounds_in_target_crs(source, target_crs)
        overlap_left = left if overlap_left is None else max(overlap_left, left)
        overlap_bottom = bottom if overlap_bottom is None else max(overlap_bottom, bottom)
        overlap_right = right if overlap_right is None else min(overlap_right, right)
        overlap_top = top if overlap_top is None else min(overlap_top, top)
    assert overlap_left is not None
    assert overlap_bottom is not None
    assert overlap_right is not None
    assert overlap_top is not None
    return overlap_left, overlap_bottom, overlap_right, overlap_top


def prepare_gray_for_matching(rgb: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    gray[~alpha] = 0
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(gray)


def mask_black_background(rgb: np.ndarray, alpha: np.ndarray, threshold: int = 1) -> np.ndarray:
    if rgb.ndim != 3 or rgb.shape[0] != 3:
        return alpha
    non_black = np.any(rgb > threshold, axis=0)
    return alpha & non_black


def sample_scene_radiometric_stats(
    dataset,
    max_side: int = 1024,
    grid_size: int = 4,
    min_valid_pixels: int = 1000,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    samples: List[List[np.ndarray]] = [[], [], []]

    grid_size = max(1, int(grid_size))
    win_w = max(256, int(math.ceil(dataset.width / grid_size)))
    win_h = max(256, int(math.ceil(dataset.height / grid_size)))

    for row_idx in range(grid_size):
        row_off = min(row_idx * win_h, max(0, dataset.height - 1))
        height = min(win_h, dataset.height - row_off)
        if height <= 0:
            continue
        for col_idx in range(grid_size):
            col_off = min(col_idx * win_w, max(0, dataset.width - 1))
            width = min(win_w, dataset.width - col_off)
            if width <= 0:
                continue

            window = Window(col_off=col_off, row_off=row_off, width=width, height=height)
            scale = min(max_side / max(float(width), float(height)), 1.0)
            out_h = max(1, int(round(height * scale)))
            out_w = max(1, int(round(width * scale)))

            try:
                data = dataset.read(
                    indexes=[1, 2, 3],
                    window=window,
                    out_shape=(3, out_h, out_w),
                    resampling=Resampling.bilinear,
                )
            except Exception:
                continue

            alpha = mask_black_background(data, np.ones((out_h, out_w), dtype=bool))
            if not np.any(alpha):
                continue

            valid_count = int(alpha.sum())
            stride = max(1, int(math.sqrt(valid_count / 8000.0)))
            sampled_alpha = alpha[::stride, ::stride]
            if not np.any(sampled_alpha):
                continue

            for band in range(3):
                sampled_band = data[band, ::stride, ::stride][sampled_alpha].astype(np.float32)
                if sampled_band.size:
                    samples[band].append(sampled_band)

    total_valid = sum(chunk.size for chunk in samples[0])
    if total_valid < min_valid_pixels:
        raise RuntimeError(f"Too few valid pixels for radiometric statistics: {dataset.name}")

    p05 = np.zeros(3, dtype=np.float32)
    p50 = np.zeros(3, dtype=np.float32)
    p95 = np.zeros(3, dtype=np.float32)
    for band in range(3):
        values = np.concatenate(samples[band], axis=0)
        p05[band], p50[band], p95[band] = np.percentile(values, [5.0, 50.0, 95.0])
    return p05, p50, p95


def estimate_radiometric_adjustment(
    source_stats: Tuple[np.ndarray, np.ndarray, np.ndarray],
    reference_stats: Tuple[np.ndarray, np.ndarray, np.ndarray],
    offset_strength: float = 0.12,
    max_offset: float = 8.0,
    gain_strength: float = 0.0,
    max_gain_delta: float = 0.12,
) -> Tuple[np.ndarray, np.ndarray]:
    src_p05, src_p50, src_p95 = source_stats
    ref_p05, ref_p50, ref_p95 = reference_stats

    # Keep this deliberately conservative. The source products can come from
    # different seasons and sensors, so a strong whole-scene match can wash out
    # real local contrast. Local seam matching handles the harder edge cleanup.
    src_span = np.maximum(src_p95 - src_p05, 1.0)
    ref_span = np.maximum(ref_p95 - ref_p05, 1.0)
    raw_gain = ref_span / src_span
    raw_gain = np.clip(raw_gain, 1.0 - float(max_gain_delta), 1.0 + float(max_gain_delta))
    gain = 1.0 + (raw_gain - 1.0) * float(gain_strength)
    gain = gain.astype(np.float32)

    raw_offset = ref_p50 - (src_p50 * gain)
    offset = np.clip(raw_offset, -float(max_offset), float(max_offset)).astype(np.float32)
    offset *= float(offset_strength)
    return gain, offset


def configure_runtime_radiometric_matching(
    runtimes: Sequence[SourceRuntime],
    reference_path: Path,
    max_side: int = 1024,
    offset_strength: float = 0.12,
    max_offset: float = 8.0,
    gain_strength: float = 0.0,
    max_gain_delta: float = 0.12,
) -> None:
    stats_by_path = {}
    for runtime in runtimes:
        try:
            stats_by_path[runtime.info.path] = sample_scene_radiometric_stats(runtime.dataset, max_side=max_side)
        except Exception as exc:
            print(
                f"Warning: radiometric stats failed for {runtime.info.path.name}; "
                f"fallback to no color adjustment for this scene. ({exc})"
            )
            stats_by_path[runtime.info.path] = None

    reference_stats = stats_by_path[reference_path]
    if reference_stats is None:
        print("Warning: reference scene stats are unavailable; disable radiometric matching for this stage.")
        for runtime in runtimes:
            runtime.band_gain = np.ones(3, dtype=np.float32)
            runtime.band_offset = np.zeros(3, dtype=np.float32)
        return

    for runtime in runtimes:
        if runtime.info.path == reference_path or stats_by_path[runtime.info.path] is None:
            runtime.band_gain = np.ones(3, dtype=np.float32)
            runtime.band_offset = np.zeros(3, dtype=np.float32)
            continue
        gain, offset = estimate_radiometric_adjustment(
            stats_by_path[runtime.info.path],
            reference_stats,
            offset_strength=offset_strength,
            max_offset=max_offset,
            gain_strength=gain_strength,
            max_gain_delta=max_gain_delta,
        )
        runtime.band_gain = gain
        runtime.band_offset = offset
        print(
            "Radiometric match for "
            f"{runtime.info.path.name}: gain={np.array2string(gain, precision=3)}, "
            f"offset={np.array2string(offset, precision=3)}"
        )


def apply_radiometric_adjustment(rgb: np.ndarray, alpha: np.ndarray, runtime: SourceRuntime) -> np.ndarray:
    if runtime.band_gain is None or runtime.band_offset is None or not np.any(alpha):
        return rgb

    adjusted = rgb.astype(np.float32, copy=True)
    valid = alpha
    for band in range(3):
        band_data = adjusted[band]
        band_data[valid] = band_data[valid] * float(runtime.band_gain[band]) + float(runtime.band_offset[band])
    return np.clip(adjusted, 0, 255).astype(rgb.dtype)


def choose_feature_detector() -> Tuple[object, int, str]:
    if hasattr(cv2, "SIFT_create"):
        return cv2.SIFT_create(8000), cv2.NORM_L2, "SIFT"
    return cv2.AKAZE_create(), cv2.NORM_HAMMING, "AKAZE"


def local_to_global_pixel_matrix(local_matrix: np.ndarray, crop_offset: np.ndarray, sample_window: Window, scale: float) -> np.ndarray:
    linear = local_matrix[:, :2].astype(np.float64)
    translation = local_matrix[:, 2].astype(np.float64)
    crop_offset = crop_offset.astype(np.float64)
    sample_origin = np.array([sample_window.col_off, sample_window.row_off], dtype=np.float64)
    shifted = translation + crop_offset - linear @ crop_offset
    global_translation = shifted / scale + sample_origin - linear @ sample_origin
    result = np.hstack([linear, global_translation.reshape(2, 1)]).astype(np.float32)
    return result


def translation_matrix_from_points(src_pts: np.ndarray, ref_pts: np.ndarray) -> np.ndarray:
    deltas = ref_pts - src_pts
    dx = float(np.median(deltas[:, 0]))
    dy = float(np.median(deltas[:, 1]))
    return np.array([[1.0, 0.0, dx], [0.0, 1.0, dy]], dtype=np.float32)


def affine_matrix_is_reasonable(
    matrix: np.ndarray,
    sample_window: Window,
    inlier_count: int,
    good_match_count: int,
) -> bool:
    if matrix is None or good_match_count <= 0:
        return False
    if inlier_count < 40:
        return False
    if inlier_count / float(good_match_count) < 0.28:
        return False

    linear = matrix[:, :2].astype(np.float64)
    try:
        _, singular_values, _ = np.linalg.svd(linear)
    except np.linalg.LinAlgError:
        return False
    if singular_values.min() < 0.92 or singular_values.max() > 1.08:
        return False

    rotation_deg = abs(math.degrees(math.atan2(linear[1, 0], linear[0, 0])))
    if rotation_deg > 3.0:
        return False

    shear_like = max(abs(float(linear[0, 1])), abs(float(linear[1, 0])))
    if shear_like > 0.06:
        return False

    translation = matrix[:, 2].astype(np.float64)
    shift_limit = max(80.0, 0.18 * max(float(sample_window.width), float(sample_window.height)))
    if np.linalg.norm(translation) > shift_limit:
        return False

    return True


def translation_matrix_is_reasonable(matrix: np.ndarray, sample_window: Window) -> bool:
    translation = matrix[:, 2].astype(np.float64)
    shift_limit = max(120.0, 0.28 * max(float(sample_window.width), float(sample_window.height)))
    return np.linalg.norm(translation) <= shift_limit


def estimate_registration_pixel_matrix(
    source_vrt: WarpedVRT,
    reference_vrt: WarpedVRT,
    source_info: SourceInfo,
    reference_info: SourceInfo,
    target_transform: Affine,
    width: int,
    height: int,
    args: argparse.Namespace,
) -> np.ndarray:
    if args.register_mode == "none":
        return identity_pixel_matrix()

    overlap_bounds = overlap_bounds_in_target_crs((source_info, reference_info), reference_info.crs)
    left, bottom, right, top = overlap_bounds
    if left >= right or bottom >= top:
        print(f"No overlap between {source_info.path.name} and {reference_info.path.name}; skip registration.")
        return identity_pixel_matrix()

    sample_window = bounds_to_window(overlap_bounds, target_transform, width, height)
    if sample_window.width <= 0 or sample_window.height <= 0:
        print(f"Empty overlap window for {source_info.path.name}; skip registration.")
        return identity_pixel_matrix()

    scale = min(
        args.register_max_size / max(float(sample_window.width), 1.0),
        args.register_max_size / max(float(sample_window.height), 1.0),
        1.0,
    )
    out_h = max(1, int(round(sample_window.height * scale)))
    out_w = max(1, int(round(sample_window.width * scale)))
    source_data = source_vrt.read([1, 2, 3, 4], window=sample_window, out_shape=(4, out_h, out_w), resampling=Resampling.bilinear)
    reference_data = reference_vrt.read([1, 2, 3, 4], window=sample_window, out_shape=(4, out_h, out_w), resampling=Resampling.bilinear)

    source_rgb = np.moveaxis(source_data[:3], 0, 2)
    reference_rgb = np.moveaxis(reference_data[:3], 0, 2)
    source_alpha = source_data[3] > 0
    reference_alpha = reference_data[3] > 0
    common_mask = source_alpha & reference_alpha
    if int(common_mask.sum()) < 5000:
        print(f"Too few overlapping pixels for {source_info.path.name}; skip registration.")
        return identity_pixel_matrix()

    ys, xs = np.where(common_mask)
    crop_y0, crop_y1 = ys.min(), ys.max() + 1
    crop_x0, crop_x1 = xs.min(), xs.max() + 1
    crop_offset = np.array([crop_x0, crop_y0], dtype=np.float32)

    source_gray = prepare_gray_for_matching(source_rgb[crop_y0:crop_y1, crop_x0:crop_x1], source_alpha[crop_y0:crop_y1, crop_x0:crop_x1])
    reference_gray = prepare_gray_for_matching(reference_rgb[crop_y0:crop_y1, crop_x0:crop_x1], reference_alpha[crop_y0:crop_y1, crop_x0:crop_x1])

    detector, norm_type, detector_name = choose_feature_detector()
    kp_source, des_source = detector.detectAndCompute(source_gray, None)
    kp_ref, des_ref = detector.detectAndCompute(reference_gray, None)
    if des_source is None or des_ref is None or len(kp_source) < 20 or len(kp_ref) < 20:
        print(f"{detector_name} found too few features for {source_info.path.name}; skip registration.")
        return identity_pixel_matrix()

    matcher = cv2.BFMatcher(norm_type)
    raw_matches = matcher.knnMatch(des_source, des_ref, k=2)
    good_matches = []
    src_pts = []
    ref_pts = []
    for pair in raw_matches:
        if len(pair) < 2:
            continue
        match_a, match_b = pair
        if match_a.distance < 0.75 * match_b.distance:
            good_matches.append(match_a)
            src_pts.append(kp_source[match_a.queryIdx].pt)
            ref_pts.append(kp_ref[match_a.trainIdx].pt)

    if len(good_matches) < 30:
        print(f"Too few good matches for {source_info.path.name}; skip registration.")
        return identity_pixel_matrix()

    src_pts_np = np.float32(src_pts)
    ref_pts_np = np.float32(ref_pts)
    translation_matrix = translation_matrix_from_points(src_pts_np, ref_pts_np)
    if args.register_mode == "translation":
        local_matrix = translation_matrix
        inlier_count = len(good_matches)
    else:
        local_matrix, inliers = cv2.estimateAffinePartial2D(
            src_pts_np,
            ref_pts_np,
            method=cv2.RANSAC,
            ransacReprojThreshold=6.0,
            maxIters=5000,
            confidence=0.995,
        )
        if local_matrix is None:
            print(f"Affine registration failed for {source_info.path.name}; skip registration.")
            return identity_pixel_matrix()
        inlier_count = int(inliers.sum()) if inliers is not None else 0
        if not affine_matrix_is_reasonable(local_matrix, sample_window, inlier_count, len(good_matches)):
            if translation_matrix_is_reasonable(translation_matrix, sample_window):
                print(
                    f"Affine registration looked unstable for {source_info.path.name}; "
                    "fallback to translation-only registration."
                )
                local_matrix = translation_matrix
                inlier_count = len(good_matches)
            else:
                print(
                    f"Affine registration looked unstable for {source_info.path.name}; "
                    "fallback to raw georeferencing."
                )
                return identity_pixel_matrix()

    full_matrix = local_to_global_pixel_matrix(local_matrix.astype(np.float32), crop_offset, sample_window, scale)
    print(
        f"Registration {args.register_mode} for {source_info.path.name}: "
        f"matches={len(good_matches)}, inliers={inlier_count}, "
        f"matrix={np.array2string(full_matrix, precision=6, suppress_small=False)}"
    )
    return full_matrix


def read_registered_window(
    runtime: SourceRuntime,
    window: Window,
    rgb_resampling_flag: int,
    ignore_read_errors: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    win_h = int(window.height)
    win_w = int(window.width)

    def empty_result() -> Tuple[np.ndarray, np.ndarray]:
        return np.zeros((3, win_h, win_w), dtype=runtime.info.dtype), np.zeros((win_h, win_w), dtype=bool)

    def handle_read_error(exc: Exception, stage: str) -> Tuple[np.ndarray, np.ndarray]:
        message = (
            f"{runtime.info.path.name}: read failed during {stage} at output window "
            f"row={int(window.row_off)}, col={int(window.col_off)}, h={win_h}, w={win_w}: {exc}"
        )
        runtime.read_error_count += 1
        runtime.last_read_error = message
        if ignore_read_errors:
            if not runtime.warned_read_error:
                print(
                    f"Warning: {runtime.info.path.name} has unreadable source tiles. "
                    "Those bad windows will be treated as empty for this source."
                )
                print(f"  First read error: {message}")
                runtime.warned_read_error = True
            return empty_result()
        raise RasterioIOError(message) from exc

    if np.allclose(runtime.pixel_matrix, identity_pixel_matrix(), atol=1e-6):
        try:
            data = runtime.vrt.read(indexes=[1, 2, 3, 4], window=window)
        except Exception as exc:
            return handle_read_error(exc, "identity read")
        rgb = data[:3]
        alpha = mask_black_background(rgb, data[3] > 0)
        rgb = apply_radiometric_adjustment(rgb, alpha, runtime)
        return rgb, alpha

    matrix = runtime.pixel_matrix.astype(np.float64)
    inv_matrix = cv2.invertAffineTransform(matrix.astype(np.float32)).astype(np.float64)
    corners = np.array(
        [
            [window.col_off, window.row_off],
            [window.col_off + window.width, window.row_off],
            [window.col_off + window.width, window.row_off + window.height],
            [window.col_off, window.row_off + window.height],
        ],
        dtype=np.float64,
    )
    src_corners = np.column_stack(
        [
            inv_matrix[0, 0] * corners[:, 0] + inv_matrix[0, 1] * corners[:, 1] + inv_matrix[0, 2],
            inv_matrix[1, 0] * corners[:, 0] + inv_matrix[1, 1] * corners[:, 1] + inv_matrix[1, 2],
        ]
    )
    pad = 4
    src_col_off = max(0, int(math.floor(src_corners[:, 0].min())) - pad)
    src_row_off = max(0, int(math.floor(src_corners[:, 1].min())) - pad)
    # The source window is expressed in the WarpedVRT's target grid, not in the
    # original dataset's native pixel grid. Cluster mosaics can be much narrower
    # than the final target canvas, so clamping to runtime.info.width/height can
    # silently drop registered sources that sit far to the right or bottom.
    src_col_end = min(runtime.vrt.width, int(math.ceil(src_corners[:, 0].max())) + pad)
    src_row_end = min(runtime.vrt.height, int(math.ceil(src_corners[:, 1].max())) + pad)
    if src_col_end <= src_col_off or src_row_end <= src_row_off:
        return empty_result()

    source_window = Window(
        col_off=src_col_off,
        row_off=src_row_off,
        width=src_col_end - src_col_off,
        height=src_row_end - src_row_off,
    )
    try:
        data = runtime.vrt.read(indexes=[1, 2, 3, 4], window=source_window)
    except Exception as exc:
        return handle_read_error(exc, "registered read")
    rgb_patch = np.moveaxis(data[:3], 0, 2)
    alpha_patch = (data[3] > 0).astype(np.uint8) * 255
    if not np.any(alpha_patch):
        return empty_result()

    linear = matrix[:, :2]
    translation = linear @ np.array([src_col_off, src_row_off], dtype=np.float64) + matrix[:, 2]
    local_translation = translation - np.array([window.col_off, window.row_off], dtype=np.float64)
    local_matrix = np.hstack([linear, local_translation.reshape(2, 1)]).astype(np.float32)

    warped_rgb = cv2.warpAffine(
        rgb_patch,
        local_matrix,
        (win_w, win_h),
        flags=rgb_resampling_flag,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    warped_alpha = cv2.warpAffine(
        alpha_patch,
        local_matrix,
        (win_w, win_h),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    warped_rgb_chw = np.moveaxis(warped_rgb, 2, 0)
    alpha = mask_black_background(warped_rgb_chw, warped_alpha > 0)
    warped_rgb_chw = apply_radiometric_adjustment(warped_rgb_chw, alpha, runtime)
    return warped_rgb_chw, alpha


def print_runtime_read_error_summary(runtimes: Sequence[SourceRuntime]) -> None:
    error_runtimes = [runtime for runtime in runtimes if runtime.read_error_count > 0]
    if not error_runtimes:
        return
    print("Read error summary:")
    for runtime in error_runtimes:
        print(f"  - {runtime.info.path.name}: {runtime.read_error_count} bad window(s)")
        if runtime.last_read_error:
            print(f"    last: {runtime.last_read_error}")


def default_preview_path(output_path: Path) -> Path:
    return output_path.with_name(output_path.stem + "_preview.jpg")


def write_preview(output_path: Path, preview_path: Path, max_size: int, quality: int) -> None:
    max_size = max(256, int(max_size))
    quality = max(1, min(100, int(quality)))
    with rasterio.open(output_path) as ds:
        scale = min(max_size / ds.width, max_size / ds.height, 1.0)
        out_w = max(1, int(round(ds.width * scale)))
        out_h = max(1, int(round(ds.height * scale)))
        preview = ds.read(
            indexes=[1, 2, 3],
            out_shape=(3, out_h, out_w),
            resampling=Resampling.bilinear,
        )
        rgb = np.moveaxis(preview, 0, 2)
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        preview_path.parent.mkdir(parents=True, exist_ok=True)
        ok = cv2.imwrite(str(preview_path), bgr, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
        if not ok:
            raise RuntimeError(f"Failed to write preview image: {preview_path}")


def run_mosaic(
    sources: Sequence[SourceInfo],
    reference: SourceInfo,
    output_path: Path,
    transform: Affine,
    width: int,
    height: int,
    args: argparse.Namespace,
) -> None:
    resampling = getattr(Resampling, args.resampling)
    profile = build_output_profile(reference, transform, width, height, args.compress)
    rgb_resampling_flag = {
        "nearest": cv2.INTER_NEAREST,
        "bilinear": cv2.INTER_LINEAR,
        "cubic": cv2.INTER_CUBIC,
    }[args.resampling]

    if output_path.exists() and args.overwrite:
        output_path.unlink()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    runtimes: List[SourceRuntime] = []
    try:
        for source in sources:
            src = rasterio.open(source.path)
            vrt = WarpedVRT(
                src,
                crs=reference.crs,
                transform=transform,
                width=width,
                height=height,
                resampling=resampling,
                add_alpha=True,
            )
            runtimes.append(
                SourceRuntime(
                    info=source,
                    dataset=src,
                    vrt=vrt,
                    pixel_matrix=identity_pixel_matrix(),
                )
            )

        reference_runtime = next(item for item in runtimes if item.info.path == reference.path)
        if args.register_mode != "none":
            for runtime in runtimes:
                if runtime.info.path == reference.path:
                    continue
                runtime.pixel_matrix = estimate_registration_pixel_matrix(
                    runtime.vrt,
                    reference_runtime.vrt,
                    runtime.info,
                    reference_runtime.info,
                    transform,
                    width,
                    height,
                    args,
                )

        total_windows = math.ceil(height / args.tile_size) * math.ceil(width / args.tile_size)
        with rasterio.open(output_path, "w", **profile) as dst:
            for index, window in enumerate(iter_windows(width, height, args.tile_size), start=1):
                win_h = int(window.height)
                win_w = int(window.width)
                mask = np.zeros((win_h, win_w), dtype=np.uint8)

                if args.method == "blend":
                    accum = np.zeros((3, win_h, win_w), dtype=np.float32)
                    weight_sum = np.zeros((win_h, win_w), dtype=np.float32)
                    for runtime in runtimes:
                        rgb, alpha = read_registered_window(
                            runtime,
                            window,
                            rgb_resampling_flag,
                            ignore_read_errors=args.ignore_read_errors,
                        )
                        if not np.any(alpha):
                            continue
                        valid_idx = np.where(alpha)
                        for band in range(3):
                            accum[band][valid_idx] += rgb[band][valid_idx].astype(np.float32)
                        weight_sum[valid_idx] += 1.0
                    mosaic = np.zeros((3, win_h, win_w), dtype=profile["dtype"])
                    valid = weight_sum > 0
                    if np.any(valid):
                        for band in range(3):
                            mosaic_band = np.zeros((win_h, win_w), dtype=np.float32)
                            mosaic_band[valid] = accum[band][valid] / weight_sum[valid]
                            mosaic[band] = np.clip(mosaic_band, 0, 255).astype(profile["dtype"])
                        mask[valid] = 255
                else:
                    mosaic = np.zeros((3, win_h, win_w), dtype=profile["dtype"])
                    filled = np.zeros((win_h, win_w), dtype=bool)

                    for runtime in runtimes:
                        rgb, alpha = read_registered_window(
                            runtime,
                            window,
                            rgb_resampling_flag,
                            ignore_read_errors=args.ignore_read_errors,
                        )

                        if args.method == "first":
                            use = (~filled) & alpha
                        else:
                            use = alpha

                        if not np.any(use):
                            continue

                        mosaic[:, use] = rgb[:, use]
                        mask[use] = 255
                        filled |= use

                dst.write(mosaic, window=window)
                dst.write_mask(mask, window=window)

                if index == 1 or index % 20 == 0 or index == total_windows:
                    print(
                        f"Processed window {index}/{total_windows} "
                        f"(row={int(window.row_off)}, col={int(window.col_off)})"
                    )
    finally:
        print_runtime_read_error_summary(runtimes)
        for runtime in runtimes:
            runtime.vrt.close()
            runtime.dataset.close()


def main() -> int:
    args = parse_args()
    start_time = time.time()

    input_dir = Path(args.input_dir).expanduser().resolve()
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Input directory does not exist: {input_dir}")

    output_path = (
        Path(args.output).expanduser().resolve()
        if args.output
        else input_dir / "GF2_truecolor_mosaic.tif"
    )
    preview_path = default_preview_path(output_path)
    if output_path.exists() and not args.overwrite and not args.dry_run:
        raise FileExistsError(f"Output already exists: {output_path}. Use --overwrite to replace it.")
    if preview_path.exists() and args.overwrite and not args.dry_run:
        preview_path.unlink()

    source_paths = discover_inputs(input_dir, args.pattern, output_path)
    sources = inspect_sources(source_paths)
    reference = choose_reference(sources, args.reference)
    transform, width, height, _ = compute_target_grid(sources, reference)
    print_plan(input_dir, output_path, preview_path, sources, reference, transform, width, height)

    if args.dry_run:
        print("Dry run only. No mosaic file was written.")
        return 0

    run_mosaic(sources, reference, output_path, transform, width, height, args)

    if not args.skip_crop:
        crop_output_to_data(output_path, args.tile_size)

    if args.build_overviews:
        print("Building overviews...")
        build_overviews(output_path)

    if not args.skip_preview:
        print("Writing preview image...")
        write_preview(output_path, preview_path, args.preview_max_size, args.preview_quality)

    print(f"Done in {(time.time() - start_time) / 60.0:.2f} minutes")
    print(f"Output: {output_path}")
    if not args.skip_preview:
        print(f"Preview: {preview_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
