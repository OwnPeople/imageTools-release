#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import os
import subprocess
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.transform import Affine
from rasterio.warp import calculate_default_transform, reproject
from rasterio.windows import Window


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rebuild a cleaner true-color image by orthorectifying PAN and MUX to the same grid before fusion."
    )
    parser.add_argument(
        "scene_dir",
        nargs="?",
        default=None,
        help="Image scene directory; if omitted, scan the current directory automatically",
    )
    parser.add_argument(
        "--dst-crs",
        default="EPSG:4326",
        help="Target CRS",
    )
    parser.add_argument("--warp-mem-mb", type=int, default=0, help="Warp cache in MB; 0 means auto")
    parser.add_argument(
        "--threads",
        type=int,
        default=0,
        help="Worker threads for GDAL warp and local image ops; 0 means auto",
    )
    parser.add_argument("--rows-per-block", type=int, default=0, help="Fusion block height; 0 means auto")
    parser.add_argument(
        "--fusion-method",
        choices=("pansharpen", "detail", "guided", "browse"),
        default="browse",
        help="Fusion mode; browse is the default and aims for the sharpest visual product",
    )
    parser.add_argument(
        "--alpha",
        type=float,
        default=1.0,
        help="Blend amount of the PAN-enhanced result; higher is sharper",
    )
    parser.add_argument("--denoise-sigma", type=float, default=0.05)
    parser.add_argument("--detail-sigma", type=float, default=0.4)
    parser.add_argument(
        "--output-tag",
        default="",
        help="Suffix used in output file names so multiple products can coexist",
    )
    parser.add_argument(
        "--out-dir-name",
        default="",
        help="Optional output folder name under the scene directory",
    )
    parser.add_argument("--dry-run", action="store_true", help="Only inspect inputs and planned outputs, do not start processing")
    parser.add_argument("--log-file", default="", help="Optional log file path; default is processed_truecolor/<output-name>.log")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--batch",
        action="store_true",
        help="Process every valid image scene directory under the given folder sequentially, one after another",
    )
    parser.add_argument(
        "--skip-overviews",
        action="store_true",
        help="Skip building overview pyramids to save time; GIS browsing may be slower until you build pyramids later",
    )
    parser.add_argument(
        "--keep-intermediates",
        action="store_true",
        help="Keep orthorectified PAN and MUX intermediate files",
    )
    parser.add_argument(
        "--compare-mode",
        action="store_true",
        help="Only generate a local comparison montage from a small sample crop instead of processing the full scene",
    )
    parser.add_argument(
        "--compare-window",
        default="auto",
        help="Comparison crop in output pixels: auto or x,y or x,y,size",
    )
    parser.add_argument(
        "--compare-size",
        type=int,
        default=768,
        help="Comparison crop size in output pixels when compare-window is auto or x,y",
    )
    parser.add_argument(
        "--compare-panel-size",
        type=int,
        default=512,
        help="Display size for each panel in the comparison montage",
    )
    parser.add_argument(
        "--test-blocks",
        type=int,
        default=0,
        help="Only fuse the first N output blocks for quick testing",
    )
    return parser.parse_args()


class Logger:
    def __init__(self, log_path: Path | None) -> None:
        self.log_path = log_path
        self._fh = None
        if log_path is not None:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            self._fh = log_path.open("w", encoding="utf-8")

    def log(self, message: str = "") -> None:
        print(message)
        if self._fh is not None:
            self._fh.write(message + "\n")
            self._fh.flush()

    def close(self) -> None:
        if self._fh is not None:
            self._fh.close()
            self._fh = None


def is_scene_dir(path: Path) -> bool:
    if not path.is_dir():
        return False
    pans = sorted(path.glob("*-BWDPAN.tiff"))
    muxes = sorted(path.glob("*-BWDMUX.tiff"))
    return len(pans) == 1 and len(muxes) == 1


def resolve_scene_dir(scene_arg: str | None) -> tuple[Path, str | None]:
    if scene_arg:
        candidate = Path(scene_arg).expanduser().resolve()
        if is_scene_dir(candidate):
            return candidate, None
        raise FileNotFoundError(
            f"{candidate} is not a valid image scene directory. "
            "It should contain one *-BWDPAN.tiff and one *-BWDMUX.tiff."
        )

    cwd = Path.cwd().resolve()
    if is_scene_dir(cwd):
        return cwd, "Auto-detected scene directory: current directory"

    candidates = sorted(path for path in cwd.iterdir() if is_scene_dir(path))
    if len(candidates) == 1:
        return candidates[0], f"Auto-detected scene directory: {candidates[0]}"
    if not candidates:
        raise FileNotFoundError(
            f"No image scene directory found under {cwd}. "
            "Run the script inside the scene folder, or inside a parent folder that contains exactly one scene folder."
        )
    names = "\n".join(f"  - {path}" for path in candidates)
    raise RuntimeError(
        "Found multiple image scene directories under the current directory. "
        "Please pass one explicitly:\n" + names
    )


def resolve_batch_root(scene_arg: str | None) -> Path:
    if scene_arg:
        return Path(scene_arg).expanduser().resolve()
    return Path.cwd().resolve()


def find_scene_dirs_under(root: Path) -> list[Path]:
    if is_scene_dir(root):
        return [root]
    if not root.is_dir():
        raise FileNotFoundError(f"{root} does not exist or is not a directory")
    return sorted(path for path in root.iterdir() if is_scene_dir(path))

def clean_tag(text: str) -> str:
    value = "".join(ch if ch.isalnum() or ch in ("-", "_") else "-" for ch in text.strip())
    value = value.strip("-_")
    return value or "clean"


def detect_total_ram_bytes() -> int | None:
    try:
        page_size = os.sysconf("SC_PAGE_SIZE")
        phys_pages = os.sysconf("SC_PHYS_PAGES")
        if page_size > 0 and phys_pages > 0:
            return int(page_size * phys_pages)
    except (AttributeError, OSError, ValueError):
        pass

    if sys.platform == "darwin":
        try:
            out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True).strip()
            value = int(out)
            if value > 0:
                return value
        except (subprocess.SubprocessError, ValueError):
            pass

    if sys.platform.startswith("linux"):
        try:
            with open("/proc/meminfo", "r", encoding="utf-8") as fh:
                for line in fh:
                    if line.startswith("MemTotal:"):
                        return int(line.split()[1]) * 1024
        except OSError:
            pass

    return None


def format_ram_gib(total_ram_bytes: int | None) -> str:
    if total_ram_bytes is None:
        return "unknown"
    return f"{total_ram_bytes / (1024 ** 3):.1f} GiB"


def auto_threads(cpu_count: int, total_ram_bytes: int | None) -> int:
    if total_ram_bytes is None:
        return min(4, max(1, cpu_count))
    ram_gib = total_ram_bytes / (1024 ** 3)
    if ram_gib <= 8:
        return min(2, cpu_count)
    if ram_gib <= 16:
        return min(4, cpu_count)
    if ram_gib <= 32:
        return min(6, cpu_count)
    return min(8, cpu_count)


def auto_warp_mem_mb(total_ram_bytes: int | None) -> int:
    if total_ram_bytes is None:
        return 768
    ram_gib = total_ram_bytes / (1024 ** 3)
    if ram_gib <= 8:
        return 512
    if ram_gib <= 16:
        return 1024
    if ram_gib <= 32:
        return 1536
    return 2048


def auto_rows_per_block(total_ram_bytes: int | None) -> int:
    if total_ram_bytes is None:
        return 512
    ram_gib = total_ram_bytes / (1024 ** 3)
    if ram_gib <= 8:
        return 256
    if ram_gib <= 16:
        return 512
    if ram_gib <= 32:
        return 768
    return 1024


def resolve_runtime_profile(args: argparse.Namespace) -> dict[str, object]:
    cpu_count = max(1, os.cpu_count() or 1)
    total_ram_bytes = detect_total_ram_bytes()
    threads = max(1, args.threads) if args.threads > 0 else auto_threads(cpu_count, total_ram_bytes)
    warp_mem_mb = max(128, args.warp_mem_mb) if args.warp_mem_mb > 0 else auto_warp_mem_mb(total_ram_bytes)
    rows_per_block = max(128, args.rows_per_block) if args.rows_per_block > 0 else auto_rows_per_block(total_ram_bytes)
    return {
        "cpu_count": cpu_count,
        "total_ram_bytes": total_ram_bytes,
        "threads": threads,
        "warp_mem_mb": warp_mem_mb,
        "rows_per_block": rows_per_block,
        "threads_auto": args.threads <= 0,
        "warp_mem_auto": args.warp_mem_mb <= 0,
        "rows_auto": args.rows_per_block <= 0,
    }


def resolve_output_tag(args: argparse.Namespace) -> str:
    if args.output_tag.strip():
        return clean_tag(args.output_tag)
    defaults = {
        "pansharpen": "clean",
        "detail": "detail",
        "guided": "guided-pan",
        "browse": "sharp-browse",
    }
    return defaults.get(args.fusion_method, "clean")


def resolve_out_dir_name(args: argparse.Namespace, output_tag: str) -> str:
    if args.out_dir_name.strip():
        return clean_tag(args.out_dir_name)
    defaults = {
        "clean": "processed_truecolor",
        "sharp-browse": "processed_truecolor_sharp_browse",
        "guided-pan": "processed_truecolor_guided_pan",
        "sharp-pan": "processed_truecolor_sharp_pan",
    }
    return defaults.get(output_tag, "processed_truecolor_variants")


def build_paths(scene_dir: Path, output_tag: str, out_dir_name: str) -> dict[str, Path]:
    name = scene_dir.name
    out_dir = scene_dir / clean_tag(out_dir_name)
    tag = clean_tag(output_tag)
    stem = f"{name}-truecolor-rgb-pan-rpc-ortho-wgs84-{tag}"
    return {
        "pan_src": scene_dir / f"{name}-BWDPAN.tiff",
        "mux_src": scene_dir / f"{name}-BWDMUX.tiff",
        "out_dir": out_dir,
        "pan_ortho": out_dir / f"{name}-BWDPAN-ortho-wgs84-{tag}-temp.tif",
        "mux_ortho": out_dir / f"{name}-BWDMUX-rgb-ortho-wgs84-{tag}-temp.tif",
        "final": out_dir / f"{stem}.tif",
        "preview": out_dir / f"{stem}-preview.jpg",
        "compare": out_dir / f"{stem}-compare-montage.jpg",
        "log": out_dir / f"{stem}.log",
    }


def sample_percentiles(ds: rasterio.io.DatasetReader, bands: list[int], q=(2.0, 98.0)) -> list[tuple[float, float]]:
    samples: list[list[np.ndarray]] = [[] for _ in bands]
    step_y = max(ds.height // 5, 1)
    step_x = max(ds.width // 5, 1)
    size = 256
    for cy in range(step_y // 2, ds.height, step_y):
        for cx in range(step_x // 2, ds.width, step_x):
            win = Window(min(max(cx - size // 2, 0), max(ds.width - size, 0)),
                         min(max(cy - size // 2, 0), max(ds.height - size, 0)),
                         min(size, ds.width), min(size, ds.height))
            arr = ds.read(bands, window=win)
            for idx in range(len(bands)):
                band = arr[idx]
                valid = band[band > 0]
                if valid.size:
                    samples[idx].append(valid[:: max(1, valid.size // 50000)])
    result: list[tuple[float, float]] = []
    for items in samples:
        vec = np.concatenate(items) if items else np.array([0, 1], dtype=np.float32)
        lo, hi = np.percentile(vec, q)
        result.append((float(lo), float(hi)))
    return result


def stretch_to_unit(arr: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return np.clip((arr.astype(np.float32) - lo) / max(hi - lo, 1.0), 0.0, 1.0)


def transform_close(a: Affine, b: Affine, tol: float = 1e-12) -> bool:
    return all(abs(x - y) <= tol for x, y in zip(a, b))


def dataset_has_signal(ds: rasterio.io.DatasetReader) -> bool:
    preview_h = min(256, max(32, ds.height))
    preview_w = min(256, max(32, ds.width))
    arr = ds.read(1, out_shape=(preview_h, preview_w), resampling=Resampling.average).astype(np.float32)
    valid = arr[arr > 0]
    if valid.size == 0:
        return False
    p02, p98 = np.percentile(valid, [2.0, 98.0])
    if np.issubdtype(np.dtype(ds.dtypes[0]), np.integer):
        return bool(p98 > 4.0 and p98 > p02 + 1.0)
    return bool(p98 > 0.01 and p98 > p02 + 0.005)


def stretch_rgb(rgb: np.ndarray, rgb_stats: list[tuple[float, float]]) -> np.ndarray:
    return np.stack(
        [stretch_to_unit(rgb[i], *rgb_stats[i]) for i in range(3)],
        axis=2,
    )


def rgb_luminance(rgb_norm: np.ndarray) -> np.ndarray:
    return 0.299 * rgb_norm[:, :, 0] + 0.587 * rgb_norm[:, :, 1] + 0.114 * rgb_norm[:, :, 2]


def match_pan_to_intensity(
    pan_norm: np.ndarray,
    pan_mean: float,
    pan_std: float,
    intensity_mean: float,
    intensity_std: float,
) -> np.ndarray:
    pan_matched = (pan_norm - pan_mean) * (intensity_std / pan_std) + intensity_mean
    return np.clip(pan_matched, 0.0, 1.0)


def apply_luminance_target(
    rgb_norm: np.ndarray,
    src_luma: np.ndarray,
    dst_luma: np.ndarray,
    valid: np.ndarray,
    min_ratio: float = 0.35,
    max_ratio: float = 2.60,
) -> np.ndarray:
    ratio = np.clip(dst_luma / np.maximum(src_luma, 0.03), min_ratio, max_ratio)
    out = np.clip(rgb_norm * ratio[:, :, None], 0.0, 1.0)
    out[~valid] = 0.0
    return out


def sample_fusion_stats(
    pan_ds: rasterio.io.DatasetReader,
    mux_ds: rasterio.io.DatasetReader,
    pan_lo: float,
    pan_hi: float,
    rgb_stats: list[tuple[float, float]],
) -> tuple[float, float, float, float]:
    pan_samples: list[np.ndarray] = []
    intensity_samples: list[np.ndarray] = []
    step_y = max(pan_ds.height // 5, 1)
    step_x = max(pan_ds.width // 5, 1)
    size = 256
    for cy in range(step_y // 2, pan_ds.height, step_y):
        for cx in range(step_x // 2, pan_ds.width, step_x):
            win = Window(
                min(max(cx - size // 2, 0), max(pan_ds.width - size, 0)),
                min(max(cy - size // 2, 0), max(pan_ds.height - size, 0)),
                min(size, pan_ds.width),
                min(size, pan_ds.height),
            )
            pan = pan_ds.read(1, window=win).astype(np.float32)
            rgb = mux_ds.read([1, 2, 3], window=win).astype(np.float32)
            pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)
            rgb_norm = stretch_rgb(rgb, rgb_stats)
            intensity = rgb_luminance(rgb_norm)
            valid = (pan > 0) & np.any(rgb > 0, axis=0)
            if not np.any(valid):
                continue
            pan_valid = pan_norm[valid]
            intensity_valid = intensity[valid]
            pan_samples.append(pan_valid[:: max(1, pan_valid.size // 50000)])
            intensity_samples.append(intensity_valid[:: max(1, intensity_valid.size // 50000)])

    if not pan_samples or not intensity_samples:
        return 0.5, 0.2, 0.5, 0.2

    pan_vec = np.concatenate(pan_samples)
    intensity_vec = np.concatenate(intensity_samples)
    pan_mean = float(np.mean(pan_vec))
    pan_std = float(np.std(pan_vec))
    intensity_mean = float(np.mean(intensity_vec))
    intensity_std = float(np.std(intensity_vec))
    return pan_mean, max(pan_std, 1e-6), intensity_mean, max(intensity_std, 1e-6)


def fuse_detail(
    pan: np.ndarray,
    rgb: np.ndarray,
    pan_lo: float,
    pan_hi: float,
    rgb_stats: list[tuple[float, float]],
    alpha: float,
    denoise_sigma: float,
    detail_sigma: float,
) -> np.ndarray:
    pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)
    rgb_norm = stretch_rgb(rgb, rgb_stats)
    pan_denoised = cv2.GaussianBlur(pan_norm, (0, 0), denoise_sigma)
    pan_base = cv2.GaussianBlur(pan_denoised, (0, 0), detail_sigma)
    detail = pan_denoised - pan_base
    weight = np.clip(rgb_norm.mean(axis=2), 0.15, 1.0)
    return np.clip(rgb_norm + alpha * detail[:, :, None] * weight[:, :, None], 0.0, 1.0)


def fuse_pansharpen(
    pan: np.ndarray,
    rgb: np.ndarray,
    pan_lo: float,
    pan_hi: float,
    rgb_stats: list[tuple[float, float]],
    alpha: float,
    denoise_sigma: float,
    detail_sigma: float,
    pan_mean: float,
    pan_std: float,
    intensity_mean: float,
    intensity_std: float,
) -> np.ndarray:
    pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)
    rgb_norm = stretch_rgb(rgb, rgb_stats)
    valid = (pan > 0) & np.any(rgb > 0, axis=0)
    if denoise_sigma > 0:
        pan_norm = cv2.GaussianBlur(pan_norm, (0, 0), denoise_sigma)

    intensity = rgb_luminance(rgb_norm)
    intensity_base = cv2.GaussianBlur(intensity, (0, 0), detail_sigma) if detail_sigma > 0 else intensity

    pan_matched = match_pan_to_intensity(pan_norm, pan_mean, pan_std, intensity_mean, intensity_std)
    ratio = pan_matched / np.maximum(intensity_base, 0.03)
    ratio = np.clip(ratio, 0.40, 2.20)

    rgb_sharp = np.clip(rgb_norm * ratio[:, :, None], 0.0, 1.0)
    weight = np.clip(intensity_base, 0.10, 1.0)
    blend = np.clip(alpha * weight, 0.0, 1.0)
    fused = rgb_norm * (1.0 - blend[:, :, None]) + rgb_sharp * blend[:, :, None]
    fused[~valid] = 0.0
    return np.clip(fused, 0.0, 1.0)


def fuse_edge_guided(
    pan: np.ndarray,
    rgb: np.ndarray,
    pan_lo: float,
    pan_hi: float,
    rgb_stats: list[tuple[float, float]],
    alpha: float,
    denoise_sigma: float,
    detail_sigma: float,
    pan_mean: float,
    pan_std: float,
    intensity_mean: float,
    intensity_std: float,
) -> np.ndarray:
    pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)
    rgb_norm = stretch_rgb(rgb, rgb_stats)
    valid = (pan > 0) & np.any(rgb > 0, axis=0)
    if denoise_sigma > 0:
        pan_norm = cv2.GaussianBlur(pan_norm, (0, 0), denoise_sigma)

    intensity = rgb_luminance(rgb_norm)
    pan_matched = match_pan_to_intensity(pan_norm, pan_mean, pan_std, intensity_mean, intensity_std)

    edge_space = max(2.0, detail_sigma * 10.0)
    sigma_color = max(0.04, 0.10 * alpha)
    pan_base = cv2.bilateralFilter(pan_matched.astype(np.float32), 9, sigma_color, edge_space)
    detail = pan_matched - pan_base
    weight = np.clip(intensity, 0.12, 1.0)
    target_luma = np.clip(intensity + alpha * detail * weight, 0.0, 1.0)
    return apply_luminance_target(rgb_norm, intensity, target_luma, valid, min_ratio=0.40, max_ratio=2.25)


def fuse_browse_sharp(
    pan: np.ndarray,
    rgb: np.ndarray,
    pan_lo: float,
    pan_hi: float,
    rgb_stats: list[tuple[float, float]],
    alpha: float,
    denoise_sigma: float,
    detail_sigma: float,
    pan_mean: float,
    pan_std: float,
    intensity_mean: float,
    intensity_std: float,
) -> np.ndarray:
    base = fuse_pansharpen(
        pan,
        rgb,
        pan_lo,
        pan_hi,
        rgb_stats,
        alpha,
        denoise_sigma,
        detail_sigma,
        pan_mean,
        pan_std,
        intensity_mean,
        intensity_std,
    )
    valid = (pan > 0) & np.any(rgb > 0, axis=0)
    base_luma = rgb_luminance(base)
    blur_sigma = max(0.35, detail_sigma * 1.4)
    luma_blur = cv2.GaussianBlur(base_luma, (0, 0), blur_sigma)
    luma_unsharp = np.clip(base_luma + 1.35 * (base_luma - luma_blur), 0.0, 1.0)

    pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)
    pan_matched = match_pan_to_intensity(pan_norm, pan_mean, pan_std, intensity_mean, intensity_std)
    browse_luma = np.clip(0.60 * luma_unsharp + 0.40 * pan_matched, 0.0, 1.0)
    return apply_luminance_target(base, base_luma, browse_luma, valid, min_ratio=0.35, max_ratio=2.80)


def orthorectify_to_grid(
    src_path: Path,
    dst_path: Path,
    bands: list[int],
    transform: Affine,
    width: int,
    height: int,
    dst_crs: str,
    rpc_height: float,
    warp_mem_mb: int,
    threads: int,
    overwrite: bool,
    log,
) -> None:
    if dst_path.exists():
        if overwrite:
            dst_path.unlink()
        else:
            with rasterio.open(dst_path) as existing:
                reusable = (
                    str(existing.crs) == str(dst_crs)
                    and existing.width == width
                    and existing.height == height
                    and existing.count == len(bands)
                    and transform_close(existing.transform, transform)
                    and dataset_has_signal(existing)
                )
            if reusable:
                log(f"Reuse existing intermediate: {dst_path}")
                return
            log(f"Rebuild intermediate with new grid/CRS or invalid content: {dst_path}")
            dst_path.unlink()

    with rasterio.open(src_path) as src:
        profile = {
            "driver": "GTiff",
            "width": width,
            "height": height,
            "count": len(bands),
            "dtype": src.dtypes[0],
            "crs": dst_crs,
            "transform": transform,
            "tiled": True,
            "blockxsize": 512,
            "blockysize": 512,
            "compress": "deflate",
            "predictor": 2,
            "BIGTIFF": "YES",
            "interleave": "pixel",
        }
        with rasterio.open(dst_path, "w", **profile) as dst:
            for out_idx, band in enumerate(bands, start=1):
                log(f"  warp {src_path.name} band {band} -> {dst_path.name} band {out_idx}")
                reproject(
                    source=rasterio.band(src, band),
                    destination=rasterio.band(dst, out_idx),
                    rpcs=src.rpcs,
                    src_crs=None,
                    dst_transform=transform,
                    dst_crs=dst_crs,
                    resampling=Resampling.cubic,
                    num_threads=threads,
                    warp_mem_limit=warp_mem_mb,
                    RPC_HEIGHT=rpc_height,
                    init_dest_nodata=True,
                    dst_nodata=0,
                )


def make_preview(src_path: Path, dst_path: Path) -> None:
    from PIL import Image

    with rasterio.open(src_path) as ds:
        data = ds.read(
            out_shape=(3, max(1, ds.height // 64), max(1, ds.width // 64)),
            resampling=Resampling.average,
        )
    Image.fromarray(data.transpose(1, 2, 0), "RGB").save(dst_path, quality=90)


def verify_output(output_path: Path, log) -> None:
    with rasterio.open(output_path) as ds:
        log("Verification:")
        log(f"  CRS:        {ds.crs}")
        log(f"  Size:       {ds.width} x {ds.height}")
        log(f"  Bands:      {ds.count}")
        log(f"  Dtype:      {', '.join(ds.dtypes)}")
        log(f"  Bounds:     {ds.bounds}")
        log(f"  Overviews:  {ds.overviews(1)}")


def auto_compare_window_from_preview(
    preview: np.ndarray,
    full_width: int,
    full_height: int,
    crop_size: int,
    log,
) -> Window:
    scan_h = preview.shape[1]
    scan_w = preview.shape[2]
    preview_rgb = np.transpose(preview, (1, 2, 0)).astype(np.float32)
    valid = preview_rgb.mean(axis=2) > 5
    gray = preview_rgb.mean(axis=2)
    gy, gx = np.gradient(gray)
    score = np.hypot(gx, gy)
    step = max(min(scan_h, scan_w) // 10, 80)
    best: tuple[float, int, int] | None = None
    for y in range(0, max(scan_h - step, 1), step):
        for x in range(0, max(scan_w - step, 1), step):
            win_valid = valid[y : y + step, x : x + step]
            if win_valid.size == 0 or float(win_valid.mean()) < 0.85:
                continue
            win_score = float(score[y : y + step, x : x + step].mean())
            if best is None or win_score > best[0]:
                best = (win_score, x + step // 2, y + step // 2)
    if best is None:
        x = max((full_width - crop_size) // 2, 0)
        y = max((full_height - crop_size) // 2, 0)
        log("  compare window fallback: center crop")
        return Window(x, y, min(crop_size, full_width), min(crop_size, full_height))

    _, cx, cy = best
    x = int(cx / scan_w * full_width - crop_size / 2)
    y = int(cy / scan_h * full_height - crop_size / 2)
    x = min(max(x, 0), max(full_width - crop_size, 0))
    y = min(max(y, 0), max(full_height - crop_size, 0))
    return Window(x, y, min(crop_size, full_width), min(crop_size, full_height))


def parse_compare_window(spec: str, width: int, height: int, compare_size: int, log) -> Window:
    value = spec.strip().lower()
    if value == "auto":
        raise ValueError("auto compare window must be resolved by auto_compare_window")
    parts = [part.strip() for part in spec.split(",") if part.strip()]
    if len(parts) not in (2, 3):
        raise ValueError("compare-window should be auto or x,y or x,y,size")
    x = int(parts[0])
    y = int(parts[1])
    size = int(parts[2]) if len(parts) == 3 else compare_size
    size = max(64, size)
    x = min(max(x, 0), max(width - size, 0))
    y = min(max(y, 0), max(height - size, 0))
    log(f"  compare window from args: x={x}, y={y}, size={size}")
    return Window(x, y, min(size, width), min(size, height))


def preset_signature(method: str, alpha: float, denoise_sigma: float, detail_sigma: float) -> tuple[str, float, float, float]:
    return (
        method,
        round(alpha, 4),
        round(denoise_sigma, 4),
        round(detail_sigma, 4),
    )


def compare_presets(args: argparse.Namespace) -> list[dict[str, object]]:
    presets: list[dict[str, object]] = [
        {"kind": "rgb", "label": "RGB Only", "subtitle": "upsampled MUX"},
        {
            "kind": "fusion",
            "label": "Balanced Pan",
            "subtitle": "pan a=0.88 dn=0.7 ds=1.2",
            "method": "pansharpen",
            "alpha": 0.88,
            "denoise_sigma": 0.7,
            "detail_sigma": 1.2,
        },
        {
            "kind": "fusion",
            "label": "Sharp Pan",
            "subtitle": "pan a=0.98 dn=0.15 ds=0.45",
            "method": "pansharpen",
            "alpha": 0.98,
            "denoise_sigma": 0.15,
            "detail_sigma": 0.45,
        },
        {
            "kind": "fusion",
            "label": "Edge Guided Pan",
            "subtitle": "guided a=0.92 dn=0.15 ds=0.8",
            "method": "guided",
            "alpha": 0.92,
            "denoise_sigma": 0.15,
            "detail_sigma": 0.8,
        },
        {
            "kind": "fusion",
            "label": "Image Merge",
            "subtitle": "browse a=1.00 dn=0.05 ds=0.4",
            "method": "browse",
            "alpha": 1.0,
            "denoise_sigma": 0.05,
            "detail_sigma": 0.4,
        },
        {"kind": "pan", "label": "PAN Ref", "subtitle": "grayscale reference"},
    ]
    current_sig = preset_signature(args.fusion_method, args.alpha, args.denoise_sigma, args.detail_sigma)
    known = {
        preset_signature(
            str(preset["method"]),
            float(preset["alpha"]),
            float(preset["denoise_sigma"]),
            float(preset["detail_sigma"]),
        )
        for preset in presets
        if preset["kind"] == "fusion"
    }
    if current_sig not in known:
        presets.insert(
            3,
            {
                "kind": "fusion",
                "label": "Current Args",
                "subtitle": f"{args.fusion_method} a={args.alpha:g} dn={args.denoise_sigma:g} ds={args.detail_sigma:g}",
                "method": args.fusion_method,
                "alpha": args.alpha,
                "denoise_sigma": args.denoise_sigma,
                "detail_sigma": args.detail_sigma,
            },
        )
    return presets


def to_rgb_panel(unit_rgb: np.ndarray) -> np.ndarray:
    return (np.clip(unit_rgb, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def to_pan_panel(unit_pan: np.ndarray) -> np.ndarray:
    arr = (np.clip(unit_pan, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
    return np.repeat(arr[:, :, None], 3, axis=2)


def window_transform(base_transform: Affine, window: Window) -> Affine:
    return base_transform * Affine.translation(window.col_off, window.row_off)


def reproject_array(
    src_path: Path,
    bands: list[int],
    dst_transform: Affine,
    width: int,
    height: int,
    dst_crs: str,
    rpc_height: float,
    warp_mem_mb: int,
    threads: int,
) -> np.ndarray:
    out = np.zeros((len(bands), height, width), dtype=np.float32)
    with rasterio.open(src_path) as src:
        for idx, band in enumerate(bands):
            reproject(
                source=rasterio.band(src, band),
                destination=out[idx],
                rpcs=src.rpcs,
                src_crs=None,
                dst_transform=dst_transform,
                dst_crs=dst_crs,
                resampling=Resampling.cubic,
                num_threads=threads,
                warp_mem_limit=warp_mem_mb,
                RPC_HEIGHT=rpc_height,
                init_dest_nodata=True,
                dst_nodata=0,
            )
    return out


def crop_percentiles(pan: np.ndarray, rgb: np.ndarray) -> tuple[tuple[float, float], list[tuple[float, float]]]:
    pan_valid = pan[pan > 0]
    if pan_valid.size:
        pan_lo, pan_hi = np.percentile(pan_valid, [2.0, 98.0])
    else:
        pan_lo, pan_hi = 0.0, 1.0
    rgb_stats: list[tuple[float, float]] = []
    for idx in range(3):
        valid = rgb[idx][rgb[idx] > 0]
        if valid.size:
            lo, hi = np.percentile(valid, [2.0, 98.0])
        else:
            lo, hi = 0.0, 1.0
        rgb_stats.append((float(lo), float(hi)))
    return (float(pan_lo), float(pan_hi)), rgb_stats


def crop_fusion_stats(
    pan: np.ndarray,
    rgb: np.ndarray,
    pan_lo: float,
    pan_hi: float,
    rgb_stats: list[tuple[float, float]],
) -> tuple[float, float, float, float]:
    valid = (pan > 0) & np.any(rgb > 0, axis=0)
    if not np.any(valid):
        return 0.5, 0.2, 0.5, 0.2
    pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)
    rgb_norm = stretch_rgb(rgb, rgb_stats)
    intensity = 0.299 * rgb_norm[:, :, 0] + 0.587 * rgb_norm[:, :, 1] + 0.114 * rgb_norm[:, :, 2]
    pan_vec = pan_norm[valid]
    intensity_vec = intensity[valid]
    return (
        float(np.mean(pan_vec)),
        max(float(np.std(pan_vec)), 1e-6),
        float(np.mean(intensity_vec)),
        max(float(np.std(intensity_vec)), 1e-6),
    )


def save_compare_montage(
    dst_path: Path,
    panels: list[tuple[str, str, np.ndarray]],
    panel_size: int,
    window: Window,
    log,
) -> None:
    from PIL import Image, ImageDraw

    cols = min(3, len(panels))
    rows = math.ceil(len(panels) / cols)
    header_h = 46
    title_h = 42
    canvas = Image.new("RGB", (cols * panel_size, title_h + rows * (panel_size + header_h)), "black")
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((0, 0, canvas.width, title_h), fill=(18, 18, 18))
    draw.text(
        (16, 12),
        f"Image merge sample compare  x={int(window.col_off)} y={int(window.row_off)} size={int(window.width)}",
        fill=(255, 255, 255),
    )

    for idx, (label, subtitle, panel) in enumerate(panels):
        col = idx % cols
        row = idx // cols
        x0 = col * panel_size
        y0 = title_h + row * (panel_size + header_h)
        panel_img = Image.fromarray(panel, "RGB").resize((panel_size, panel_size), Image.Resampling.LANCZOS)
        canvas.paste(panel_img, (x0, y0))
        draw.rectangle((x0, y0, x0 + panel_size, y0 + 34), fill=(0, 0, 0))
        draw.text((x0 + 10, y0 + 8), label, fill=(255, 255, 255))
        draw.rectangle((x0, y0 + panel_size, x0 + panel_size, y0 + panel_size + header_h), fill=(15, 15, 15))
        draw.text((x0 + 10, y0 + panel_size + 11), subtitle, fill=(210, 210, 210))

    canvas.save(dst_path, quality=92)
    log(f"Compare montage: {dst_path}")


def run_compare_mode(
    paths: dict[str, Path],
    args: argparse.Namespace,
    transform: Affine,
    width: int,
    height: int,
    rpc_height: float,
    log,
) -> None:
    log("Compare mode: local sample montage only")
    if args.compare_window.strip().lower() == "auto":
        preview_w = min(1200, max(400, width))
        preview_h = min(1200, max(400, height))
        preview_transform = transform * Affine.scale(width / preview_w, height / preview_h)
        preview = reproject_array(
            paths["mux_src"],
            [3, 2, 1],
            preview_transform,
            preview_w,
            preview_h,
            args.dst_crs,
            rpc_height,
            args.warp_mem_mb,
            args.threads,
        )
        window = auto_compare_window_from_preview(preview, width, height, args.compare_size, log)
        log(
            "  compare window auto-selected: "
            f"x={int(window.col_off)}, y={int(window.row_off)}, size={int(window.width)}"
        )
    else:
        window = parse_compare_window(args.compare_window, width, height, args.compare_size, log)

    crop_transform = window_transform(transform, window)
    pan = reproject_array(
        paths["pan_src"],
        [1],
        crop_transform,
        int(window.width),
        int(window.height),
        args.dst_crs,
        rpc_height,
        args.warp_mem_mb,
        args.threads,
    )[0]
    rgb = reproject_array(
        paths["mux_src"],
        [3, 2, 1],
        crop_transform,
        int(window.width),
        int(window.height),
        args.dst_crs,
        rpc_height,
        args.warp_mem_mb,
        args.threads,
    )
    (pan_lo, pan_hi), rgb_stats = crop_percentiles(pan, rgb)
    pan_mean, pan_std, intensity_mean, intensity_std = crop_fusion_stats(
        pan,
        rgb,
        pan_lo,
        pan_hi,
        rgb_stats,
    )
    log(f"  PAN stretch: {pan_lo:.1f} - {pan_hi:.1f}")
    log("  RGB stretch: " + ", ".join(f"{lo:.1f}-{hi:.1f}" for lo, hi in rgb_stats))
    rgb_norm = stretch_rgb(rgb, rgb_stats)
    pan_norm = stretch_to_unit(pan, pan_lo, pan_hi)

    panels: list[tuple[str, str, np.ndarray]] = []
    for preset in compare_presets(args):
        kind = str(preset["kind"])
        if kind == "rgb":
            panel = to_rgb_panel(rgb_norm)
        elif kind == "pan":
            panel = to_pan_panel(pan_norm)
        elif str(preset["method"]) == "pansharpen":
            fused = fuse_pansharpen(
                pan,
                rgb,
                pan_lo,
                pan_hi,
                rgb_stats,
                float(preset["alpha"]),
                float(preset["denoise_sigma"]),
                float(preset["detail_sigma"]),
                pan_mean,
                pan_std,
                intensity_mean,
                intensity_std,
            )
            panel = to_rgb_panel(fused)
        elif str(preset["method"]) == "guided":
            fused = fuse_edge_guided(
                pan,
                rgb,
                pan_lo,
                pan_hi,
                rgb_stats,
                float(preset["alpha"]),
                float(preset["denoise_sigma"]),
                float(preset["detail_sigma"]),
                pan_mean,
                pan_std,
                intensity_mean,
                intensity_std,
            )
            panel = to_rgb_panel(fused)
        elif str(preset["method"]) == "browse":
            fused = fuse_browse_sharp(
                pan,
                rgb,
                pan_lo,
                pan_hi,
                rgb_stats,
                float(preset["alpha"]),
                float(preset["denoise_sigma"]),
                float(preset["detail_sigma"]),
                pan_mean,
                pan_std,
                intensity_mean,
                intensity_std,
            )
            panel = to_rgb_panel(fused)
        else:
            fused = fuse_detail(
                pan,
                rgb,
                pan_lo,
                pan_hi,
                rgb_stats,
                float(preset["alpha"]),
                float(preset["denoise_sigma"]),
                float(preset["detail_sigma"]),
            )
            panel = to_rgb_panel(fused)
        panels.append((str(preset["label"]), str(preset["subtitle"]), panel))

    save_compare_montage(paths["compare"], panels, args.compare_panel_size, window, log)


def process_scene(
    scene_dir: Path,
    args: argparse.Namespace,
    runtime: dict[str, object],
    detected_message: str | None = None,
) -> int:
    output_tag = resolve_output_tag(args)
    out_dir_name = resolve_out_dir_name(args, output_tag)
    paths = build_paths(scene_dir, output_tag, out_dir_name)
    paths["out_dir"].mkdir(parents=True, exist_ok=True)
    log_path = Path(args.log_file).expanduser().resolve() if args.log_file else paths["log"]
    logger = Logger(log_path)
    log = logger.log
    if detected_message:
        log(detected_message)
    log(f"Scene dir:    {scene_dir}")
    log(f"Output dir:   {paths['out_dir']}")
    log(f"Output tag:   {output_tag}")
    log(f"Log file:     {log_path}")
    log(f"CPU cores:    {runtime['cpu_count']}")
    log(f"Total RAM:    {format_ram_gib(runtime['total_ram_bytes'])}")

    for key in ("pan_src", "mux_src"):
        if not paths[key].exists():
            logger.close()
            raise FileNotFoundError(paths[key])

    log(f"PAN source:   {paths['pan_src']}")
    log(f"MUX source:   {paths['mux_src']}")
    log(f"Final output: {paths['final']}")
    log(f"Preview:      {paths['preview']}")
    log(f"Compare out:  {paths['compare']}")
    log(f"Keep temps:   {args.keep_intermediates}")
    log(f"Overwrite:    {args.overwrite}")
    log(f"Warp mem MB:  {args.warp_mem_mb}")
    log(f"Threads:      {args.threads}")
    log(f"Rows/block:   {args.rows_per_block}")
    log(
        "Auto tune:    "
        f"threads={'yes' if runtime['threads_auto'] else 'no'}, "
        f"warp_mem={'yes' if runtime['warp_mem_auto'] else 'no'}, "
        f"rows={'yes' if runtime['rows_auto'] else 'no'}"
    )
    log(f"Fusion mode:  {args.fusion_method}")
    log(f"Alpha:        {args.alpha}")
    log(f"Denoise s:    {args.denoise_sigma}")
    log(f"Detail s:     {args.detail_sigma}")
    log(f"Skip ovr:     {args.skip_overviews}")
    log(f"Compare mode: {args.compare_mode}")
    log(f"Compare win:  {args.compare_window}")
    log(f"Compare size: {args.compare_size}")

    if args.dry_run:
        log("")
        log("Dry run only. No processing started.")
        logger.close()
        return 0

    if (not args.compare_mode) and paths["final"].exists():
        if not args.overwrite:
            logger.close()
            raise FileExistsError(f"{paths['final']} exists. Re-run with --overwrite.")
        paths["final"].unlink()

    cv2.setNumThreads(max(1, args.threads))

    with rasterio.open(paths["pan_src"]) as pan_src, rasterio.open(paths["mux_src"]) as mux_src:
        rpc_height = float((pan_src.rpcs.height_off + mux_src.rpcs.height_off) / 2.0)
        transform, width, height = calculate_default_transform(
            None,
            args.dst_crs,
            pan_src.width,
            pan_src.height,
            rpcs=pan_src.rpcs,
            RPC_HEIGHT=rpc_height,
        )

    log(f"Target grid: {width} x {height}")
    log(f"Target CRS:  {args.dst_crs}")
    log(f"RPC height:  {rpc_height:.3f}")

    if args.compare_mode:
        with rasterio.Env(GDAL_NUM_THREADS=str(max(1, args.threads)), GDAL_CACHEMAX=args.warp_mem_mb):
            run_compare_mode(
                paths,
                args,
                transform,
                width,
                height,
                rpc_height,
                log,
            )
        logger.close()
        return 0

    with rasterio.Env(GDAL_NUM_THREADS=str(max(1, args.threads)), GDAL_CACHEMAX=args.warp_mem_mb):
        log("Step 1/3: orthorectify PAN to target grid")
        orthorectify_to_grid(
            paths["pan_src"],
            paths["pan_ortho"],
            [1],
            transform,
            width,
            height,
            args.dst_crs,
            rpc_height,
            args.warp_mem_mb,
            args.threads,
            args.overwrite,
            log,
        )

        log("Step 2/3: orthorectify MUX RGB to the same grid")
        orthorectify_to_grid(
            paths["mux_src"],
            paths["mux_ortho"],
            [3, 2, 1],
            transform,
            width,
            height,
            args.dst_crs,
            rpc_height,
            args.warp_mem_mb,
            args.threads,
            args.overwrite,
            log,
        )

        log("Step 3/3: fuse aligned PAN and MUX")
        with rasterio.open(paths["pan_ortho"]) as pan_ds, rasterio.open(paths["mux_ortho"]) as mux_ds:
            pan_lo, pan_hi = sample_percentiles(pan_ds, [1])[0]
            rgb_stats = sample_percentiles(mux_ds, [1, 2, 3])
            pan_mean, pan_std, intensity_mean, intensity_std = sample_fusion_stats(
                pan_ds,
                mux_ds,
                pan_lo,
                pan_hi,
                rgb_stats,
            )
            log(f"  PAN stretch: {pan_lo:.1f} - {pan_hi:.1f}")
            log("  RGB stretch: " + ", ".join(f"{lo:.1f}-{hi:.1f}" for lo, hi in rgb_stats))
            log(f"  PAN mean/std: {pan_mean:.4f} / {pan_std:.4f}")
            log(f"  Int mean/std: {intensity_mean:.4f} / {intensity_std:.4f}")

            profile = mux_ds.profile.copy()
            profile.update(
                driver="GTiff",
                dtype="uint8",
                count=3,
                tiled=True,
                blockxsize=512,
                blockysize=512,
                compress="deflate",
                predictor=2,
                BIGTIFF="YES",
                photometric="RGB",
                interleave="pixel",
            )
            start = time.time()
            with rasterio.open(paths["final"], "w", **profile) as dst:
                total_blocks = math.ceil(height / args.rows_per_block)
                if args.test_blocks > 0:
                    total_blocks = min(total_blocks, args.test_blocks)
                for block_idx in range(total_blocks):
                    row_off = block_idx * args.rows_per_block
                    win_h = min(args.rows_per_block, height - row_off)
                    win = Window(0, row_off, width, win_h)

                    pan = pan_ds.read(1, window=win).astype(np.float32)
                    rgb = mux_ds.read([1, 2, 3], window=win).astype(np.float32)

                    if args.fusion_method == "pansharpen":
                        rgb_clean = fuse_pansharpen(
                            pan,
                            rgb,
                            pan_lo,
                            pan_hi,
                            rgb_stats,
                            args.alpha,
                            args.denoise_sigma,
                            args.detail_sigma,
                            pan_mean,
                            pan_std,
                            intensity_mean,
                            intensity_std,
                        )
                    elif args.fusion_method == "guided":
                        rgb_clean = fuse_edge_guided(
                            pan,
                            rgb,
                            pan_lo,
                            pan_hi,
                            rgb_stats,
                            args.alpha,
                            args.denoise_sigma,
                            args.detail_sigma,
                            pan_mean,
                            pan_std,
                            intensity_mean,
                            intensity_std,
                        )
                    elif args.fusion_method == "browse":
                        rgb_clean = fuse_browse_sharp(
                            pan,
                            rgb,
                            pan_lo,
                            pan_hi,
                            rgb_stats,
                            args.alpha,
                            args.denoise_sigma,
                            args.detail_sigma,
                            pan_mean,
                            pan_std,
                            intensity_mean,
                            intensity_std,
                        )
                    else:
                        rgb_clean = fuse_detail(
                            pan,
                            rgb,
                            pan_lo,
                            pan_hi,
                            rgb_stats,
                            args.alpha,
                            args.denoise_sigma,
                            args.detail_sigma,
                        )

                    dst.write((rgb_clean * 255.0 + 0.5).astype(np.uint8).transpose(2, 0, 1), window=win)

                    if block_idx % 16 == 0 or block_idx + 1 == total_blocks:
                        elapsed = (time.time() - start) / 60.0
                        log(f"  fuse block {block_idx + 1}/{total_blocks} ({elapsed:.1f} min)")

                if args.test_blocks == 0 and not args.skip_overviews:
                    log("  building overviews [2, 4, 8, 16]")
                    dst.build_overviews([2, 4, 8, 16], Resampling.average)
                    dst.update_tags(ns="rio_overview", resampling="average")
                if args.test_blocks == 0:
                    dst.update_tags(
                        ORTHO_METHOD="PAN and MUX co-orthorectified to a common grid before fusion",
                        FUSION_METHOD=(
                            "Adaptive intensity-ratio pansharpen with PAN histogram matching"
                            if args.fusion_method == "pansharpen"
                            else (
                                "Edge-guided luminance injection with bilateral PAN base separation"
                                if args.fusion_method == "guided"
                                else (
                                    "Browse-oriented sharp luminance fusion with PAN-guided unsharp enhancement"
                                    if args.fusion_method == "browse"
                                    else "Conservative Gaussian detail injection"
                                )
                            )
                        ),
                        RPC_HEIGHT_USED=str(rpc_height),
                        SOURCE_PAN=paths["pan_src"].name,
                        SOURCE_MUX=paths["mux_src"].name,
                    )

    make_preview(paths["final"], paths["preview"])
    verify_output(paths["final"], log)

    if not args.keep_intermediates and args.test_blocks == 0:
        for key in ("pan_ortho", "mux_ortho"):
            try:
                paths[key].unlink()
            except FileNotFoundError:
                pass

    log("")
    log(f"Clean output:  {paths['final']}")
    log(f"Preview:       {paths['preview']}")
    logger.close()
    return 0


def main() -> int:
    args = parse_args()
    runtime = resolve_runtime_profile(args)
    args.threads = int(runtime["threads"])
    args.warp_mem_mb = int(runtime["warp_mem_mb"])
    args.rows_per_block = int(runtime["rows_per_block"])

    if args.batch:
        if args.log_file:
            raise ValueError("--log-file cannot be used together with --batch; each scene writes its own log")
        root = resolve_batch_root(args.scene_dir)
        scene_dirs = find_scene_dirs_under(root)
        if not scene_dirs:
            raise FileNotFoundError(
                f"No image scene directories found under {root}. "
                "A valid scene directory should contain one *-BWDPAN.tiff and one *-BWDMUX.tiff."
            )
        print(f"Batch root:    {root}")
        print(f"Scene count:   {len(scene_dirs)}")
        for index, scene_dir in enumerate(scene_dirs, start=1):
            print("")
            print(f"[{index}/{len(scene_dirs)}] Start: {scene_dir.name}")
            process_scene(scene_dir, args, runtime, detected_message=None)
            print(f"[{index}/{len(scene_dirs)}] Done:  {scene_dir.name}")
        return 0

    scene_dir, detected_message = resolve_scene_dir(args.scene_dir)
    return process_scene(scene_dir, args, runtime, detected_message=detected_message)


if __name__ == "__main__":
    raise SystemExit(main())
