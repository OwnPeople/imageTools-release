#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.windows import Window


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Post-process a mosaic with low-frequency color balancing and small black-hole filling."
    )
    parser.add_argument("input", help="Input RGB GeoTIFF")
    parser.add_argument("--output", default="", help="Optional full-resolution output GeoTIFF")
    parser.add_argument(
        "--preview-input",
        default="",
        help="Optional existing preview JPG/PNG to use for estimating color field and writing preview faster",
    )
    parser.add_argument(
        "--preview-output",
        default="",
        help="Preview JPG output; default is <input>_colorfill_preview.jpg",
    )
    parser.add_argument(
        "--comparison-output",
        default="",
        help="Optional side-by-side comparison JPG output",
    )
    parser.add_argument("--preview-max-size", type=int, default=2400)
    parser.add_argument("--preview-quality", type=int, default=92)
    parser.add_argument("--valid-threshold", type=int, default=2)
    parser.add_argument("--strength", type=float, default=0.35, help="Color-balance strength from 0 to 1")
    parser.add_argument("--blur-sigma", type=float, default=55.0, help="Low-res Gaussian sigma for color field")
    parser.add_argument("--max-offset", type=float, default=36.0, help="Clamp per-channel offset")
    parser.add_argument(
        "--preview-hole-max-area",
        type=int,
        default=24000,
        help="Largest black component to fill in preview pixels",
    )
    parser.add_argument(
        "--preview-hole-max-span",
        type=int,
        default=260,
        help="Largest black component width/height to fill in preview pixels",
    )
    parser.add_argument(
        "--full-hole-max-area",
        type=int,
        default=2800000,
        help="Largest black component to fill in full-resolution pixels",
    )
    parser.add_argument(
        "--full-hole-max-span",
        type=int,
        default=2200,
        help="Largest black component width/height to fill in full-resolution pixels",
    )
    parser.add_argument("--inpaint-radius", type=float, default=5.0)
    parser.add_argument(
        "--hole-min-fill-ratio",
        type=float,
        default=0.65,
        help="Fill only compact components whose area/(bbox area) is at least this ratio",
    )
    parser.add_argument("--tile-size", type=int, default=2048)
    parser.add_argument("--pad", type=int, default=256)
    parser.add_argument("--compress", choices=("lzw", "deflate"), default="lzw")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--skip-preview", action="store_true")
    return parser.parse_args()


def default_preview_path(input_path: Path) -> Path:
    return input_path.with_name(f"{input_path.stem}_colorfill_preview.jpg")


def default_comparison_path(input_path: Path) -> Path:
    return input_path.with_name(f"{input_path.stem}_colorfill_compare.jpg")


def valid_mask(rgb_hwc: np.ndarray, threshold: int) -> np.ndarray:
    return np.any(rgb_hwc > threshold, axis=2)


def small_hole_mask(
    valid: np.ndarray,
    max_area: int,
    max_span: int,
    allow_border: bool,
    min_fill_ratio: float,
) -> np.ndarray:
    invalid = (~valid).astype(np.uint8)
    if int(invalid.sum()) == 0:
        return np.zeros(valid.shape, dtype=bool)

    count, labels, stats, _ = cv2.connectedComponentsWithStats(invalid, connectivity=8)
    holes = np.zeros(valid.shape, dtype=bool)
    h, w = valid.shape
    for label in range(1, count):
        x = int(stats[label, cv2.CC_STAT_LEFT])
        y = int(stats[label, cv2.CC_STAT_TOP])
        bw = int(stats[label, cv2.CC_STAT_WIDTH])
        bh = int(stats[label, cv2.CC_STAT_HEIGHT])
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area <= 0 or area > max_area:
            continue
        if bw > max_span or bh > max_span:
            continue
        fill_ratio = area / float(max(1, bw * bh))
        if fill_ratio < float(min_fill_ratio):
            continue
        touches_border = x == 0 or y == 0 or x + bw >= w or y + bh >= h
        if touches_border and not allow_border:
            continue
        holes |= labels == label
    return holes


def fill_holes(rgb_hwc: np.ndarray, holes: np.ndarray, radius: float) -> np.ndarray:
    if not np.any(holes):
        return rgb_hwc
    mask = (holes.astype(np.uint8)) * 255
    return cv2.inpaint(rgb_hwc, mask, float(radius), cv2.INPAINT_TELEA)


def compute_offset_map(
    rgb_hwc: np.ndarray,
    valid: np.ndarray,
    sigma: float,
    strength: float,
    max_offset: float,
) -> np.ndarray:
    if int(valid.sum()) < 1000:
        return np.zeros(rgb_hwc.shape, dtype=np.float32)

    rgbf = rgb_hwc.astype(np.float32)
    maskf = valid.astype(np.float32)
    target = np.median(rgbf[valid], axis=0).astype(np.float32)

    blur_mask = cv2.GaussianBlur(maskf, (0, 0), sigmaX=sigma, sigmaY=sigma, borderType=cv2.BORDER_REPLICATE)
    blur_mask = np.maximum(blur_mask, 1e-4)

    local = np.zeros_like(rgbf)
    for band in range(3):
        numerator = cv2.GaussianBlur(
            rgbf[:, :, band] * maskf,
            (0, 0),
            sigmaX=sigma,
            sigmaY=sigma,
            borderType=cv2.BORDER_REPLICATE,
        )
        local[:, :, band] = numerator / blur_mask

    offset = (target[None, None, :] - local) * float(strength)
    offset = np.clip(offset, -float(max_offset), float(max_offset)).astype(np.float32)
    offset[~valid] = 0.0
    return offset


def apply_offset(rgb_hwc: np.ndarray, valid: np.ndarray, offset: np.ndarray) -> np.ndarray:
    out = rgb_hwc.astype(np.float32) + offset
    out[~valid] = rgb_hwc[~valid]
    return np.clip(out, 0, 255).astype(np.uint8)


def read_preview(ds, max_size: int) -> tuple[np.ndarray, float]:
    scale = min(max_size / float(ds.width), max_size / float(ds.height), 1.0)
    out_w = max(1, int(round(ds.width * scale)))
    out_h = max(1, int(round(ds.height * scale)))
    data = ds.read([1, 2, 3], out_shape=(3, out_h, out_w), resampling=Resampling.bilinear)
    return np.moveaxis(data, 0, 2), scale


def postprocess_preview(rgb: np.ndarray, args: argparse.Namespace) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    valid = valid_mask(rgb, args.valid_threshold)
    holes = small_hole_mask(
        valid,
        max_area=args.preview_hole_max_area,
        max_span=args.preview_hole_max_span,
        allow_border=False,
        min_fill_ratio=args.hole_min_fill_ratio,
    )
    filled = fill_holes(rgb, holes, args.inpaint_radius)
    valid_after = valid | holes
    offset = compute_offset_map(
        filled,
        valid_after,
        sigma=args.blur_sigma,
        strength=args.strength,
        max_offset=args.max_offset,
    )
    processed = apply_offset(filled, valid_after, offset)
    return processed, holes, offset


def write_jpg(path: Path, rgb: np.ndarray, quality: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    ok = cv2.imwrite(str(path), bgr, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    if not ok:
        raise RuntimeError(f"Failed to write {path}")


def label(rgb: np.ndarray, text: str) -> np.ndarray:
    out = rgb.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
    return out


def make_comparison(original: np.ndarray, processed: np.ndarray, holes: np.ndarray) -> np.ndarray:
    hole_vis = original.copy()
    hole_vis[holes] = np.array([255, 60, 40], dtype=np.uint8)
    tiles = [label(original, "original"), label(processed, "color balanced + filled"), label(hole_vis, "filled holes marked red")]
    max_h = max(tile.shape[0] for tile in tiles)
    padded = []
    for tile in tiles:
        if tile.shape[0] < max_h:
            pad = np.zeros((max_h - tile.shape[0], tile.shape[1], 3), dtype=np.uint8)
            tile = np.vstack([tile, pad])
        padded.append(tile)
    return np.hstack(padded)


def iter_windows(width: int, height: int, tile_size: int) -> Iterable[Window]:
    for row in range(0, height, tile_size):
        for col in range(0, width, tile_size):
            yield Window(col, row, min(tile_size, width - col), min(tile_size, height - row))


def padded_window(window: Window, width: int, height: int, pad: int) -> tuple[Window, tuple[int, int, int, int]]:
    col0 = max(0, int(window.col_off) - pad)
    row0 = max(0, int(window.row_off) - pad)
    col1 = min(width, int(window.col_off + window.width) + pad)
    row1 = min(height, int(window.row_off + window.height) + pad)
    padded = Window(col0, row0, col1 - col0, row1 - row0)
    top = int(window.row_off) - row0
    left = int(window.col_off) - col0
    bottom = top + int(window.height)
    right = left + int(window.width)
    return padded, (top, bottom, left, right)


def resize_offset_for_window(offset: np.ndarray, window: Window, full_width: int, full_height: int) -> np.ndarray:
    low_h, low_w = offset.shape[:2]
    col0 = max(0, int(math.floor(window.col_off * low_w / full_width)) - 2)
    row0 = max(0, int(math.floor(window.row_off * low_h / full_height)) - 2)
    col1 = min(low_w, int(math.ceil((window.col_off + window.width) * low_w / full_width)) + 2)
    row1 = min(low_h, int(math.ceil((window.row_off + window.height) * low_h / full_height)) + 2)
    crop = offset[row0:row1, col0:col1]
    return cv2.resize(crop, (int(window.width), int(window.height)), interpolation=cv2.INTER_LINEAR)


def write_full_output(input_path: Path, output_path: Path, low_offset: np.ndarray, args: argparse.Namespace) -> None:
    if output_path.exists():
        if not args.overwrite:
            raise FileExistsError(f"Output exists: {output_path}. Use --overwrite to replace it.")
        output_path.unlink()

    with rasterio.open(input_path) as src:
        profile = src.profile.copy()
        profile.update(
            driver="GTiff",
            count=3,
            dtype="uint8",
            compress=args.compress,
            tiled=True,
            blockxsize=512,
            blockysize=512,
            BIGTIFF="YES",
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        total = math.ceil(src.width / args.tile_size) * math.ceil(src.height / args.tile_size)
        with rasterio.open(output_path, "w", **profile) as dst:
            for index, window in enumerate(iter_windows(src.width, src.height, args.tile_size), start=1):
                padded, crop = padded_window(window, src.width, src.height, args.pad)
                data = src.read([1, 2, 3], window=padded)
                rgb_pad = np.moveaxis(data, 0, 2)
                valid_pad = valid_mask(rgb_pad, args.valid_threshold)
                holes_pad = small_hole_mask(
                    valid_pad,
                    max_area=args.full_hole_max_area,
                    max_span=args.full_hole_max_span,
                    allow_border=False,
                    min_fill_ratio=args.hole_min_fill_ratio,
                )
                filled_pad = fill_holes(rgb_pad, holes_pad, args.inpaint_radius)
                top, bottom, left, right = crop
                rgb = filled_pad[top:bottom, left:right]
                valid = valid_mask(rgb, args.valid_threshold)
                offset = resize_offset_for_window(low_offset, window, src.width, src.height)
                out = apply_offset(rgb, valid, offset)
                dst.write(np.moveaxis(out, 2, 0), window=window)
                dst.write_mask((valid.astype(np.uint8)) * 255, window=window)
                if index == 1 or index % 50 == 0 or index == total:
                    print(f"Processed window {index}/{total} row={int(window.row_off)} col={int(window.col_off)}")


def main() -> int:
    args = parse_args()
    input_path = Path(args.input).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError(input_path)

    preview_path = Path(args.preview_output).expanduser() if args.preview_output else default_preview_path(input_path)
    comparison_path = Path(args.comparison_output).expanduser() if args.comparison_output else default_comparison_path(input_path)

    if args.preview_input:
        preview_input = Path(args.preview_input).expanduser().resolve()
        bgr = cv2.imread(str(preview_input), cv2.IMREAD_COLOR)
        if bgr is None:
            raise RuntimeError(f"Failed to read preview input: {preview_input}")
        preview = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        with rasterio.open(input_path) as ds:
            scale = min(preview.shape[1] / float(ds.width), preview.shape[0] / float(ds.height))
    else:
        with rasterio.open(input_path) as ds:
            preview, scale = read_preview(ds, args.preview_max_size)

    processed_preview, holes, low_offset = postprocess_preview(preview, args)
    print(f"Preview scale: {scale:.6f}")
    print(f"Preview filled hole pixels: {int(holes.sum())}")
    print(f"Offset range: {float(low_offset.min()):.2f} .. {float(low_offset.max()):.2f}")

    if not args.skip_preview:
        write_jpg(preview_path, processed_preview, args.preview_quality)
        write_jpg(comparison_path, make_comparison(preview, processed_preview, holes), args.preview_quality)
        print(f"Preview: {preview_path}")
        print(f"Comparison: {comparison_path}")

    if args.output:
        output_path = Path(args.output).expanduser().resolve()
        write_full_output(input_path, output_path, low_offset, args)
        print(f"Full output: {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
