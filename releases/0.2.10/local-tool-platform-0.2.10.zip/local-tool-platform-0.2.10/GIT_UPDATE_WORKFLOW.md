# Git 自动更新流程

这条流程最简单：服务器只维护 Git 仓库，客户端启动时自动拉代码。

## 服务器

在服务器上建一个 Git 仓库，只放工具代码，不放影像数据。

开发机改完代码后：

```bash
git add .
git commit -m "更新工具"
git push origin main
```

## 客户端第一次安装

客户端机器只需要能访问 Git 仓库：

```bash
git clone git@你的服务器:tool-platform.git
cd tool-platform/tool_platform
./bootstrap_setup.sh
./run_platform.sh
```

如果客户端没有 Python，`bootstrap_setup.sh` 会自动下载独立 Python。

## 客户端以后启动

直接运行：

```bash
cd tool-platform/tool_platform
./run_platform.sh
```

启动时会自动：

1. 检查 `origin/main` 是否有新代码
2. 如果本地没有改过代码，就 `git pull --ff-only`
3. 如果代码更新了，就自动刷新 `.venv` 依赖
4. 启动网页平台

网页里不会要求用户手动检查更新，只会显示最近一次启动更新日志。

## 可选配置

默认更新 `origin/当前分支`。

如果要指定分支：

```bash
GIT_BRANCH=main ./run_platform.sh
```

如果要临时关闭自动更新：

```bash
AUTO_GIT_UPDATE=0 ./run_platform.sh
```

如果远程名不是 `origin`：

```bash
GIT_REMOTE=server ./run_platform.sh
```

## 注意

如果客户端本地改过代码，自动更新会跳过，避免覆盖本地修改。正常用户机器不要改代码，只放任务数据和运行日志。

`tool_platform/runtime/`、`.venv/`、影像文件和输出文件都不应该进 Git。
