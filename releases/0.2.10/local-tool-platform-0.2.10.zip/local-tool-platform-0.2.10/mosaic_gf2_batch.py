#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import cv2
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.windows import Window

from mosaic_gf2_geotiffs import (
    SourceInfo,
    SourceRuntime,
    bounds_to_window,
    build_output_profile,
    build_overviews,
    choose_reference,
    compute_target_grid,
    crop_output_to_data,
    default_preview_path,
    discover_inputs,
    estimate_registration_pixel_matrix,
    identity_pixel_matrix,
    inspect_sources,
    iter_windows,
    mask_black_background,
    print_plan,
    print_runtime_read_error_summary,
    prepare_gray_for_matching,
    read_registered_window,
    source_bounds_in_target_crs,
    write_preview,
    choose_feature_detector,
)


@dataclass
class PairEdge:
    a: int
    b: int
    overlap_area_px: int
    overlap_window: Window


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Batch mosaic all GeoTIFF files in a folder by chaining registration along overlap relationships."
    )
    parser.add_argument(
        "input_dir",
        nargs="?",
        default="/Users/jun/Documents/map/高分2号镶嵌测试",
        help="Folder containing source tif/tiff files",
    )
    parser.add_argument(
        "--output",
        default="",
        help="Output mosaic path; default is <input_dir>/<folder_name>_mosaic_batch.tif",
    )
    parser.add_argument(
        "--pattern",
        default="*.tif",
        help="Input glob pattern inside input_dir",
    )
    parser.add_argument(
        "--filename-prefix",
        default="",
        help="Only include TIFF files whose names start with this prefix; default is empty, meaning merge all TIFFs in the folder",
    )
    parser.add_argument(
        "--reference",
        default="auto",
        help="Reference grid source: auto, finest, or an exact input filename",
    )
    parser.add_argument(
        "--register-mode",
        choices=("none", "translation", "affine"),
        default="affine",
        help="Estimate image-space registration for every non-reference scene using the strongest overlap chain",
    )
    parser.add_argument(
        "--register-max-size",
        type=int,
        default=2800,
        help="Longest side of the overlap sample used for automatic registration",
    )
    parser.add_argument(
        "--resampling",
        choices=("nearest", "bilinear", "cubic"),
        default="bilinear",
        help="Resampling used when aligning onto the target grid",
    )
    parser.add_argument(
        "--method",
        choices=("first", "last", "blend", "feather"),
        default="blend",
        help="Overlap rule in the final mosaic",
    )
    parser.add_argument(
        "--feather-width",
        type=int,
        default=1800,
        help="Feather transition width in pixels when method=feather",
    )
    parser.add_argument(
        "--seam-register",
        action="store_true",
        help="Before feathering, estimate a bounded translation from overlap strips and apply it to later sources",
    )
    parser.add_argument(
        "--seam-register-max-shift",
        type=float,
        default=96.0,
        help="Maximum local seam translation in output pixels",
    )
    parser.add_argument(
        "--seam-register-band",
        type=int,
        default=2400,
        help="Width in output pixels sampled near an existing-source boundary for local seam registration",
    )
    parser.add_argument(
        "--seam-register-max-size",
        type=int,
        default=2200,
        help="Longest side of the downsampled seam-registration sample",
    )
    parser.add_argument(
        "--seam-color-match",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Locally match color inside the feather band before blending",
    )
    parser.add_argument(
        "--seam-color-match-strength",
        type=float,
        default=0.55,
        help="Strength of local seam color correction from 0 to 1",
    )
    parser.add_argument(
        "--seam-color-match-max-offset",
        type=float,
        default=32.0,
        help="Maximum per-channel local seam offset in 8-bit values",
    )
    parser.add_argument(
        "--seam-color-match-gain-strength",
        type=float,
        default=0.20,
        help="Strength of robust local seam contrast matching from 0 to 1",
    )
    parser.add_argument(
        "--seam-color-match-max-gain-delta",
        type=float,
        default=0.16,
        help="Maximum local seam gain change before strength is applied",
    )
    parser.add_argument(
        "--seam-color-match-min-pixels",
        type=int,
        default=1600,
        help="Minimum overlap pixels needed before estimating a local seam color correction",
    )
    parser.add_argument(
        "--seam-color-match-new-side",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Apply the local seam correction just outside the overlap and taper it away from the edge",
    )
    parser.add_argument(
        "--min-overlap-pixels",
        type=int,
        default=512,
        help="Minimum overlap width and height in output pixels for two scenes to be considered neighbors",
    )
    parser.add_argument(
        "--tile-size",
        type=int,
        default=1024,
        help="Processing tile size in output pixels",
    )
    parser.add_argument(
        "--compress",
        choices=("lzw", "deflate"),
        default="lzw",
        help="GeoTIFF compression",
    )
    parser.add_argument(
        "--ignore-read-errors",
        action="store_true",
        help="If a source tile cannot be decoded, treat that source window as empty instead of aborting the whole run",
    )
    parser.add_argument(
        "--build-overviews",
        action="store_true",
        help="Build overview pyramids after writing the mosaic",
    )
    parser.add_argument(
        "--skip-preview",
        action="store_true",
        help="Do not create a JPEG preview after the mosaic finishes",
    )
    parser.add_argument(
        "--preview-max-size",
        type=int,
        default=2400,
        help="Longest side of the JPEG preview in pixels",
    )
    parser.add_argument(
        "--preview-quality",
        type=int,
        default=90,
        help="JPEG preview quality from 1 to 100",
    )
    parser.add_argument(
        "--skip-crop",
        action="store_true",
        help="Do not crop empty outer borders after mosaicking",
    )
    parser.add_argument(
        "--allow-disconnected",
        action="store_true",
        help="Allow scenes without any overlap chain to the reference; they will be left unregistered",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite the output if it already exists",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only print the batch plan, do not write the output",
    )
    return parser.parse_args()


def default_output_path(input_dir: Path) -> Path:
    return input_dir / f"{input_dir.name}_mosaic_batch.tif"


def is_generated_artifact(path: Path) -> bool:
    name = path.name.lower()
    return (
        "truecolor_mosaic" in name
        or name.endswith("_cropped_tmp.tif")
        or name.endswith("_cropped.tif")
    )


def matches_filename_prefix(path: Path, prefix: str) -> bool:
    if not prefix:
        return True
    return path.name.upper().startswith(prefix.upper())


def estimate_required_free_bytes(
    sources: Sequence[SourceInfo],
    width: int,
    height: int,
    args: argparse.Namespace,
) -> int:
    input_total = sum(source.path.stat().st_size for source in sources)
    base_output = width * height * 4
    estimated = max(int(input_total * 1.5), int(base_output * 0.45))
    if not args.skip_crop:
        estimated += max(int(input_total * 0.8), int(base_output * 0.20))
    if args.build_overviews:
        estimated += max(int(input_total * 0.15), int(base_output * 0.05))
    return estimated


def format_gib(num_bytes: int) -> str:
    return f"{num_bytes / (1024 ** 3):.1f} GiB"


def check_free_space_or_raise(output_path: Path, required_bytes: int) -> None:
    usage = shutil.disk_usage(output_path.parent)
    print(f"Disk free:      {format_gib(usage.free)}")
    print(f"Estimated need: {format_gib(required_bytes)}")
    if usage.free < required_bytes:
        raise RuntimeError(
            "Not enough free disk space for this mosaic run. "
            f"Free {format_gib(usage.free)}, estimated required {format_gib(required_bytes)}."
        )


def pair_overlap_window(
    source_a: SourceInfo,
    source_b: SourceInfo,
    target_crs: object,
    target_transform,
    width: int,
    height: int,
) -> Window | None:
    left_a, bottom_a, right_a, top_a = source_bounds_in_target_crs(source_a, target_crs)
    left_b, bottom_b, right_b, top_b = source_bounds_in_target_crs(source_b, target_crs)
    overlap = (
        max(left_a, left_b),
        max(bottom_a, bottom_b),
        min(right_a, right_b),
        min(top_a, top_b),
    )
    if overlap[0] >= overlap[2] or overlap[1] >= overlap[3]:
        return None
    window = bounds_to_window(overlap, target_transform, width, height)
    if window.width <= 0 or window.height <= 0:
        return None
    return window


def build_pair_edges(
    sources: Sequence[SourceInfo],
    target_crs: object,
    target_transform,
    width: int,
    height: int,
    min_overlap_pixels: int,
) -> List[PairEdge]:
    edges: List[PairEdge] = []
    for index_a in range(len(sources)):
        for index_b in range(index_a + 1, len(sources)):
            overlap_window = pair_overlap_window(
                sources[index_a],
                sources[index_b],
                target_crs,
                target_transform,
                width,
                height,
            )
            if overlap_window is None:
                continue
            if overlap_window.width < min_overlap_pixels or overlap_window.height < min_overlap_pixels:
                continue
            overlap_area_px = int(overlap_window.width * overlap_window.height)
            edges.append(
                PairEdge(
                    a=index_a,
                    b=index_b,
                    overlap_area_px=overlap_area_px,
                    overlap_window=overlap_window,
                )
            )
    edges.sort(key=lambda item: item.overlap_area_px, reverse=True)
    return edges


def build_registration_tree(
    sources: Sequence[SourceInfo],
    edges: Sequence[PairEdge],
    reference_index: int,
    allow_disconnected: bool,
) -> Tuple[Dict[int, int], List[int]]:
    parent_map: Dict[int, int] = {reference_index: reference_index}
    visited = {reference_index}
    adjacency: Dict[int, List[PairEdge]] = {index: [] for index in range(len(sources))}
    for edge in edges:
        adjacency[edge.a].append(edge)
        adjacency[edge.b].append(edge)

    while len(visited) < len(sources):
        best_edge = None
        best_child = None
        best_parent = None
        for parent_index in list(visited):
            for edge in adjacency[parent_index]:
                child_index = edge.b if edge.a == parent_index else edge.a
                if child_index in visited:
                    continue
                if best_edge is None or edge.overlap_area_px > best_edge.overlap_area_px:
                    best_edge = edge
                    best_child = child_index
                    best_parent = parent_index
        if best_edge is None or best_child is None or best_parent is None:
            remaining = sorted(set(range(len(sources))) - visited)
            if allow_disconnected:
                return parent_map, remaining
            names = ", ".join(sources[index].path.name for index in remaining)
            raise RuntimeError(
                "Some scenes are disconnected from the reference and cannot be reliably registered: "
                + names
                + ". Remove them from this batch, or rerun with --allow-disconnected if you accept using raw georeferencing for those scenes."
            )
        parent_map[best_child] = best_parent
        visited.add(best_child)

    return parent_map, []


def compose_affine(parent_matrix: np.ndarray, child_to_parent_matrix: np.ndarray) -> np.ndarray:
    parent_h = np.vstack([parent_matrix, np.array([0.0, 0.0, 1.0], dtype=np.float32)])
    child_h = np.vstack([child_to_parent_matrix, np.array([0.0, 0.0, 1.0], dtype=np.float32)])
    combined = parent_h @ child_h
    return combined[:2].astype(np.float32)


def print_pair_summary(edges: Sequence[PairEdge], sources: Sequence[SourceInfo]) -> None:
    print("Overlap graph:")
    if not edges:
        print("  - no valid overlap edges found")
        return
    for edge in edges:
        print(
            "  - "
            f"{sources[edge.a].path.name} <-> {sources[edge.b].path.name} | "
            f"overlap={int(edge.overlap_window.width)}x{int(edge.overlap_window.height)} px"
        )


def create_runtimes(
    sources: Sequence[SourceInfo],
    target_crs: object,
    target_transform,
    width: int,
    height: int,
    resampling: Resampling,
) -> List[SourceRuntime]:
    runtimes: List[SourceRuntime] = []
    for source in sources:
        dataset = rasterio.open(source.path)
        vrt = WarpedVRT(
            dataset,
            crs=target_crs,
            transform=target_transform,
            width=width,
            height=height,
            resampling=resampling,
            add_alpha=True,
        )
        runtimes.append(
            SourceRuntime(
                info=source,
                dataset=dataset,
                vrt=vrt,
                pixel_matrix=identity_pixel_matrix(),
            )
        )
    return runtimes


def close_runtimes(runtimes: Sequence[SourceRuntime]) -> None:
    for runtime in runtimes:
        runtime.vrt.close()
        runtime.dataset.close()


def apply_registration_tree(
    runtimes: Sequence[SourceRuntime],
    parent_map: Dict[int, int],
    reference_index: int,
    target_transform,
    width: int,
    height: int,
    args: argparse.Namespace,
) -> None:
    pending = set(parent_map.keys()) - {reference_index}
    resolved = {reference_index}

    while pending:
        progress = False
        for child_index in list(pending):
            parent_index = parent_map[child_index]
            if parent_index not in resolved:
                continue
            child_runtime = runtimes[child_index]
            parent_runtime = runtimes[parent_index]
            child_to_parent = estimate_registration_pixel_matrix(
                child_runtime.vrt,
                parent_runtime.vrt,
                child_runtime.info,
                parent_runtime.info,
                target_transform,
                width,
                height,
                args,
            )
            child_runtime.pixel_matrix = compose_affine(parent_runtime.pixel_matrix, child_to_parent)
            print(
                f"Global matrix for {child_runtime.info.path.name}: "
                f"{np.array2string(child_runtime.pixel_matrix, precision=6, suppress_small=False)}"
            )
            resolved.add(child_index)
            pending.remove(child_index)
            progress = True
        if not progress:
            unresolved_names = ", ".join(runtimes[index].info.path.name for index in sorted(pending))
            raise RuntimeError("Could not resolve registration tree for: " + unresolved_names)


def overlap_window_for_pair(
    source: SourceInfo,
    reference: SourceInfo,
    target_crs: object,
    target_transform,
    width: int,
    height: int,
) -> Window | None:
    src_left, src_bottom, src_right, src_top = source_bounds_in_target_crs(source, target_crs)
    ref_left, ref_bottom, ref_right, ref_top = source_bounds_in_target_crs(reference, target_crs)
    overlap_bounds = (
        max(src_left, ref_left),
        max(src_bottom, ref_bottom),
        min(src_right, ref_right),
        min(src_top, ref_top),
    )
    left, bottom, right, top = overlap_bounds
    if left >= right or bottom >= top:
        return None
    window = bounds_to_window(overlap_bounds, target_transform, width, height)
    if window.width <= 0 or window.height <= 0:
        return None
    return window


def read_seam_registration_sample(
    runtime: SourceRuntime,
    window: Window,
    out_h: int,
    out_w: int,
) -> tuple[np.ndarray, np.ndarray] | None:
    try:
        data = runtime.vrt.read(
            indexes=[1, 2, 3, 4],
            window=window,
            out_shape=(4, out_h, out_w),
            resampling=Resampling.bilinear,
        )
    except Exception as exc:
        print(f"Seam registration sample failed for {runtime.info.path.name}; skip this pair. ({exc})")
        return None
    alpha = mask_black_background(data[:3], data[3] > 0)
    if not np.any(alpha):
        return None
    return np.moveaxis(data[:3], 0, 2), alpha


def estimate_local_seam_translation(
    source_runtime: SourceRuntime,
    reference_runtime: SourceRuntime,
    target_crs: object,
    target_transform,
    width: int,
    height: int,
    args: argparse.Namespace,
) -> tuple[np.ndarray, int, float] | None:
    sample_window = overlap_window_for_pair(
        source_runtime.info,
        reference_runtime.info,
        target_crs,
        target_transform,
        width,
        height,
    )
    if sample_window is None:
        return None

    max_size = max(256, int(getattr(args, "seam_register_max_size", 2200)))
    scale = min(max_size / max(float(sample_window.width), float(sample_window.height)), 1.0)
    out_h = max(1, int(round(sample_window.height * scale)))
    out_w = max(1, int(round(sample_window.width * scale)))

    source_sample = read_seam_registration_sample(source_runtime, sample_window, out_h, out_w)
    reference_sample = read_seam_registration_sample(reference_runtime, sample_window, out_h, out_w)
    if source_sample is None or reference_sample is None:
        return None

    source_rgb, source_alpha = source_sample
    reference_rgb, reference_alpha = reference_sample
    common = source_alpha & reference_alpha
    if int(common.sum()) < 4000:
        return None

    seam_band = max(64.0, float(getattr(args, "seam_register_band", 2400)) * scale)
    ref_dist = cv2.distanceTransform((reference_alpha.astype(np.uint8)) * 255, cv2.DIST_L2, 3)
    seam_mask = common & (ref_dist <= seam_band)
    if int(seam_mask.sum()) < 3000:
        seam_mask = common

    ys, xs = np.where(seam_mask)
    if ys.size < 3000:
        return None
    pad = 24
    y0 = max(0, int(ys.min()) - pad)
    y1 = min(out_h, int(ys.max()) + pad + 1)
    x0 = max(0, int(xs.min()) - pad)
    x1 = min(out_w, int(xs.max()) + pad + 1)

    source_crop_alpha = seam_mask[y0:y1, x0:x1]
    reference_crop_alpha = seam_mask[y0:y1, x0:x1]
    source_gray = prepare_gray_for_matching(source_rgb[y0:y1, x0:x1], source_crop_alpha)
    reference_gray = prepare_gray_for_matching(reference_rgb[y0:y1, x0:x1], reference_crop_alpha)

    detector, norm_type, detector_name = choose_feature_detector()
    kp_source, des_source = detector.detectAndCompute(source_gray, None)
    kp_ref, des_ref = detector.detectAndCompute(reference_gray, None)
    if des_source is None or des_ref is None or len(kp_source) < 20 or len(kp_ref) < 20:
        print(
            f"Seam registration skipped for {source_runtime.info.path.name}: "
            f"{detector_name} found too few features against {reference_runtime.info.path.name}."
        )
        return None

    matcher = cv2.BFMatcher(norm_type)
    raw_matches = matcher.knnMatch(des_source, des_ref, k=2)
    deltas = []
    for pair in raw_matches:
        if len(pair) < 2:
            continue
        match_a, match_b = pair
        if match_a.distance >= 0.78 * match_b.distance:
            continue
        sx, sy = kp_source[match_a.queryIdx].pt
        rx, ry = kp_ref[match_a.trainIdx].pt
        deltas.append((rx - sx, ry - sy))

    if len(deltas) < 24:
        print(
            f"Seam registration skipped for {source_runtime.info.path.name}: "
            f"only {len(deltas)} reliable local matches against {reference_runtime.info.path.name}."
        )
        return None

    delta_np = np.asarray(deltas, dtype=np.float32)
    median = np.median(delta_np, axis=0)
    residual = np.linalg.norm(delta_np - median, axis=1)
    mad = float(np.median(residual))
    keep = residual <= max(3.0, 3.0 * mad)
    if int(keep.sum()) < 18:
        return None

    refined = np.median(delta_np[keep], axis=0)
    dx = float(refined[0] / scale)
    dy = float(refined[1] / scale)
    shift = math.hypot(dx, dy)
    max_shift = float(getattr(args, "seam_register_max_shift", 96.0))
    if shift > max_shift:
        print(
            f"Seam registration rejected for {source_runtime.info.path.name}: "
            f"shift=({dx:.2f}, {dy:.2f}) px exceeds limit {max_shift:.1f} px."
        )
        return None

    matrix = np.array([[1.0, 0.0, dx], [0.0, 1.0, dy]], dtype=np.float32)
    return matrix, int(keep.sum()), shift


def apply_local_seam_registration(
    runtimes: Sequence[SourceRuntime],
    target_crs: object,
    target_transform,
    width: int,
    height: int,
    args: argparse.Namespace,
) -> None:
    if not getattr(args, "seam_register", False) or len(runtimes) < 2:
        return

    placed: List[SourceRuntime] = []
    for runtime in runtimes:
        if not placed:
            placed.append(runtime)
            continue

        candidates = []
        for reference_runtime in placed:
            result = estimate_local_seam_translation(
                runtime,
                reference_runtime,
                target_crs,
                target_transform,
                width,
                height,
                args,
            )
            if result is None:
                continue
            matrix, inlier_count, shift = result
            candidates.append((inlier_count, -shift, reference_runtime, matrix, shift))

        if not candidates:
            print(f"Seam registration: keep raw georeferencing for {runtime.info.path.name}.")
            placed.append(runtime)
            continue

        _, _, reference_runtime, matrix, shift = max(candidates, key=lambda item: (item[0], item[1]))
        runtime.pixel_matrix = compose_affine(matrix, runtime.pixel_matrix)
        print(
            f"Seam registration for {runtime.info.path.name} against {reference_runtime.info.path.name}: "
            f"shift=({matrix[0, 2]:.2f}, {matrix[1, 2]:.2f}) px, norm={shift:.2f}"
        )
        placed.append(runtime)


def robust_seam_color_adjustment(
    source_values: np.ndarray,
    target_values: np.ndarray,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray] | None:
    min_pixels = int(getattr(args, "seam_color_match_min_pixels", 512))
    if source_values.shape[1] < min_pixels:
        return None

    src = source_values.astype(np.float32)
    dst = target_values.astype(np.float32)
    src_p10, src_p50, src_p90 = np.percentile(src, [10.0, 50.0, 90.0], axis=1)
    dst_p10, dst_p50, dst_p90 = np.percentile(dst, [10.0, 50.0, 90.0], axis=1)

    gain_strength = float(getattr(args, "seam_color_match_gain_strength", 0.35))
    max_gain_delta = float(getattr(args, "seam_color_match_max_gain_delta", 0.16))
    src_span = np.maximum(src_p90 - src_p10, 1.0)
    dst_span = np.maximum(dst_p90 - dst_p10, 1.0)
    raw_gain = np.clip(dst_span / src_span, 1.0 - max_gain_delta, 1.0 + max_gain_delta)
    gain = 1.0 + (raw_gain - 1.0) * gain_strength

    strength = float(getattr(args, "seam_color_match_strength", 0.85))
    max_offset = float(getattr(args, "seam_color_match_max_offset", 48.0))
    raw_offset = dst_p50 - src_p50 * gain
    offset = np.clip(raw_offset, -max_offset, max_offset) * strength
    gain = 1.0 + (gain - 1.0) * strength
    return gain.astype(np.float32), offset.astype(np.float32)


def apply_color_adjustment(values: np.ndarray, adjustment: tuple[np.ndarray, np.ndarray]) -> np.ndarray:
    gain, offset = adjustment
    adjusted = values.astype(np.float32) * gain[:, None] + offset[:, None]
    return np.clip(adjusted, 0, 255)


def run_batch_mosaic(
    runtimes: Sequence[SourceRuntime],
    reference: SourceInfo,
    output_path: Path,
    transform,
    width: int,
    height: int,
    args: argparse.Namespace,
) -> None:
    profile = build_output_profile(reference, transform, width, height, args.compress)
    rgb_resampling_flag = {
        "nearest": cv2.INTER_NEAREST,
        "bilinear": cv2.INTER_LINEAR,
        "cubic": cv2.INTER_CUBIC,
    }[args.resampling]

    if output_path.exists() and args.overwrite:
        output_path.unlink()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    apply_local_seam_registration(runtimes, reference.crs, transform, width, height, args)

    total_windows = math.ceil(height / args.tile_size) * math.ceil(width / args.tile_size)
    with rasterio.open(output_path, "w", **profile) as dst:
        for index, window in enumerate(iter_windows(width, height, args.tile_size), start=1):
            win_h = int(window.height)
            win_w = int(window.width)
            mask = np.zeros((win_h, win_w), dtype=np.uint8)

            if args.method == "blend":
                accum = np.zeros((3, win_h, win_w), dtype=np.float32)
                weight_sum = np.zeros((win_h, win_w), dtype=np.float32)
                for runtime in runtimes:
                    rgb, alpha = read_registered_window(
                        runtime,
                        window,
                        rgb_resampling_flag,
                        ignore_read_errors=args.ignore_read_errors,
                    )
                    if not np.any(alpha):
                        continue
                    valid_idx = np.where(alpha)
                    for band in range(3):
                        accum[band][valid_idx] += rgb[band][valid_idx].astype(np.float32)
                    weight_sum[valid_idx] += 1.0
                mosaic = np.zeros((3, win_h, win_w), dtype=profile["dtype"])
                valid = weight_sum > 0
                if np.any(valid):
                    for band in range(3):
                        band_data = np.zeros((win_h, win_w), dtype=np.float32)
                        band_data[valid] = accum[band][valid] / weight_sum[valid]
                        mosaic[band] = np.clip(band_data, 0, 255).astype(profile["dtype"])
                    mask[valid] = 255
            elif args.method in ("first", "last"):
                mosaic = np.zeros((3, win_h, win_w), dtype=profile["dtype"])
                filled = np.zeros((win_h, win_w), dtype=bool)
                for runtime in runtimes:
                    rgb, alpha = read_registered_window(
                        runtime,
                        window,
                        rgb_resampling_flag,
                        ignore_read_errors=args.ignore_read_errors,
                    )
                    if args.method == "first":
                        use = (~filled) & alpha
                    else:
                        use = alpha
                    if not np.any(use):
                        continue
                    mosaic[:, use] = rgb[:, use]
                    mask[use] = 255
                    filled |= use
            else:
                mosaic = np.zeros((3, win_h, win_w), dtype=np.float32)
                filled = np.zeros((win_h, win_w), dtype=bool)
                feather_width = max(8.0, float(getattr(args, "feather_width", 192)))
                for runtime in runtimes:
                    rgb, alpha = read_registered_window(
                        runtime,
                        window,
                        rgb_resampling_flag,
                        ignore_read_errors=args.ignore_read_errors,
                    )
                    if not np.any(alpha):
                        continue

                    previous_filled = filled.copy()
                    new_only = (~previous_filled) & alpha
                    if np.any(new_only):
                        mosaic[:, new_only] = rgb[:, new_only].astype(np.float32)
                        mask[new_only] = 255
                        filled[new_only] = True

                    overlap = previous_filled & alpha
                    if not np.any(overlap):
                        continue

                    previous_u8 = (previous_filled.astype(np.uint8)) * 255
                    dist_existing = cv2.distanceTransform(previous_u8, cv2.DIST_L2, 3)
                    blend_zone = overlap & (dist_existing < feather_width)
                    adjustment = None

                    if np.any(blend_zone):
                        # Keep the existing mosaic as the primary image and only
                        # cross-fade near the boundary where new data fills a gap.
                        t_new = (1.0 - np.clip(dist_existing[blend_zone] / feather_width, 0.0, 1.0)).astype(np.float32)
                        src = rgb[:, blend_zone].astype(np.float32)
                        dst_vals = mosaic[:, blend_zone]
                        if getattr(args, "seam_color_match", True):
                            adjustment = robust_seam_color_adjustment(src, dst_vals, args)
                            if adjustment is not None:
                                src = apply_color_adjustment(src, adjustment)
                        mosaic[:, blend_zone] = dst_vals * (1.0 - t_new) + src * t_new

                    if (
                        adjustment is not None
                        and np.any(new_only)
                        and getattr(args, "seam_color_match_new_side", True)
                    ):
                        outside_previous_u8 = ((~previous_filled).astype(np.uint8)) * 255
                        dist_to_existing = cv2.distanceTransform(outside_previous_u8, cv2.DIST_L2, 3)
                        new_side_zone = new_only & (dist_to_existing < feather_width)
                        if np.any(new_side_zone):
                            t_adjust = (
                                1.0 - np.clip(dist_to_existing[new_side_zone] / feather_width, 0.0, 1.0)
                            ).astype(np.float32)
                            raw_new = mosaic[:, new_side_zone]
                            adjusted_new = apply_color_adjustment(raw_new, adjustment)
                            mosaic[:, new_side_zone] = raw_new * (1.0 - t_adjust) + adjusted_new * t_adjust

                    mask[alpha] = 255
                    filled |= alpha

                mosaic = np.clip(mosaic, 0, 255).astype(profile["dtype"])

            dst.write(mosaic, window=window)
            dst.write_mask(mask, window=window)
            if index == 1 or index % 20 == 0 or index == total_windows:
                print(
                    f"Processed window {index}/{total_windows} "
                    f"(row={int(window.row_off)}, col={int(window.col_off)})"
                )


def main() -> int:
    args = parse_args()
    start_time = time.time()

    input_dir = Path(args.input_dir).expanduser().resolve()
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Input directory does not exist: {input_dir}")

    output_path = Path(args.output).expanduser().resolve() if args.output else default_output_path(input_dir)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    preview_path = default_preview_path(output_path)
    if output_path.exists() and not args.overwrite and not args.dry_run:
        raise FileExistsError(f"Output already exists: {output_path}. Use --overwrite to replace it.")
    if preview_path.exists() and args.overwrite and not args.dry_run:
        preview_path.unlink()

    source_paths = [
        path
        for path in discover_inputs(input_dir, args.pattern, output_path)
        if not is_generated_artifact(path) and matches_filename_prefix(path, args.filename_prefix)
    ]
    if len(source_paths) < 2:
        prefix_note = f" and prefix {args.filename_prefix!r}" if args.filename_prefix else ""
        raise FileNotFoundError(
            f"Need at least two source TIFF files under {input_dir} after filtering generated artifacts "
            f"{prefix_note}."
        )
    sources = inspect_sources(source_paths)
    reference = choose_reference(sources, args.reference)
    reference_index = next(index for index, item in enumerate(sources) if item.path == reference.path)
    transform, width, height, target_crs = compute_target_grid(sources, reference)
    edges = build_pair_edges(sources, target_crs, transform, width, height, args.min_overlap_pixels)

    print_plan(input_dir, output_path, preview_path, sources, reference, transform, width, height)
    print_pair_summary(edges, sources)
    required_bytes = estimate_required_free_bytes(sources, width, height, args)
    check_free_space_or_raise(output_path, required_bytes)
    parent_map, disconnected = build_registration_tree(sources, edges, reference_index, args.allow_disconnected)
    print("Registration tree:")
    for child_index, parent_index in sorted(parent_map.items()):
        if child_index == parent_index:
            print(f"  - {sources[child_index].path.name} (reference)")
        else:
            print(f"  - {sources[child_index].path.name} <- {sources[parent_index].path.name}")
    if disconnected:
        print("Disconnected scenes:")
        for index in disconnected:
            print(f"  - {sources[index].path.name}")

    if args.dry_run:
        print("Dry run only. No mosaic file was written.")
        return 0

    resampling = getattr(Resampling, args.resampling)
    runtimes = create_runtimes(sources, target_crs, transform, width, height, resampling)
    try:
        apply_registration_tree(runtimes, parent_map, reference_index, transform, width, height, args)
        run_batch_mosaic(runtimes, reference, output_path, transform, width, height, args)
    finally:
        print_runtime_read_error_summary(runtimes)
        close_runtimes(runtimes)

    if not args.skip_crop:
        crop_output_to_data(output_path, args.tile_size)

    if args.build_overviews:
        print("Building overviews...")
        build_overviews(output_path)

    if not args.skip_preview:
        print("Writing preview image...")
        write_preview(output_path, preview_path, args.preview_max_size, args.preview_quality)

    print(f"Done in {(time.time() - start_time) / 60.0:.2f} minutes")
    print(f"Output: {output_path}")
    if not args.skip_preview:
        print(f"Preview: {preview_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
