@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%tool_platform\run_platform_windows.ps1"

if errorlevel 1 (
  echo.
  echo 启动失败，请把这个窗口截图发给技术人员。
  pause
)
