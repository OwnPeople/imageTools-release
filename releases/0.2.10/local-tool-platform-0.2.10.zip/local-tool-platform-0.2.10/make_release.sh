#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
  cat <<'EOF'
Usage:
  ./make_release.sh VERSION PUBLIC_BASE_URL [RELEASE_NOTES_FILE]

Example:
  ./make_release.sh 0.2.0 https://example.com/tool-platform notes.txt

Output:
  dist/releases/VERSION/local-tool-platform-VERSION.zip
  dist/releases/VERSION/manifest.json
  dist/manifest.json

Upload the zip to PUBLIC_BASE_URL/releases/VERSION/.
Upload dist/manifest.json to PUBLIC_BASE_URL/manifest.json.
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 2 || $# -gt 3 ]]; then
  usage >&2
  exit 2
fi

VERSION="$1"
PUBLIC_BASE_URL="${2%/}"
RELEASE_NOTES_FILE="${3:-}"
RELEASE_DIR="$ROOT_DIR/dist/releases/$VERSION"
PACKAGE_NAME="local-tool-platform-$VERSION"
ZIP_SOURCE="$ROOT_DIR/dist/$PACKAGE_NAME.zip"
ZIP_TARGET="$RELEASE_DIR/$PACKAGE_NAME.zip"
MANIFEST_PATH="$RELEASE_DIR/manifest.json"
LATEST_MANIFEST_PATH="$ROOT_DIR/dist/manifest.json"
CONFIG_PATH="$ROOT_DIR/tool_platform/app/config.py"
PUBLISHED_AT="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
DOWNLOAD_URL="$PUBLIC_BASE_URL/releases/$VERSION/$PACKAGE_NAME.zip"

if [[ ! "$VERSION" =~ ^[0-9]+(\.[0-9]+){1,3}$ ]]; then
  echo "Version should look like 0.2.0 or 1.0.0: $VERSION" >&2
  exit 2
fi

if [[ -n "$RELEASE_NOTES_FILE" && ! -f "$RELEASE_NOTES_FILE" ]]; then
  echo "Release notes file not found: $RELEASE_NOTES_FILE" >&2
  exit 1
fi

python3 - "$CONFIG_PATH" "$VERSION" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
version = sys.argv[2]
text = path.read_text(encoding="utf-8")
new_text, count = re.subn(r'^PLATFORM_VERSION = ".*"$', f'PLATFORM_VERSION = "{version}"', text, count=1, flags=re.MULTILINE)
if count != 1:
    raise SystemExit("Could not update PLATFORM_VERSION")
path.write_text(new_text, encoding="utf-8")
PY

PACKAGE_VERSION="$VERSION" "$ROOT_DIR/package_tool_platform.sh"

mkdir -p "$RELEASE_DIR"
cp "$ZIP_SOURCE" "$ZIP_TARGET"
ZIP_SHA256="$(shasum -a 256 "$ZIP_TARGET" | awk '{print $1}')"

python3 - "$MANIFEST_PATH" "$VERSION" "$DOWNLOAD_URL" "$PUBLISHED_AT" "$RELEASE_NOTES_FILE" "$ZIP_SHA256" <<'PY'
from pathlib import Path
import json
import sys

manifest_path = Path(sys.argv[1])
version = sys.argv[2]
download_url = sys.argv[3]
published_at = sys.argv[4]
notes_file = sys.argv[5]
zip_sha256 = sys.argv[6]
release_notes = ""
if notes_file:
    release_notes = Path(notes_file).read_text(encoding="utf-8").strip()

manifest = {
    "version": version,
    "download_url": download_url,
    "sha256": zip_sha256,
    "release_notes": release_notes or f"发布版本 {version}",
    "published_at": published_at,
    "tools_bundle_version": version,
    "minimum_supported_version": "0.1.0",
}
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY

cp "$MANIFEST_PATH" "$LATEST_MANIFEST_PATH"

echo "Release ready:"
echo "  $ZIP_TARGET"
echo "  $MANIFEST_PATH"
echo "  $LATEST_MANIFEST_PATH"
echo
echo "Upload:"
echo "  $ZIP_TARGET -> $PUBLIC_BASE_URL/releases/$VERSION/$PACKAGE_NAME.zip"
echo "  $LATEST_MANIFEST_PATH -> $PUBLIC_BASE_URL/manifest.json"
echo
echo "Manifest URL for clients:"
echo "  $PUBLIC_BASE_URL/manifest.json"
