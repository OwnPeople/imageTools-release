# 发布和更新流程

当前采用“私有源码仓库 + 公开发布仓库”的自动更新方案。

## 仓库分工

```text
OwnPeople/imageTools
```

私有源码仓库，保存代码、脚本、工具平台和 GitHub Actions 工作流。

```text
OwnPeople/imageTools-release
```

公开发布仓库，只保存客户端更新需要读取的文件：

```text
manifest.json
releases/版本号/local-tool-platform-版本号.zip
```

客户端默认读取：

```text
https://ownpeople.github.io/imageTools-release/manifest.json
```

## 开发者怎么发布

以后只需要在源码仓库执行：

```bash
git add .
git commit -m "更新工具"
git push origin main
```

GitHub Actions 会自动：

1. 生成新版本号
2. 打包 `local-tool-platform-版本号.zip`
3. 生成 `manifest.json`
4. 推送到 `OwnPeople/imageTools-release`
5. 由 GitHub Pages 对外提供下载

## 一次性配置

源码仓库的 Actions 需要一个 Secret：

```text
IMAGE_TOOLS_RELEASE_DEPLOY_KEY
```

这个 Secret 保存发布密钥的私钥。

公开发布仓库需要添加同一把密钥的公钥作为 Deploy key，并勾选：

```text
Allow write access
```

公开发布仓库 Pages 设置：

```text
Settings -> Pages
Source: Deploy from a branch
Branch: main
Folder: /root
```

## 客户端怎么更新

普通使用方只需要双击启动入口：

```text
本地工具平台.app
启动本地工具平台.bat
```

启动时会自动检查 manifest。如果版本号更新，会自动下载 zip、覆盖本地代码、刷新依赖并继续启动。
