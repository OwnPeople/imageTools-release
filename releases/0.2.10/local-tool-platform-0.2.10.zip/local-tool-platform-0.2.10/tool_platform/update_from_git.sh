#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
RUNTIME_DIR="$SCRIPT_DIR/runtime"
UPDATE_LOG="$RUNTIME_DIR/update.log"
REMOTE="${GIT_REMOTE:-origin}"
BRANCH="${GIT_BRANCH:-}"
AUTO_GIT_UPDATE="${AUTO_GIT_UPDATE:-1}"

mkdir -p "$RUNTIME_DIR"

log() {
  local message="$1"
  printf '%s %s\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" "$message" >> "$UPDATE_LOG"
  printf '%s\n' "$message"
}

if [[ "$AUTO_GIT_UPDATE" != "1" ]]; then
  log "Git auto-update disabled."
  exit 0
fi

if ! command -v git >/dev/null 2>&1; then
  log "Git not found; skip auto-update."
  exit 0
fi

if [[ ! -d "$APP_ROOT/.git" ]]; then
  log "App root is not a git checkout; skip auto-update: $APP_ROOT"
  exit 0
fi

if ! git -C "$APP_ROOT" diff --quiet || ! git -C "$APP_ROOT" diff --cached --quiet; then
  log "Local code changes found; skip auto-update to avoid overwriting them."
  exit 0
fi

if [[ -z "$BRANCH" ]]; then
  BRANCH="$(git -C "$APP_ROOT" branch --show-current)"
fi

if [[ -z "$BRANCH" ]]; then
  log "Could not determine git branch; skip auto-update."
  exit 0
fi

log "Checking git updates: $REMOTE/$BRANCH"
if ! git -C "$APP_ROOT" fetch --quiet "$REMOTE" "$BRANCH"; then
  log "Git fetch failed; start with current local code."
  exit 0
fi

LOCAL_REV="$(git -C "$APP_ROOT" rev-parse HEAD)"
REMOTE_REV="$(git -C "$APP_ROOT" rev-parse "$REMOTE/$BRANCH")"

if [[ "$LOCAL_REV" == "$REMOTE_REV" ]]; then
  log "Already up to date: $LOCAL_REV"
  exit 0
fi

BASE_REV="$(git -C "$APP_ROOT" merge-base HEAD "$REMOTE/$BRANCH")"
if [[ "$BASE_REV" != "$LOCAL_REV" ]]; then
  log "Local branch diverged from $REMOTE/$BRANCH; skip auto-update."
  exit 0
fi

log "Updating code: $LOCAL_REV -> $REMOTE_REV"
if git -C "$APP_ROOT" pull --ff-only --quiet "$REMOTE" "$BRANCH"; then
  touch "$RUNTIME_DIR/.needs_setup"
  log "Git update applied."
else
  log "Git pull failed; start with current local code."
fi
