from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional


class TaskStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    tool_id TEXT NOT NULL,
                    input_path TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    output_path TEXT,
                    log_path TEXT,
                    options_json TEXT NOT NULL,
                    message TEXT
                )
                """
            )
            conn.commit()

    def create_task(
        self,
        *,
        task_id: str,
        tool_id: str,
        input_path: str,
        status: str,
        created_at: str,
        log_path: str,
        options: Dict[str, Any],
    ) -> None:
        payload = (
            task_id,
            tool_id,
            input_path,
            status,
            created_at,
            None,
            None,
            None,
            log_path,
            json.dumps(options, ensure_ascii=False),
            "",
        )
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO tasks (
                    id, tool_id, input_path, status, created_at, started_at,
                    finished_at, output_path, log_path, options_json, message
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                payload,
            )
            conn.commit()

    def update_task(self, task_id: str, **fields: Any) -> None:
        if not fields:
            return
        columns = []
        values = []
        if "options" in fields:
            fields["options_json"] = json.dumps(fields.pop("options"), ensure_ascii=False)
        for key, value in fields.items():
            columns.append(f"{key} = ?")
            values.append(value)
        values.append(task_id)
        with self._lock, self._connect() as conn:
            conn.execute(f"UPDATE tasks SET {', '.join(columns)} WHERE id = ?", values)
            conn.commit()

    def list_tasks(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_dict(row) for row in rows]

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if row is None:
            return None
        return self._row_to_dict(row)

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
        data = dict(row)
        data["options"] = json.loads(data.pop("options_json") or "{}")
        return data
