from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from datetime import datetime
from typing import Any, Dict, List

from .config import PLATFORM_VERSION, load_settings, save_settings


def utc_now_text() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def parse_version_parts(version: str) -> List[int]:
    if not version:
        return [0]
    numbers = re.findall(r"\d+", version)
    if not numbers:
        return [0]
    return [int(item) for item in numbers]


def compare_versions(left: str, right: str) -> int:
    left_parts = parse_version_parts(left)
    right_parts = parse_version_parts(right)
    size = max(len(left_parts), len(right_parts))
    left_parts.extend([0] * (size - len(left_parts)))
    right_parts.extend([0] * (size - len(right_parts)))
    if left_parts < right_parts:
        return -1
    if left_parts > right_parts:
        return 1
    return 0


def fetch_manifest(manifest_url: str, timeout: int = 12) -> Dict[str, Any]:
    request = urllib.request.Request(
        manifest_url,
        headers={
            "User-Agent": f"local-tool-platform/{PLATFORM_VERSION}",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        payload = response.read().decode(charset, errors="replace")
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("Manifest JSON must be an object")
    return data


def normalize_manifest(manifest: Dict[str, Any]) -> Dict[str, Any]:
    version = str(manifest.get("version") or "").strip()
    if not version:
        raise ValueError("Manifest must include version")
    return {
        "version": version,
        "download_url": str(manifest.get("download_url") or "").strip(),
        "release_notes": str(manifest.get("release_notes") or "").strip(),
        "published_at": str(manifest.get("published_at") or "").strip(),
        "tools_bundle_version": str(manifest.get("tools_bundle_version") or "").strip(),
        "minimum_supported_version": str(manifest.get("minimum_supported_version") or "").strip(),
    }


def build_update_result(manifest: Dict[str, Any]) -> Dict[str, Any]:
    current_version = PLATFORM_VERSION
    latest_version = manifest["version"]
    has_update = compare_versions(current_version, latest_version) < 0
    return {
        "checked_at": utc_now_text(),
        "ok": True,
        "has_update": has_update,
        "current_version": current_version,
        "latest_version": latest_version,
        "download_url": manifest.get("download_url", ""),
        "release_notes": manifest.get("release_notes", ""),
        "published_at": manifest.get("published_at", ""),
        "tools_bundle_version": manifest.get("tools_bundle_version", ""),
        "minimum_supported_version": manifest.get("minimum_supported_version", ""),
        "error": "",
    }


def store_update_result(result: Dict[str, Any]) -> Dict[str, Any]:
    settings = load_settings()
    settings.setdefault("server", {})
    settings["server"]["last_update_check"] = result
    save_settings(settings)
    return result


def check_updates(manifest_url: str) -> Dict[str, Any]:
    manifest = normalize_manifest(fetch_manifest(manifest_url))
    result = build_update_result(manifest)
    return store_update_result(result)


def check_updates_from_settings() -> Dict[str, Any]:
    settings = load_settings()
    manifest_url = str(settings.get("server", {}).get("manifest_url") or "").strip()
    if not manifest_url:
        result = {
            "checked_at": utc_now_text(),
            "ok": False,
            "has_update": False,
            "current_version": PLATFORM_VERSION,
            "latest_version": "",
            "download_url": "",
            "release_notes": "",
            "published_at": "",
            "tools_bundle_version": "",
            "minimum_supported_version": "",
            "error": "Manifest URL is empty",
        }
        return store_update_result(result)
    try:
        return check_updates(manifest_url)
    except (ValueError, urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as exc:
        result = {
            "checked_at": utc_now_text(),
            "ok": False,
            "has_update": False,
            "current_version": PLATFORM_VERSION,
            "latest_version": "",
            "download_url": "",
            "release_notes": "",
            "published_at": "",
            "tools_bundle_version": "",
            "minimum_supported_version": "",
            "error": str(exc),
        }
        return store_update_result(result)
