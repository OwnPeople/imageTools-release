from __future__ import annotations

import os
import queue
import subprocess
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from .config import LOG_DIR
from .storage import TaskStore
from .tool_registry import ToolRegistry


def utc_now_text() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


@dataclass
class QueuedTask:
    task_id: str
    tool_id: str
    input_path: Path
    options: Dict[str, Any]


class TaskQueue:
    def __init__(self, store: TaskStore, registry: ToolRegistry) -> None:
        self.store = store
        self.registry = registry
        self._queue: queue.Queue[QueuedTask] = queue.Queue()
        self._thread = threading.Thread(target=self._run_forever, daemon=True, name="tool-platform-worker")
        self._started = False

    def start(self) -> None:
        if not self._started:
            self._thread.start()
            self._started = True

    def submit(self, tool_id: str, input_path: Path, options: Dict[str, Any]) -> Dict[str, Any]:
        task_id = uuid.uuid4().hex
        log_path = LOG_DIR / f"{task_id}.log"
        self.store.create_task(
            task_id=task_id,
            tool_id=tool_id,
            input_path=str(input_path),
            status="PENDING",
            created_at=utc_now_text(),
            log_path=str(log_path),
            options=options,
        )
        self._queue.put(QueuedTask(task_id=task_id, tool_id=tool_id, input_path=input_path, options=options))
        return self.store.get_task(task_id) or {"id": task_id}

    def _run_forever(self) -> None:
        while True:
            task = self._queue.get()
            try:
                self._execute(task)
            finally:
                self._queue.task_done()

    def _execute(self, task: QueuedTask) -> None:
        tool = self.registry.get(task.tool_id)
        output_dir = tool.resolve_output_dir(task.input_path)
        command = tool.build_command(task.input_path, task.options, output_path=output_dir)
        environment_overrides = tool.build_environment(task.options)
        task_data = self.store.get_task(task.task_id)
        if task_data is None:
            return
        log_path = Path(task_data["log_path"])
        log_path.parent.mkdir(parents=True, exist_ok=True)

        self.store.update_task(task.task_id, status="RUNNING", started_at=utc_now_text(), message="Task started")
        with log_path.open("w", encoding="utf-8") as log_fh:
            log_fh.write(f"工具：{tool.name}\n")
            log_fh.write(f"输入目录：{task.input_path}\n\n")
            if environment_overrides:
                log_fh.write("Environment:\n")
                for key in sorted(environment_overrides):
                    log_fh.write(f"{key}={environment_overrides[key]}\n")
                log_fh.write("\n")
            log_fh.flush()
            process_env = os.environ.copy()
            process_env.update(environment_overrides)
            process = subprocess.Popen(
                command,
                cwd=str(task.input_path.parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                env=process_env,
            )
            assert process.stdout is not None
            for line in process.stdout:
                log_fh.write(line)
                log_fh.flush()
            code = process.wait()

        if code == 0:
            self.store.update_task(
                task.task_id,
                status="SUCCESS",
                finished_at=utc_now_text(),
                output_path=str(output_dir),
                message="Task completed",
            )
            return

        self.store.update_task(
            task.task_id,
            status="FAILED",
            finished_at=utc_now_text(),
            output_path=str(output_dir),
            message=f"Task failed with exit code {code}",
        )
