from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any, Dict, List

from .config import BASE_DIR, RUNTIME_DIR


APP_ROOT = BASE_DIR.parent
UPDATE_LOG_PATH = RUNTIME_DIR / "update.log"
HTTP_UPDATE_LOG_PATH = RUNTIME_DIR / "update_http.log"


def run_git(args: List[str]) -> str:
    return subprocess.check_output(
        ["git", "-C", str(APP_ROOT), *args],
        text=True,
        stderr=subprocess.DEVNULL,
    ).strip()


def read_log(path: Path, max_lines: int = 8) -> List[str]:
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return lines[-max_lines:]


def get_git_update_status() -> Dict[str, Any]:
    log_lines = sorted((read_log(UPDATE_LOG_PATH) + read_log(HTTP_UPDATE_LOG_PATH))[-12:])
    last_line = log_lines[-1] if log_lines else ""
    status: Dict[str, Any] = {
        "mode": "launcher",
        "enabled": True,
        "app_root": str(APP_ROOT),
        "is_git_checkout": (APP_ROOT / ".git").exists(),
        "branch": "",
        "commit": "",
        "remote": "",
        "last_log_lines": log_lines,
        "last_checked_at": last_line.split(" ", 1)[0] if last_line else "",
        "version": "",
    }
    if "HTTP update applied" in last_line:
        status["state"] = "updated"
        status["message"] = "已自动更新到最新版本。"
        return status
    if "Already up to date" in last_line:
        status["state"] = "current"
        status["message"] = "已是最新版本。"
        return status
    if not status["is_git_checkout"]:
        status["state"] = "skip"
        status["message"] = "自动更新将在正式客户端启用。"
        return status

    try:
        status["branch"] = run_git(["branch", "--show-current"])
        status["commit"] = run_git(["rev-parse", "--short", "HEAD"])
        status["remote"] = run_git(["remote", "get-url", "origin"])
    except (FileNotFoundError, subprocess.SubprocessError):
        status["state"] = "unknown"
        status["message"] = "自动更新状态暂不可用。"
        return status

    if "Git update applied" in last_line:
        status["state"] = "updated"
        status["message"] = "已自动更新到最新版本。"
    elif "Already up to date" in last_line:
        status["state"] = "current"
        status["message"] = "已是最新版本。"
    elif "skip" in last_line.lower():
        status["state"] = "skip"
        status["message"] = "自动更新已跳过。"
    else:
        status["state"] = "ready"
        status["message"] = "启动时会自动检查更新。"
    return status
