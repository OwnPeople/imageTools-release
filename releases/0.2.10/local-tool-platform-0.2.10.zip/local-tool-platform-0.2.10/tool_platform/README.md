# 本地工具平台

这是“本地运行、网页操作”的第一版工具平台原型。

当前已经接入：

- `影像合并`
- `TIFF 镶嵌 + 色彩填补`

当前能力：

- 本地网页界面
- 工具注册表
- 顺序任务队列
- 批量扫描影像场景目录
- 扫描包含多张 GeoTIFF 的镶嵌输入目录
- 实时日志查看
- 打开结果目录
- 本地设置文件
- 远程更新检查底座

## 启动

```bash
cd /Users/jun/Documents/map/tool_platform
./setup_platform.sh
./run_platform.sh
```

然后打开：

```text
http://127.0.0.1:8765
```

## 换机器安装

正式交付给普通使用方时，用 `本地工具平台.app`。用户只需要双击 App，启动器会自动检查更新、刷新环境、启动服务并打开网页。

```bash
UPDATE_MANIFEST_URL=https://ownpeople.github.io/imageTools-release/manifest.json ./make_macos_app.sh
```

开发者只需要 push Git，GitHub Actions 会自动打包，并把 `manifest.json` 和 zip 更新包发布到公开仓库 `OwnPeople/imageTools-release`。详细流程见 `/Users/jun/Documents/map/FOOLPROOF_DEPLOYMENT.md`。

Windows 当前使用双击入口：

```text
启动本地工具平台.bat
```

它会自动调用 PowerShell 脚本完成 Python 环境、更新、依赖刷新和启动。

Git 自动更新仍可用于开发/内测：客户端第一次 `git clone`，以后启动时自动 `git pull`。详细流程见 `/Users/jun/Documents/map/GIT_UPDATE_WORKFLOW.md`。

如果暂时不用 Git，也可以继续用 zip 发布包：

在开发机上先打包：

```bash
cd /Users/jun/Documents/map
./package_tool_platform.sh
```

把 `dist/local-tool-platform-*.zip` 复制到新机器并解压，然后进入解压后的 `tool_platform` 运行：

```bash
./bootstrap_setup.sh
./run_platform.sh
```

`bootstrap_setup.sh` 会先寻找本机可用的 Python。如果没有 Python，或 Python 太旧/不能创建虚拟环境，它会把一个独立的 Miniforge Python 下载到 `tool_platform/runtime/python/`，然后继续创建 `.venv`、安装网页平台依赖和影像处理依赖，并检查 `cv2`、`numpy`、`PIL`、`rasterio` 是否可用。

如果新机器已经有可用的 Python，也可以直接运行：

```bash
./setup_platform.sh
```

如果新机器已经有可用的 Anaconda/Miniconda 影像处理环境，也可以跳过处理依赖安装：

```bash
INSTALL_PROCESSING_DEPS=0 ./bootstrap_setup.sh
```

处理脚本运行时会优先使用平台 `.venv`，找不到可用依赖时再尝试 `/opt/anaconda3`、`/Users/jun/miniconda3` 和系统 `python3`。

## 目录

- `app/`：FastAPI 后端
- `static/`：前端静态资源
- `templates/`：页面模板
- `tools/`：工具定义
- `runtime/`：任务数据库、日志、设置

## 当前说明

- 默认一次只跑一个重任务
- 影像合并工具复用现有的影像合并处理脚本
- 影像合并工具可以直接处理单个场景目录；如果选择的是包含多个影像场景的父目录，平台会自动走批处理模式
- 处理输出仍然写回原始景目录下的 `processed_truecolor_sharp_browse/`
- TIFF 镶嵌工具复用现有的 `/Users/jun/Documents/map/run_mosaic_all.sh`
- 镶嵌输出默认写到输入目录旁边的 `输入目录名_镶嵌结果/`

## 自动更新

客户端启动时会自动读取：

```text
https://ownpeople.github.io/imageTools-release/manifest.json
```

如果发现新版本，会自动下载公开仓库里的 zip 更新包、覆盖本地代码、刷新依赖环境，然后继续启动平台。普通使用方不需要手动检查更新，也不需要配置 Git。

## 后续适合继续加

- 远程版本更新
- 监控目录自动入队
- 定时任务
- 多工具接入
