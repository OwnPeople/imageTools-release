#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNTIME_DIR="$SCRIPT_DIR/runtime"
PYTHON_RUNTIME_DIR="$RUNTIME_DIR/python"
DOWNLOAD_DIR="$RUNTIME_DIR/downloads"
FORCE_EMBEDDED_PYTHON="${FORCE_EMBEDDED_PYTHON:-0}"

python_is_usable() {
  local python_bin="$1"
  "$python_bin" - <<'PY' >/dev/null 2>&1
import sys
import venv
raise SystemExit(0 if sys.version_info >= (3, 9) else 1)
PY
}

find_system_python() {
  local candidate
  for candidate in python3 python; do
    local resolved
    resolved="$(command -v "$candidate" 2>/dev/null || true)"
    if [[ -n "$resolved" ]] && python_is_usable "$resolved"; then
      printf '%s\n' "$resolved"
      return 0
    fi
  done
  return 1
}

miniforge_platform() {
  local os_name
  local arch_name
  os_name="$(uname -s)"
  arch_name="$(uname -m)"

  case "$os_name" in
    Darwin) os_name="MacOSX" ;;
    Linux) os_name="Linux" ;;
    *)
      echo "Unsupported OS for automatic Python bootstrap: $os_name" >&2
      return 1
      ;;
  esac

  case "$arch_name" in
    arm64|aarch64) arch_name="arm64" ;;
    x86_64|amd64) arch_name="x86_64" ;;
    *)
      echo "Unsupported CPU architecture for automatic Python bootstrap: $arch_name" >&2
      return 1
      ;;
  esac

  if [[ "$os_name" == "Linux" && "$arch_name" == "arm64" ]]; then
    arch_name="aarch64"
  fi

  printf '%s-%s\n' "$os_name" "$arch_name"
}

install_embedded_python() {
  mkdir -p "$DOWNLOAD_DIR"

  if [[ -x "$PYTHON_RUNTIME_DIR/bin/python" ]] && python_is_usable "$PYTHON_RUNTIME_DIR/bin/python"; then
    printf '%s\n' "$PYTHON_RUNTIME_DIR/bin/python"
    return 0
  fi

  if ! command -v curl >/dev/null 2>&1; then
    echo "curl is required to download the embedded Python installer." >&2
    return 1
  fi

  local platform_name
  platform_name="$(miniforge_platform)"
  local installer_name="Miniforge3-${platform_name}.sh"
  local installer_path="$DOWNLOAD_DIR/$installer_name"
  local installer_url="https://github.com/conda-forge/miniforge/releases/latest/download/$installer_name"

  echo "Downloading embedded Python runtime:" >&2
  echo "  $installer_url" >&2
  curl -L --fail --retry 3 -o "$installer_path" "$installer_url"

  rm -rf "$PYTHON_RUNTIME_DIR"
  bash "$installer_path" -b -p "$PYTHON_RUNTIME_DIR" >&2
  "$PYTHON_RUNTIME_DIR/bin/conda" config --set auto_activate_base false >/dev/null 2>&1 || true

  printf '%s\n' "$PYTHON_RUNTIME_DIR/bin/python"
}

main() {
  local python_bin=""
  if [[ "$FORCE_EMBEDDED_PYTHON" != "1" ]]; then
    python_bin="$(find_system_python || true)"
  fi

  if [[ -z "$python_bin" ]]; then
    python_bin="$(install_embedded_python)"
  fi

  echo "Using Python: $python_bin"
  PYTHON="$python_bin" "$SCRIPT_DIR/setup_platform.sh"
}

main "$@"
