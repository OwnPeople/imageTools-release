#!/usr/bin/env python3
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import re
import shutil
import time
from types import SimpleNamespace
from typing import Dict, List, Sequence

from rasterio.enums import Resampling

from mosaic_gf2_batch import (
    apply_registration_tree,
    build_pair_edges,
    build_registration_tree,
    create_runtimes,
    is_generated_artifact,
    print_pair_summary,
    run_batch_mosaic,
)
from mosaic_gf2_geotiffs import (
    SourceInfo,
    build_overviews,
    choose_reference,
    configure_runtime_radiometric_matching,
    compute_target_grid,
    crop_output_to_data,
    default_preview_path,
    inspect_sources,
    print_runtime_read_error_summary,
    write_preview,
)


@dataclass
class SourceGroup:
    name: str
    sources: List[SourceInfo]
    priority_pixel_area: float


@dataclass
class SourceCluster:
    group_name: str
    cluster_id: int
    sources: List[SourceInfo]
    priority_pixel_area: float

    @property
    def name(self) -> str:
        return f"{self.group_name}_part{self.cluster_id:02d}"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Hierarchical mosaic for mixed-source GeoTIFF folders: mosaic each source family first, "
            "then merge the family mosaics with the sharper source taking priority."
        )
    )
    parser.add_argument(
        "input_dir",
        nargs="?",
        default="/Users/jun/Documents/map/武川县",
        help="Folder containing source tif/tiff files",
    )
    parser.add_argument(
        "--output-dir",
        default="",
        help="Output folder; default is a sibling folder named <input_dir>_hierarchical_merge",
    )
    parser.add_argument(
        "--output-name",
        default="",
        help="Final mosaic filename inside output-dir; default is <input_dir>_hierarchical_merge.tif",
    )
    parser.add_argument(
        "--pattern",
        default="*.tif",
        help="Input glob pattern inside input_dir",
    )
    parser.add_argument(
        "--only-clusters",
        default="",
        help="Optional comma-separated cluster names to run, for example GF7_part01 or GF7_part01,GF2_part01",
    )
    parser.add_argument(
        "--reuse-existing-clusters",
        action="store_true",
        help="When only rerunning some clusters, reuse existing cluster TIFFs for the others during the final merge",
    )
    parser.add_argument(
        "--group-register-mode",
        choices=("auto", "none", "translation", "affine"),
        default="auto",
        help="Registration mode used inside each same-source group",
    )
    parser.add_argument(
        "--group-method",
        choices=("first", "last", "blend", "feather"),
        default="feather",
        help="Overlap rule used inside each same-source group",
    )
    parser.add_argument(
        "--feather-width",
        type=int,
        default=1800,
        help="Feather transition width in pixels when group-method=feather",
    )
    parser.add_argument(
        "--final-method",
        choices=("first", "last", "feather"),
        default="feather",
        help="Overlap rule used when merging source groups together",
    )
    parser.add_argument(
        "--group-seam-register",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Estimate bounded local seam shifts inside same-source clusters",
    )
    parser.add_argument(
        "--final-seam-register",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Estimate bounded local seam shifts when merging source clusters",
    )
    parser.add_argument(
        "--seam-register-max-shift",
        type=float,
        default=96.0,
        help="Maximum local seam translation in output pixels",
    )
    parser.add_argument(
        "--seam-register-band",
        type=int,
        default=2400,
        help="Width in output pixels sampled near a cluster boundary for local seam registration",
    )
    parser.add_argument(
        "--seam-register-max-size",
        type=int,
        default=2200,
        help="Longest side of the downsampled seam-registration sample",
    )
    parser.add_argument(
        "--seam-color-match",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Locally match color inside the feather band before blending",
    )
    parser.add_argument(
        "--seam-color-match-strength",
        type=float,
        default=0.55,
        help="Strength of local seam color correction from 0 to 1",
    )
    parser.add_argument(
        "--seam-color-match-max-offset",
        type=float,
        default=32.0,
        help="Maximum per-channel local seam offset in 8-bit values",
    )
    parser.add_argument(
        "--seam-color-match-gain-strength",
        type=float,
        default=0.20,
        help="Strength of robust local seam contrast matching from 0 to 1",
    )
    parser.add_argument(
        "--seam-color-match-max-gain-delta",
        type=float,
        default=0.16,
        help="Maximum local seam gain change before strength is applied",
    )
    parser.add_argument(
        "--seam-color-match-min-pixels",
        type=int,
        default=1600,
        help="Minimum overlap pixels needed before estimating a local seam color correction",
    )
    parser.add_argument(
        "--seam-color-match-new-side",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Apply the local seam correction just outside the overlap and taper it away from the edge",
    )
    parser.add_argument(
        "--group-radiometric-match",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Apply conservative whole-scene color matching inside each source group",
    )
    parser.add_argument("--group-radiometric-strength", type=float, default=0.12)
    parser.add_argument("--group-radiometric-max-offset", type=float, default=8.0)
    parser.add_argument("--group-radiometric-gain-strength", type=float, default=0.0)
    parser.add_argument(
        "--final-radiometric-match",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Apply conservative whole-scene color matching between source-group mosaics before final merge",
    )
    parser.add_argument("--final-radiometric-strength", type=float, default=0.28)
    parser.add_argument("--final-radiometric-max-offset", type=float, default=24.0)
    parser.add_argument("--final-radiometric-gain-strength", type=float, default=0.10)
    parser.add_argument(
        "--resampling",
        choices=("nearest", "bilinear", "cubic"),
        default="bilinear",
        help="Resampling used when aligning onto the target grid",
    )
    parser.add_argument(
        "--register-max-size",
        type=int,
        default=2800,
        help="Longest side of the overlap sample used for automatic registration inside a source group",
    )
    parser.add_argument(
        "--tile-size",
        type=int,
        default=1024,
        help="Processing tile size in output pixels",
    )
    parser.add_argument(
        "--compress",
        choices=("lzw", "deflate"),
        default="lzw",
        help="GeoTIFF compression",
    )
    parser.add_argument(
        "--ignore-read-errors",
        action="store_true",
        help="If a source tile cannot be decoded, treat that source window as empty instead of aborting the whole run",
    )
    parser.add_argument(
        "--build-overviews",
        action="store_true",
        help="Build overview pyramids for the final mosaic",
    )
    parser.add_argument(
        "--skip-final-merge",
        action="store_true",
        help="Only produce cluster outputs, do not write the final merged mosaic",
    )
    parser.add_argument(
        "--skip-crop",
        action="store_true",
        help="Do not crop empty outer borders after writing each mosaic stage",
    )
    parser.add_argument(
        "--skip-preview",
        action="store_true",
        help="Do not create a JPEG preview after the final mosaic finishes",
    )
    parser.add_argument(
        "--preview-max-size",
        type=int,
        default=2400,
        help="Longest side of the JPEG preview in pixels",
    )
    parser.add_argument(
        "--preview-quality",
        type=int,
        default=90,
        help="JPEG preview quality from 1 to 100",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing outputs if they already exist",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only print the planned group/final workflow, do not write files",
    )
    return parser.parse_args()


def default_output_dir(input_dir: Path) -> Path:
    return input_dir.parent / f"{input_dir.name}_hierarchical_merge"


def default_output_name(input_dir: Path) -> str:
    return f"{input_dir.name}_hierarchical_merge.tif"


def group_key_from_name(path: Path) -> str:
    stem = path.stem
    match = re.match(r"^([A-Za-z]+\d+)", stem)
    if match:
        return match.group(1).upper()
    token = stem.split("_", 1)[0].strip()
    return token.upper() if token else "UNKNOWN"


def collect_input_paths(input_dir: Path, pattern: str, output_dir: Path) -> List[Path]:
    paths: List[Path] = []
    for path in sorted(input_dir.glob(pattern)):
        if not path.is_file():
            continue
        resolved = path.resolve()
        if output_dir in resolved.parents:
            continue
        if is_generated_artifact(resolved):
            continue
        paths.append(resolved)
    if len(paths) < 2:
        raise FileNotFoundError(f"Need at least two source TIFF files under {input_dir}, but found {len(paths)}.")
    return paths


def parse_only_clusters(value: str) -> set[str]:
    return {item.strip() for item in value.split(",") if item.strip()}


def build_groups(sources: Sequence[SourceInfo]) -> List[SourceGroup]:
    grouped: Dict[str, List[SourceInfo]] = {}
    for source in sources:
        grouped.setdefault(group_key_from_name(source.path), []).append(source)

    groups: List[SourceGroup] = []
    for name, items in grouped.items():
        ordered = sorted(items, key=lambda item: (item.pixel_area, item.path.name))
        groups.append(
            SourceGroup(
                name=name,
                sources=ordered,
                priority_pixel_area=min(item.pixel_area for item in ordered),
            )
        )
    groups.sort(key=lambda group: (group.priority_pixel_area, group.name))
    return groups


def make_stage_args(args: argparse.Namespace, method: str, register_mode: str, seam_register: bool) -> SimpleNamespace:
    return SimpleNamespace(
        method=method,
        register_mode=register_mode,
        register_max_size=args.register_max_size,
        tile_size=args.tile_size,
        resampling=args.resampling,
        compress=args.compress,
        ignore_read_errors=args.ignore_read_errors,
        overwrite=args.overwrite,
        feather_width=args.feather_width,
        seam_register=seam_register,
        seam_register_max_shift=args.seam_register_max_shift,
        seam_register_band=args.seam_register_band,
        seam_register_max_size=args.seam_register_max_size,
        seam_color_match=args.seam_color_match,
        seam_color_match_strength=args.seam_color_match_strength,
        seam_color_match_max_offset=args.seam_color_match_max_offset,
        seam_color_match_gain_strength=args.seam_color_match_gain_strength,
        seam_color_match_max_gain_delta=args.seam_color_match_max_gain_delta,
        seam_color_match_min_pixels=args.seam_color_match_min_pixels,
        seam_color_match_new_side=args.seam_color_match_new_side,
        skip_crop=args.skip_crop,
        build_overviews=False,
        preview_max_size=args.preview_max_size,
        preview_quality=args.preview_quality,
    )


def effective_group_register_mode(group: SourceGroup, args: argparse.Namespace) -> str:
    if args.group_register_mode != "auto":
        return args.group_register_mode
    # GF7 sharp-browse products already carry consistent georeferencing, but their
    # black fill triangles can trick feature matching. After masking black fills,
    # keeping raw georeferencing is more stable than forcing an extra translation.
    if group.name.upper() == "GF7":
        return "none"
    return "translation"


def make_virtual_source_info(
    path: Path,
    reference: SourceInfo,
    transform,
    width: int,
    height: int,
) -> SourceInfo:
    left = float(transform.c)
    top = float(transform.f)
    right = left + width * abs(float(transform.a))
    bottom = top - height * abs(float(transform.e))
    resx = abs(float(transform.a))
    resy = abs(float(transform.e))
    return SourceInfo(
        path=path,
        crs=reference.crs,
        width=width,
        height=height,
        count=3,
        dtype=reference.dtype,
        transform=transform,
        bounds=(left, bottom, right, top),
        res=(resx, resy),
        pixel_area=resx * resy,
    )


def print_group_summary(groups: Sequence[SourceGroup]) -> None:
    print("Source groups:")
    for group in groups:
        print(
            f"  - {group.name}: {len(group.sources)} scene(s), "
            f"best pixel area={group.priority_pixel_area:.12e}"
        )
        for source in group.sources:
            print(f"    * {source.path.name}")


def build_connected_components(num_nodes: int, edges) -> List[List[int]]:
    adjacency: Dict[int, List[int]] = {index: [] for index in range(num_nodes)}
    for edge in edges:
        adjacency[edge.a].append(edge.b)
        adjacency[edge.b].append(edge.a)

    visited = set()
    components: List[List[int]] = []
    for start in range(num_nodes):
        if start in visited:
            continue
        stack = [start]
        component: List[int] = []
        visited.add(start)
        while stack:
            current = stack.pop()
            component.append(current)
            for neighbor in adjacency[current]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    stack.append(neighbor)
        components.append(sorted(component))
    return components


def build_clusters_for_group(group: SourceGroup, min_overlap_pixels: int = 512) -> List[SourceCluster]:
    if len(group.sources) == 1:
        return [
            SourceCluster(
                group_name=group.name,
                cluster_id=1,
                sources=list(group.sources),
                priority_pixel_area=group.priority_pixel_area,
            )
        ]

    reference = choose_reference(group.sources, "auto")
    transform, width, height, target_crs = compute_target_grid(group.sources, reference)
    edges = build_pair_edges(group.sources, target_crs, transform, width, height, min_overlap_pixels=min_overlap_pixels)
    components = build_connected_components(len(group.sources), edges)

    clusters: List[SourceCluster] = []
    for cluster_id, component in enumerate(components, start=1):
        component_sources = [group.sources[index] for index in component]
        component_sources.sort(key=lambda item: (item.pixel_area, item.path.name))
        clusters.append(
            SourceCluster(
                group_name=group.name,
                cluster_id=cluster_id,
                sources=component_sources,
                priority_pixel_area=min(item.pixel_area for item in component_sources),
            )
        )
    clusters.sort(key=lambda item: (item.priority_pixel_area, item.name))
    return clusters


def print_cluster_summary(group: SourceGroup, clusters: Sequence[SourceCluster]) -> None:
    print(f"  {group.name} clusters:")
    for cluster in clusters:
        print(
            f"    - {cluster.name}: {len(cluster.sources)} scene(s), "
            f"best pixel area={cluster.priority_pixel_area:.12e}"
        )
        for source in cluster.sources:
            print(f"      * {source.path.name}")


def close_stage_runtimes(runtimes) -> None:
    print_runtime_read_error_summary(runtimes)
    for runtime in runtimes:
        runtime.vrt.close()
        runtime.dataset.close()


def estimate_stage_bytes(
    sources: Sequence[SourceInfo],
    width: int,
    height: int,
    stage_args: SimpleNamespace,
) -> int:
    existing_sizes = [source.path.stat().st_size for source in sources if source.path.exists()]
    input_total = sum(existing_sizes)
    base_output = width * height * 4
    estimated = max(int(input_total * 1.5), int(base_output * 0.45))
    if not stage_args.skip_crop:
        estimated += max(int(input_total * 0.8), int(base_output * 0.20))
    if stage_args.build_overviews:
        estimated += max(int(input_total * 0.15), int(base_output * 0.05))
    return estimated


def available_stage_free_bytes(output_path: Path, overwrite: bool) -> int:
    usage = shutil.disk_usage(output_path.parent)
    reclaimable = output_path.stat().st_size if overwrite and output_path.exists() else 0
    return int(usage.free + reclaimable)


def print_stage_space(output_path: Path, required_bytes: int, overwrite: bool) -> None:
    free_bytes = available_stage_free_bytes(output_path, overwrite)
    free_gib = free_bytes / (1024 ** 3)
    required_gib = required_bytes / (1024 ** 3)
    print(f"Disk free:      {free_gib:.1f} GiB")
    print(f"Estimated need: {required_gib:.1f} GiB")
    if free_bytes < required_bytes:
        print("Warning: free space is lower than the estimated need for this stage.")


def run_cluster_stage(
    cluster: SourceCluster,
    output_path: Path,
    args: argparse.Namespace,
) -> SourceInfo:
    if len(cluster.sources) == 1:
        source = cluster.sources[0]
        print(f"[Cluster {cluster.name}] only one source, reuse original: {source.path.name}")
        if not args.skip_preview:
            preview_path = default_preview_path(output_path)
            if args.dry_run:
                print(f"[Cluster {cluster.name}] preview -> {preview_path}")
                return source
            print(f"[Cluster {cluster.name}] writing preview -> {preview_path}")
            write_preview(source.path, preview_path, args.preview_max_size, args.preview_quality)
        return source

    pseudo_group = SourceGroup(cluster.group_name, cluster.sources, cluster.priority_pixel_area)
    register_mode = effective_group_register_mode(pseudo_group, args)
    stage_args = make_stage_args(args, args.group_method, register_mode, args.group_seam_register)
    reference = choose_reference(cluster.sources, "auto")
    transform, width, height, target_crs = compute_target_grid(cluster.sources, reference)
    virtual_info = make_virtual_source_info(output_path, reference, transform, width, height)

    print(f"[Cluster {cluster.name}] output -> {output_path}")
    print(
        f"[Cluster {cluster.name}] method={args.group_method}, register-mode={register_mode}, "
        f"seam-register={args.group_seam_register}, reference={reference.path.name}, size={width}x{height}"
    )

    required_bytes = estimate_stage_bytes(cluster.sources, width, height, stage_args)
    if args.dry_run:
        print_stage_space(output_path, required_bytes, args.overwrite)
    else:
        print_stage_space(output_path, required_bytes, args.overwrite)
        available_free = available_stage_free_bytes(output_path, args.overwrite)
        if available_free < required_bytes:
            raise RuntimeError(
                "Not enough free disk space for this mosaic run. "
                f"Free {available_free / (1024 ** 3):.1f} GiB, "
                f"estimated required {required_bytes / (1024 ** 3):.1f} GiB."
            )

    edges = []
    parent_map = {0: 0}
    disconnected: List[int] = []
    reference_index = next(index for index, item in enumerate(cluster.sources) if item.path == reference.path)
    if register_mode != "none":
        edges = build_pair_edges(cluster.sources, target_crs, transform, width, height, min_overlap_pixels=512)
        print_pair_summary(edges, cluster.sources)
        parent_map, disconnected = build_registration_tree(
            cluster.sources,
            edges,
            reference_index,
            allow_disconnected=True,
        )
        print(f"[Cluster {cluster.name}] registration tree:")
        for child_index, parent_index in sorted(parent_map.items()):
            if child_index == parent_index:
                print(f"  - {cluster.sources[child_index].path.name} (reference)")
            else:
                print(f"  - {cluster.sources[child_index].path.name} <- {cluster.sources[parent_index].path.name}")
        if disconnected:
            print(f"[Cluster {cluster.name}] disconnected scenes kept by raw georeferencing:")
            for index in disconnected:
                print(f"  - {cluster.sources[index].path.name}")
    else:
        print(f"[Cluster {cluster.name}] registration disabled; use raw georeferencing inside this source family.")

    if args.dry_run:
        if not args.skip_preview:
            print(f"[Cluster {cluster.name}] preview -> {default_preview_path(output_path)}")
        return virtual_info

    if output_path.exists() and not args.overwrite:
        raise FileExistsError(f"Group output already exists: {output_path}. Use --overwrite to replace it.")

    runtimes = create_runtimes(cluster.sources, target_crs, transform, width, height, getattr(Resampling, args.resampling))
    try:
        if register_mode != "none":
            apply_registration_tree(runtimes, parent_map, reference_index, transform, width, height, stage_args)
        if args.group_radiometric_match:
            print(f"[Cluster {cluster.name}] radiometric matching -> {reference.path.name}")
            configure_runtime_radiometric_matching(
                runtimes,
                reference.path,
                offset_strength=args.group_radiometric_strength,
                max_offset=args.group_radiometric_max_offset,
                gain_strength=args.group_radiometric_gain_strength,
            )
        else:
            print(f"[Cluster {cluster.name}] radiometric matching disabled.")
        run_batch_mosaic(runtimes, reference, output_path, transform, width, height, stage_args)
    finally:
        close_stage_runtimes(runtimes)

    if not args.skip_crop:
        crop_output_to_data(output_path, args.tile_size)

    if not args.skip_preview:
        preview_path = default_preview_path(output_path)
        print(f"[Cluster {cluster.name}] writing preview -> {preview_path}")
        write_preview(output_path, preview_path, args.preview_max_size, args.preview_quality)

    return inspect_sources([output_path])[0]


def run_final_stage(
    grouped_infos: Sequence[SourceInfo],
    final_output_path: Path,
    args: argparse.Namespace,
) -> None:
    stage_args = make_stage_args(args, args.final_method, "none", args.final_seam_register)
    ordered_infos = sorted(grouped_infos, key=lambda item: (item.pixel_area, item.path.name))
    reference = choose_reference(ordered_infos, "auto")
    transform, width, height, target_crs = compute_target_grid(ordered_infos, reference)

    print("Final merge order (sharpest first):")
    for info in ordered_infos:
        print(f"  - {info.path.name} | pixel_area={info.pixel_area:.12e}")
    print(
        f"Final output -> {final_output_path}\n"
        f"Final method={args.final_method}, seam-register={args.final_seam_register}, "
        f"reference={reference.path.name}, size={width}x{height}"
    )

    required_bytes = estimate_stage_bytes(ordered_infos, width, height, stage_args)
    if args.dry_run:
        print_stage_space(final_output_path, required_bytes, args.overwrite)
    else:
        print_stage_space(final_output_path, required_bytes, args.overwrite)
        available_free = available_stage_free_bytes(final_output_path, args.overwrite)
        if available_free < required_bytes:
            raise RuntimeError(
                "Not enough free disk space for this mosaic run. "
                f"Free {available_free / (1024 ** 3):.1f} GiB, "
                f"estimated required {required_bytes / (1024 ** 3):.1f} GiB."
            )

    if args.dry_run:
        return

    if final_output_path.exists() and not args.overwrite:
        raise FileExistsError(f"Output already exists: {final_output_path}. Use --overwrite to replace it.")

    runtimes = create_runtimes(ordered_infos, target_crs, transform, width, height, getattr(Resampling, args.resampling))
    try:
        if args.final_radiometric_match:
            print(f"Final radiometric matching -> {reference.path.name}")
            configure_runtime_radiometric_matching(
                runtimes,
                reference.path,
                offset_strength=args.final_radiometric_strength,
                max_offset=args.final_radiometric_max_offset,
                gain_strength=args.final_radiometric_gain_strength,
            )
        else:
            print("Final radiometric matching disabled.")
        run_batch_mosaic(runtimes, reference, final_output_path, transform, width, height, stage_args)
    finally:
        close_stage_runtimes(runtimes)

    if not args.skip_crop:
        crop_output_to_data(final_output_path, args.tile_size)

    if args.build_overviews:
        print("Building overviews...")
        build_overviews(final_output_path)

    if not args.skip_preview:
        preview_path = default_preview_path(final_output_path)
        print("Writing preview image...")
        write_preview(final_output_path, preview_path, args.preview_max_size, args.preview_quality)


def main() -> int:
    args = parse_args()
    start_time = time.time()

    input_dir = Path(args.input_dir).expanduser().resolve()
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Input directory does not exist: {input_dir}")

    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else default_output_dir(input_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_name = args.output_name or default_output_name(input_dir)
    final_output_path = output_dir / output_name
    group_output_dir = output_dir / "groups"
    group_output_dir.mkdir(parents=True, exist_ok=True)

    input_paths = collect_input_paths(input_dir, args.pattern, output_dir)
    sources = inspect_sources(input_paths)
    groups = build_groups(sources)
    print_group_summary(groups)
    only_clusters = parse_only_clusters(args.only_clusters)
    matched_clusters: set[str] = set()

    clustered_infos: List[SourceInfo] = []
    for group in groups:
        clusters = build_clusters_for_group(group)
        print_cluster_summary(group, clusters)
        active_in_group = False
        for cluster in clusters:
            cluster_output_path = group_output_dir / f"{cluster.name}.tif"
            selected = not only_clusters or cluster.name in only_clusters
            if selected:
                active_in_group = True
                matched_clusters.add(cluster.name)
                clustered_info = run_cluster_stage(cluster, cluster_output_path, args)
                clustered_infos.append(clustered_info)
                continue

            if args.reuse_existing_clusters and not args.skip_final_merge:
                if not cluster_output_path.exists():
                    print(f"[Cluster {cluster.name}] missing reusable output, build now -> {cluster_output_path}")
                    clustered_info = run_cluster_stage(cluster, cluster_output_path, args)
                    clustered_infos.append(clustered_info)
                    continue
                print(f"[Cluster {cluster.name}] reuse existing -> {cluster_output_path}")
                clustered_infos.append(inspect_sources([cluster_output_path])[0])

        if only_clusters and not active_in_group and not args.reuse_existing_clusters:
            print(f"  {group.name} clusters: skipped by --only-clusters filter")

    if only_clusters:
        missing = sorted(only_clusters - matched_clusters)
        if missing:
            raise FileNotFoundError("Requested cluster(s) not found: " + ", ".join(missing))

    if not clustered_infos:
        raise RuntimeError("No clusters were selected to process.")

    if args.skip_final_merge:
        print("Skip final merge as requested.")
        print(f"Done in {(time.time() - start_time) / 60.0:.2f} minutes")
        print(f"Cluster outputs: {group_output_dir}")
        return 0

    run_final_stage(clustered_infos, final_output_path, args)

    print(f"Done in {(time.time() - start_time) / 60.0:.2f} minutes")
    print(f"Final output: {final_output_path}")
    if not args.skip_preview:
        print(f"Preview: {default_preview_path(final_output_path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
