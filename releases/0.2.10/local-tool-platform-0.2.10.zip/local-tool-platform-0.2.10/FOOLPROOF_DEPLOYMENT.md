# 傻瓜式交付方案

使用方不是技术人员，所以客户端不能出现 Git、终端命令、更新地址、手动检查更新。

正式方案：

```text
开发者 push 私有源码仓库 main
  -> GitHub Actions 自动打包
  -> 推送发布文件到公开仓库 imageTools-release
  -> GitHub Pages 自动更新 manifest.json
  -> 客户端双击 App
  -> App 自动检查、下载、覆盖代码、刷新环境、打开网页
```

## 使用方看到什么

只看到一个 macOS App：

```text
本地工具平台.app
```

Windows 上先给用户这个双击入口：

```text
启动本地工具平台.bat
```

用户双击即可。

App 会自动：

- 检查更新
- 下载新代码包
- 安装/刷新 Python 环境
- 启动本地服务
- 打开浏览器页面

## 开发者怎么更新

以后开发者只做：

```bash
git add .
git commit -m "更新工具"
git push origin main
```

仓库里已经配置了 GitHub Actions。每次 push 到 `main` 后，它会自动运行：

```text
.github/workflows/publish-client-update.yml
```

并发布到公开仓库 `OwnPeople/imageTools-release`：

```text
https://ownpeople.github.io/imageTools-release/manifest.json
https://ownpeople.github.io/imageTools-release/releases/版本号/local-tool-platform-版本号.zip
```

也就是说，开发者只需要提交并推送代码，打包和更新清单不需要手动操作。

## GitHub 一次性配置

因为源码仓库是私有的，GitHub Actions 需要一把专门的发布密钥，才能把发布文件推到公开仓库。

需要配置两个地方：

1. 在公开仓库 `OwnPeople/imageTools-release` 添加 Deploy key，并勾选 `Allow write access`
2. 在私有源码仓库 `OwnPeople/imageTools` 添加 Actions Secret，名字必须是 `IMAGE_TOOLS_RELEASE_DEPLOY_KEY`

公开仓库 Pages 设置：

```text
Settings -> Pages -> Build and deployment
Source: Deploy from a branch
Branch: main
Folder: /root
```

配置好后，私有源码仓库每次 push 到 `main`，都会自动更新公开仓库的 Pages 文件。

## 第一次生成 App

在开发机上执行：

```bash
UPDATE_MANIFEST_URL=https://ownpeople.github.io/imageTools-release/manifest.json ./make_macos_app.sh
```

生成：

```text
dist/本地工具平台.app
```

把这个 App 给用户即可。后续用户不需要重新安装，App 启动时会自己更新内部工具代码。

客户端代码里也内置了同一个默认更新地址，所以 Windows bat 启动方式不需要额外配置更新地址。

## Windows 第一次交付

当前先用 zip 包交付。用户解压后双击：

```text
启动本地工具平台.bat
```

它会自动调用：

```text
tool_platform\run_platform_windows.ps1
```

并自动完成 Python 环境、依赖、更新和打开浏览器。

后续可以再把这个 bat 包成真正的 Windows `.exe` 安装包。

## 为什么不让客户端走 Git

Git 适合开发者和服务器，不适合普通使用方：

- 需要安装 Git
- 需要配置仓库权限
- 容易遇到网络/凭证/冲突问题
- 出错信息对普通用户不友好

因此客户端改为 HTTP 更新包，Git 只留在服务器自动化里。
