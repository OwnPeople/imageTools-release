#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import cv2
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.windows import Window

from mosaic_gf2_geotiffs import choose_feature_detector, mask_black_background, prepare_gray_for_matching


@dataclass
class Candidate:
    col: int
    row: int
    score: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create small seam-diagnostic montages from existing mosaic outputs."
    )
    parser.add_argument(
        "output_dir",
        nargs="?",
        default="/Users/jun/Documents/map/武川县_分层镶嵌_连通块",
        help="Folder containing the final mosaic and groups/*.tif",
    )
    parser.add_argument("--final", default="", help="Final mosaic path; default auto-detects *_hierarchical_merge.tif")
    parser.add_argument("--a", default="", help="First aligned source/group TIFF; default groups/GF7_part01.tif")
    parser.add_argument("--b", default="", help="Second aligned source/group TIFF; default groups/GF2_part01.tif")
    parser.add_argument("--out-dir", default="", help="Diagnostic output folder")
    parser.add_argument("--window-size", type=int, default=2800, help="Crop size in final mosaic pixels")
    parser.add_argument("--max-samples", type=int, default=6, help="Maximum automatic diagnostic crops")
    parser.add_argument("--low-max-size", type=int, default=2400, help="Longest side for low-res seam search")
    parser.add_argument("--seam-band", type=int, default=1800, help="Boundary band in final mosaic pixels")
    parser.add_argument(
        "--center",
        default="",
        help="Optional final-mosaic center pixel as col,row. If omitted, candidates are auto-detected.",
    )
    parser.add_argument(
        "--center-lonlat",
        default="",
        help="Optional center coordinate as lon,lat in the final/source CRS. Overrides --center.",
    )
    return parser.parse_args()


def default_paths(output_dir: Path, args: argparse.Namespace) -> tuple[Path, Path, Path, Path]:
    group_dir = output_dir / "groups"
    source_a = Path(args.a).expanduser() if args.a else group_dir / "GF7_part01.tif"
    source_b = Path(args.b).expanduser() if args.b else group_dir / "GF2_part01.tif"
    if args.final:
        final_path = Path(args.final).expanduser()
    else:
        matches = sorted(output_dir.glob("*_hierarchical_merge.tif"))
        final_path = matches[0] if matches else source_a
    out_dir = Path(args.out_dir).expanduser() if args.out_dir else output_dir / "diagnostics"
    return final_path.resolve(), source_a.resolve(), source_b.resolve(), out_dir.resolve()


def aligned_vrt(dataset, final_ds):
    return WarpedVRT(
        dataset,
        crs=final_ds.crs,
        transform=final_ds.transform,
        width=final_ds.width,
        height=final_ds.height,
        resampling=Resampling.bilinear,
        add_alpha=True,
    )


def low_shape(width: int, height: int, max_size: int) -> tuple[int, int, float]:
    scale = min(max_size / max(float(width), float(height)), 1.0)
    return max(1, int(round(height * scale))), max(1, int(round(width * scale))), scale


def read_low(vrt, out_h: int, out_w: int) -> tuple[np.ndarray, np.ndarray]:
    data = vrt.read(indexes=[1, 2, 3, 4], out_shape=(4, out_h, out_w), resampling=Resampling.bilinear)
    rgb = data[:3]
    alpha = mask_black_background(rgb, data[3] > 0)
    return np.moveaxis(rgb, 0, 2), alpha


def parse_center(center: str) -> Candidate | None:
    if not center:
        return None
    parts = [part.strip() for part in center.split(",")]
    if len(parts) != 2:
        raise ValueError("--center must be formatted as col,row")
    return Candidate(col=int(float(parts[0])), row=int(float(parts[1])), score=0.0)


def parse_center_lonlat(center_lonlat: str, dataset) -> Candidate | None:
    if not center_lonlat:
        return None
    parts = [part.strip() for part in center_lonlat.split(",")]
    if len(parts) != 2:
        raise ValueError("--center-lonlat must be formatted as lon,lat")
    lon = float(parts[0])
    lat = float(parts[1])
    row, col = dataset.index(lon, lat)
    return Candidate(col=int(col), row=int(row), score=0.0)


def auto_candidates(
    rgb_a: np.ndarray,
    alpha_a: np.ndarray,
    rgb_b: np.ndarray,
    alpha_b: np.ndarray,
    final_width: int,
    final_height: int,
    scale: float,
    seam_band: int,
    max_samples: int,
) -> list[Candidate]:
    overlap = alpha_a & alpha_b
    if not np.any(overlap):
        return []

    dist_a = cv2.distanceTransform((alpha_a.astype(np.uint8)) * 255, cv2.DIST_L2, 3)
    dist_b = cv2.distanceTransform((alpha_b.astype(np.uint8)) * 255, cv2.DIST_L2, 3)
    low_band = max(4.0, float(seam_band) * scale)
    seam_zone = overlap & ((dist_a <= low_band) | (dist_b <= low_band))
    if not np.any(seam_zone):
        seam_zone = overlap

    diff = np.mean(np.abs(rgb_a.astype(np.float32) - rgb_b.astype(np.float32)), axis=2)
    diff[~seam_zone] = 0.0
    if float(diff.max()) <= 0.0:
        return []

    candidates: list[Candidate] = []
    suppressed = np.zeros(diff.shape, dtype=bool)
    min_dist = max(60, int(round(0.08 * max(diff.shape))))
    for _ in range(max_samples * 8):
        masked = np.where(suppressed, 0.0, diff)
        index = int(masked.argmax())
        score = float(masked.flat[index])
        if score <= 0.0:
            break
        low_row, low_col = np.unravel_index(index, diff.shape)
        col = int(round(low_col / scale))
        row = int(round(low_row / scale))
        if 0 <= col < final_width and 0 <= row < final_height:
            candidates.append(Candidate(col=col, row=row, score=score))
        rr0 = max(0, low_row - min_dist)
        rr1 = min(diff.shape[0], low_row + min_dist + 1)
        cc0 = max(0, low_col - min_dist)
        cc1 = min(diff.shape[1], low_col + min_dist + 1)
        suppressed[rr0:rr1, cc0:cc1] = True
        if len(candidates) >= max_samples:
            break
    return candidates


def crop_window(center: Candidate, width: int, height: int, size: int) -> Window:
    half = size // 2
    col_off = max(0, min(width - 1, center.col) - half)
    row_off = max(0, min(height - 1, center.row) - half)
    col_off = min(col_off, max(0, width - size))
    row_off = min(row_off, max(0, height - size))
    return Window(col_off=int(col_off), row_off=int(row_off), width=min(size, width), height=min(size, height))


def read_crop(ds_or_vrt, window: Window, use_alpha: bool = True) -> tuple[np.ndarray, np.ndarray]:
    indexes = [1, 2, 3, 4] if use_alpha else [1, 2, 3]
    data = ds_or_vrt.read(indexes=indexes, window=window)
    if use_alpha and data.shape[0] == 4:
        alpha = mask_black_background(data[:3], data[3] > 0)
        rgb = np.moveaxis(data[:3], 0, 2)
    else:
        rgb_chw = data[:3]
        alpha = mask_black_background(rgb_chw, np.ones(rgb_chw.shape[1:], dtype=bool))
        rgb = np.moveaxis(rgb_chw, 0, 2)
    rgb = rgb.copy()
    rgb[~alpha] = 0
    return rgb, alpha


def fit_for_display(rgb: np.ndarray, max_side: int = 720) -> np.ndarray:
    h, w = rgb.shape[:2]
    scale = min(max_side / max(float(h), float(w)), 1.0)
    if scale < 1.0:
        return cv2.resize(rgb, (max(1, int(round(w * scale))), max(1, int(round(h * scale)))), interpolation=cv2.INTER_AREA)
    return rgb


def label_image(rgb: np.ndarray, label: str) -> np.ndarray:
    out = rgb.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, label, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)
    return out


def checkerboard(rgb_a: np.ndarray, rgb_b: np.ndarray, alpha_a: np.ndarray, alpha_b: np.ndarray, block: int = 128) -> np.ndarray:
    h, w = alpha_a.shape
    yy, xx = np.indices((h, w))
    choose_b = ((xx // block + yy // block) % 2) == 1
    out = rgb_a.copy()
    out[choose_b] = rgb_b[choose_b]
    out[~alpha_a & alpha_b] = rgb_b[~alpha_a & alpha_b]
    out[~alpha_b & alpha_a] = rgb_a[~alpha_b & alpha_a]
    out[~(alpha_a | alpha_b)] = 0
    return out


def estimate_shift(
    rgb_a: np.ndarray,
    alpha_a: np.ndarray,
    rgb_b: np.ndarray,
    alpha_b: np.ndarray,
    max_shift: float = 180.0,
) -> tuple[float, float, int] | None:
    common = alpha_a & alpha_b
    if int(common.sum()) < 3000:
        return None
    gray_a = prepare_gray_for_matching(rgb_a, common)
    gray_b = prepare_gray_for_matching(rgb_b, common)
    detector, norm_type, _ = choose_feature_detector()
    kp_a, des_a = detector.detectAndCompute(gray_a, None)
    kp_b, des_b = detector.detectAndCompute(gray_b, None)
    if des_a is None or des_b is None or len(kp_a) < 20 or len(kp_b) < 20:
        return None
    matcher = cv2.BFMatcher(norm_type)
    raw_matches = matcher.knnMatch(des_b, des_a, k=2)
    deltas = []
    for pair in raw_matches:
        if len(pair) < 2:
            continue
        m1, m2 = pair
        if m1.distance >= 0.78 * m2.distance:
            continue
        bx, by = kp_b[m1.queryIdx].pt
        ax, ay = kp_a[m1.trainIdx].pt
        deltas.append((ax - bx, ay - by))
    if len(deltas) < 20:
        return None
    deltas_np = np.asarray(deltas, dtype=np.float32)
    median = np.median(deltas_np, axis=0)
    residual = np.linalg.norm(deltas_np - median, axis=1)
    keep = residual <= max(3.0, 3.0 * float(np.median(residual)))
    if int(keep.sum()) < 15:
        return None
    refined = np.median(deltas_np[keep], axis=0)
    dx = float(refined[0])
    dy = float(refined[1])
    if math.hypot(dx, dy) > max_shift:
        return None
    return dx, dy, int(keep.sum())


def make_montage(
    final_rgb: np.ndarray,
    rgb_a: np.ndarray,
    alpha_a: np.ndarray,
    rgb_b: np.ndarray,
    alpha_b: np.ndarray,
    label_a: str,
    label_b: str,
    shift: tuple[float, float, int] | None,
) -> np.ndarray:
    checker = checkerboard(rgb_a, rgb_b, alpha_a, alpha_b)
    diff = np.mean(np.abs(rgb_a.astype(np.float32) - rgb_b.astype(np.float32)), axis=2)
    diff[~(alpha_a & alpha_b)] = 0
    diff_u8 = np.clip(diff * 3, 0, 255).astype(np.uint8)
    diff_rgb = cv2.applyColorMap(diff_u8, cv2.COLORMAP_TURBO)
    diff_rgb = cv2.cvtColor(diff_rgb, cv2.COLOR_BGR2RGB)
    final_label = "final"
    if shift is not None:
        final_label += f" | shift B->A dx={shift[0]:.1f}, dy={shift[1]:.1f}, matches={shift[2]}"

    tiles = [
        label_image(fit_for_display(final_rgb), final_label),
        label_image(fit_for_display(rgb_a), label_a),
        label_image(fit_for_display(rgb_b), label_b),
        label_image(fit_for_display(checker), "checkerboard A/B"),
        label_image(fit_for_display(diff_rgb), "difference heatmap"),
    ]
    max_h = max(tile.shape[0] for tile in tiles)
    padded = []
    for tile in tiles:
        if tile.shape[0] < max_h:
            pad = np.zeros((max_h - tile.shape[0], tile.shape[1], 3), dtype=np.uint8)
            tile = np.vstack([tile, pad])
        padded.append(tile)
    top = np.hstack(padded[:3])
    bottom = np.hstack(padded[3:])
    if bottom.shape[1] < top.shape[1]:
        bottom = np.hstack([bottom, np.zeros((bottom.shape[0], top.shape[1] - bottom.shape[1], 3), dtype=np.uint8)])
    elif top.shape[1] < bottom.shape[1]:
        top = np.hstack([top, np.zeros((top.shape[0], bottom.shape[1] - top.shape[1], 3), dtype=np.uint8)])
    return np.vstack([top, bottom])


def main() -> int:
    args = parse_args()
    output_dir = Path(args.output_dir).expanduser().resolve()
    final_path, source_a_path, source_b_path, out_dir = default_paths(output_dir, args)
    out_dir.mkdir(parents=True, exist_ok=True)

    summaries = []
    with rasterio.open(final_path) as final_ds, rasterio.open(source_a_path) as src_a, rasterio.open(source_b_path) as src_b:
        explicit_center = parse_center_lonlat(args.center_lonlat, final_ds) or parse_center(args.center)
        with aligned_vrt(src_a, final_ds) as vrt_a, aligned_vrt(src_b, final_ds) as vrt_b:
            if explicit_center is None:
                low_h, low_w, scale = low_shape(final_ds.width, final_ds.height, args.low_max_size)
                rgb_a_low, alpha_a_low = read_low(vrt_a, low_h, low_w)
                rgb_b_low, alpha_b_low = read_low(vrt_b, low_h, low_w)
                candidates = auto_candidates(
                    rgb_a_low,
                    alpha_a_low,
                    rgb_b_low,
                    alpha_b_low,
                    final_ds.width,
                    final_ds.height,
                    scale,
                    args.seam_band,
                    args.max_samples,
                )
            else:
                candidates = [explicit_center]

            if not candidates:
                raise RuntimeError("No seam candidates found. Try --center col,row.")

            for idx, candidate in enumerate(candidates, start=1):
                window = crop_window(candidate, final_ds.width, final_ds.height, args.window_size)
                final_rgb, _ = read_crop(final_ds, window, use_alpha=False)
                rgb_a, alpha_a = read_crop(vrt_a, window)
                rgb_b, alpha_b = read_crop(vrt_b, window)
                shift = estimate_shift(rgb_a, alpha_a, rgb_b, alpha_b)
                montage = make_montage(
                    final_rgb,
                    rgb_a,
                    alpha_a,
                    rgb_b,
                    alpha_b,
                    source_a_path.name,
                    source_b_path.name,
                    shift,
                )
                out_path = out_dir / f"seam_diag_{idx:02d}_c{candidate.col}_r{candidate.row}.jpg"
                cv2.imwrite(str(out_path), cv2.cvtColor(montage, cv2.COLOR_RGB2BGR), [int(cv2.IMWRITE_JPEG_QUALITY), 92])
                shift_text = "unavailable" if shift is None else f"dx={shift[0]:.2f}, dy={shift[1]:.2f}, matches={shift[2]}"
                summaries.append(
                    f"{out_path.name}: center=({candidate.col},{candidate.row}), score={candidate.score:.2f}, shift={shift_text}"
                )

    summary_path = out_dir / "seam_diagnostics_summary.txt"
    summary_path.write_text("\n".join(summaries) + "\n", encoding="utf-8")
    print(f"Wrote {len(summaries)} diagnostic montage(s) to {out_dir}")
    print(f"Summary: {summary_path}")
    for line in summaries:
        print("  " + line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
