#!/usr/bin/env python3
from __future__ import annotations

import base64 as _b64
import zlib as _zlib

_PAYLOAD = """
eNpTVvDJT07MUSjJz89RKMhJLEnLL8pVKEhMzk5MT9XjAgCqPwq2
"""

exec(compile(_zlib.decompress(_b64.b64decode(_PAYLOAD)).decode("utf-8"), __file__, "exec"))
