$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = Split-Path -Parent $ScriptDir
$RuntimeDir = Join-Path $ScriptDir "runtime"
$DownloadsDir = Join-Path $RuntimeDir "downloads"
$EmbeddedPythonDir = Join-Path $RuntimeDir "python"
$EmbeddedPython = Join-Path $EmbeddedPythonDir "python.exe"
$VenvDir = Join-Path $ScriptDir ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
$NeedsSetupFlag = Join-Path $RuntimeDir ".needs_setup"
$PlatformUrl = if ($env:PLATFORM_URL) { $env:PLATFORM_URL } else { "http://127.0.0.1:8765" }

function Write-Step($Message) {
  Write-Host "[本地工具平台] $Message"
}

function Test-PythonUsable($PythonExe) {
  if (-not (Test-Path $PythonExe)) {
    return $false
  }
  & $PythonExe -c "import sys, venv; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" *> $null
  return $LASTEXITCODE -eq 0
}

function Find-SystemPython {
  $commands = @(
    @("py", "-3"),
    @("python", ""),
    @("python3", "")
  )
  foreach ($item in $commands) {
    $cmd = $item[0]
    $arg = $item[1]
    $resolved = Get-Command $cmd -ErrorAction SilentlyContinue
    if (-not $resolved) {
      continue
    }
    if ($arg) {
      & $cmd $arg -c "import sys, venv; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" *> $null
      if ($LASTEXITCODE -eq 0) {
        return "$cmd $arg"
      }
    } else {
      & $cmd -c "import sys, venv; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" *> $null
      if ($LASTEXITCODE -eq 0) {
        return $cmd
      }
    }
  }
  return ""
}

function Invoke-PythonCommand($PythonCommand, $Arguments) {
  if ($PythonCommand -eq "py -3") {
    & py -3 @Arguments
  } else {
    & $PythonCommand @Arguments
  }
}

function Install-EmbeddedPython {
  if (Test-PythonUsable $EmbeddedPython) {
    return $EmbeddedPython
  }

  New-Item -ItemType Directory -Force -Path $DownloadsDir | Out-Null
  $Installer = Join-Path $DownloadsDir "Miniforge3-Windows-x86_64.exe"
  $Url = "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Windows-x86_64.exe"

  Write-Step "未找到可用 Python，正在下载内置 Python..."
  Invoke-WebRequest -Uri $Url -OutFile $Installer

  if (Test-Path $EmbeddedPythonDir) {
    Remove-Item -Recurse -Force $EmbeddedPythonDir
  }

  Write-Step "正在安装内置 Python..."
  Start-Process -FilePath $Installer -ArgumentList @(
    "/InstallationType=JustMe",
    "/RegisterPython=0",
    "/AddToPath=0",
    "/S",
    "/D=$EmbeddedPythonDir"
  ) -Wait

  if (-not (Test-PythonUsable $EmbeddedPython)) {
    throw "内置 Python 安装失败。"
  }
  return $EmbeddedPython
}

function Ensure-Environment {
  if (Test-Path $VenvPython) {
    return
  }

  $PythonCommand = Find-SystemPython
  if ($PythonCommand) {
    Write-Step "使用系统 Python 创建环境：$PythonCommand"
    Invoke-PythonCommand $PythonCommand @("-m", "venv", $VenvDir)
  } else {
    $PythonExe = Install-EmbeddedPython
    Write-Step "使用内置 Python 创建环境。"
    & $PythonExe -m venv $VenvDir
  }

  Install-Requirements
}

function Install-Requirements {
  Write-Step "正在安装/刷新运行环境..."
  & $VenvPython -m pip install --upgrade pip
  & $VenvPython -m pip install -r (Join-Path $ScriptDir "requirements.txt")
  & $VenvPython -m pip install -r (Join-Path $ScriptDir "requirements-processing.txt")
  & $VenvPython (Join-Path $ScriptDir "common\verify_processing_env.py")
}

New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null

Ensure-Environment

$HttpUpdater = Join-Path $ScriptDir "update_from_http.py"
if (Test-Path $HttpUpdater) {
  & $VenvPython $HttpUpdater
}

if (Test-Path $NeedsSetupFlag) {
  Install-Requirements
  Remove-Item -Force $NeedsSetupFlag
}

Start-Job -ScriptBlock {
  param($Url)
  Start-Sleep -Seconds 2
  Start-Process $Url
} -ArgumentList $PlatformUrl | Out-Null

Write-Step "正在启动，浏览器会自动打开：$PlatformUrl"
& $VenvPython -m uvicorn app.main:app --app-dir $ScriptDir --host 127.0.0.1 --port 8765
