#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="${APP_NAME:-本地工具平台}"
UPDATE_MANIFEST_URL="${UPDATE_MANIFEST_URL:-}"
DIST_DIR="$ROOT_DIR/dist"
APP_PATH="$DIST_DIR/$APP_NAME.app"
RESOURCES_DIR="$APP_PATH/Contents/Resources"
MACOS_DIR="$APP_PATH/Contents/MacOS"
APP_CODE_DIR="$RESOURCES_DIR/tool-platform"

rm -rf "$APP_PATH"
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

rsync -a \
  --exclude '.git/' \
  --exclude 'dist/' \
  --exclude '.DS_Store' \
  --exclude '__pycache__/' \
  --exclude '*.pyc' \
  --exclude '*.tif' \
  --exclude '*.tiff' \
  --exclude '*.jpg' \
  --exclude '*.jpeg' \
  --exclude '*.png' \
  --exclude '*.aux.xml' \
  --exclude 'tool_platform/.venv/' \
  --exclude 'tool_platform/runtime/' \
  --exclude '武川县/' \
  --exclude '武川县_*/' \
  "$ROOT_DIR/" "$APP_CODE_DIR/"

cat > "$APP_PATH/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key>
  <string>LocalToolPlatform</string>
  <key>CFBundleIdentifier</key>
  <string>com.local.toolplatform</string>
  <key>CFBundleName</key>
  <string>$APP_NAME</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleShortVersionString</key>
  <string>0.2.0</string>
  <key>LSMinimumSystemVersion</key>
  <string>11.0</string>
</dict>
</plist>
EOF

cat > "$MACOS_DIR/LocalToolPlatform" <<EOF
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="\$(cd "\$(dirname "\$0")/.." && pwd)"
APP_ROOT="\$APP_DIR/Resources/tool-platform"
export OPEN_BROWSER=1
export AUTO_GIT_UPDATE=0
export TOOL_PLATFORM_MANIFEST_URL="$UPDATE_MANIFEST_URL"

exec /usr/bin/env bash "\$APP_ROOT/tool_platform/run_platform.sh"
EOF

chmod +x "$MACOS_DIR/LocalToolPlatform"
chmod +x "$APP_CODE_DIR/tool_platform/bootstrap_setup.sh" \
  "$APP_CODE_DIR/tool_platform/setup_platform.sh" \
  "$APP_CODE_DIR/tool_platform/run_platform.sh" \
  "$APP_CODE_DIR/tool_platform/update_from_git.sh" \
  "$APP_CODE_DIR/tool_platform/tools/image_merge/run.sh" \
  "$APP_CODE_DIR/tool_platform/tools/tiff_mosaic_colorfill/run.sh"

echo "App created: $APP_PATH"
if [[ -z "$UPDATE_MANIFEST_URL" ]]; then
  echo "Warning: UPDATE_MANIFEST_URL is empty; HTTP auto-update will be disabled."
fi
