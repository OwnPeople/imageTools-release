#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(cd "$ROOT_DIR/../.." && pwd)"
cd "$ROOT_DIR"

usage() {
  cat <<'EOF'
Usage:
  ./run.sh INPUT_DIR [OUTPUT_DIR] [OUTPUT_PREFIX]

Examples:
  ./run.sh 新区域
  ./run.sh 新区域 新区域_镶嵌结果
  ./run.sh /data/tifs /data/result my_area

Environment options:
  PYTHON_BIN=python3              Python executable
  MOSAIC_PATTERN=*.tif            Input file glob inside INPUT_DIR
  KEEP_GROUP_TIFS=1               Keep intermediate groups/*.tif for review; set 0 to delete
  RUN_DIAGNOSTICS=1               Run automatic seam diagnostics; set 0 to skip
  MAX_DIAG_PAIRS=6                Max group-pair diagnostics to generate
  DIAG_MAX_SAMPLES=4              Max seam crops per diagnostic pair
  SEAM_MATCH_NEW_SIDE=0           Set 1 to push seam color matching outward more aggressively
  COLOR_STRENGTH=0.45             Low-frequency color-balance strength
  COLOR_BLUR_SIGMA=90             Low-frequency color-balance blur sigma
  COLOR_MAX_OFFSET=36             Max per-channel color offset
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 1 ]]; then
  usage >&2
  exit 2
fi

INPUT_DIR="${1%/}"
INPUT_BASENAME="$(basename "$INPUT_DIR")"
OUTPUT_DIR="${2:-${INPUT_DIR}_镶嵌结果}"
OUTPUT_PREFIX="${3:-$INPUT_BASENAME}"

resolve_python_bin() {
  local candidates=()
  if [[ -n "${PYTHON_BIN:-}" ]]; then
    candidates+=("$PYTHON_BIN")
  else
    candidates+=(
      "$PLATFORM_DIR/.venv/bin/python"
      "/opt/anaconda3/bin/python3"
      "/opt/anaconda3/bin/python"
      "/Users/jun/miniconda3/bin/python"
      "python3"
    )
  fi

  local candidate
  local resolved
  for candidate in "${candidates[@]}"; do
    if [[ -x "$candidate" ]]; then
      resolved="$candidate"
    else
      resolved="$(command -v "$candidate" 2>/dev/null || true)"
    fi
    if [[ -z "$resolved" ]]; then
      continue
    fi
    if "$resolved" - <<'PY' >/dev/null 2>&1
import cv2
import numpy
import rasterio
PY
    then
      printf '%s\n' "$resolved"
      return 0
    fi
  done
  return 1
}

if ! PYTHON_BIN="$(resolve_python_bin)"; then
  cat >&2 <<'EOF'
No Python runtime with cv2, numpy, and rasterio was found.
Set PYTHON_BIN to the Python executable used for mosaic processing, for example:
  PYTHON_BIN=/opt/anaconda3/bin/python3 ./run.sh ...
EOF
  exit 1
fi
MOSAIC_PATTERN="${MOSAIC_PATTERN:-*.tif}"
KEEP_GROUP_TIFS="${KEEP_GROUP_TIFS:-1}"
RUN_DIAGNOSTICS="${RUN_DIAGNOSTICS:-1}"
MAX_DIAG_PAIRS="${MAX_DIAG_PAIRS:-6}"
DIAG_MAX_SAMPLES="${DIAG_MAX_SAMPLES:-4}"
DIAG_WINDOW_SIZE="${DIAG_WINDOW_SIZE:-2800}"
SEAM_MATCH_NEW_SIDE="${SEAM_MATCH_NEW_SIDE:-0}"

COLOR_STRENGTH="${COLOR_STRENGTH:-0.45}"
COLOR_BLUR_SIGMA="${COLOR_BLUR_SIGMA:-90}"
COLOR_MAX_OFFSET="${COLOR_MAX_OFFSET:-36}"

FINAL_NAME="${OUTPUT_PREFIX}_merge_FINAL.tif"
COLORFILL_NAME="${OUTPUT_PREFIX}_merge_FINAL_colorfill.tif"

FINAL_PATH="$OUTPUT_DIR/$FINAL_NAME"
FINAL_PREVIEW="$OUTPUT_DIR/${FINAL_NAME%.tif}_preview.jpg"
COLORFILL_PATH="$OUTPUT_DIR/$COLORFILL_NAME"
COLORFILL_PREVIEW="$OUTPUT_DIR/${COLORFILL_NAME%.tif}_preview.jpg"
COLORFILL_COMPARE="$OUTPUT_DIR/${COLORFILL_NAME%.tif}_compare.jpg"

shopt -s nullglob

if [[ ! -d "$INPUT_DIR" ]]; then
  echo "Input directory not found: $INPUT_DIR" >&2
  exit 1
fi

input_count="$(find "$INPUT_DIR" -maxdepth 1 -type f -name "$MOSAIC_PATTERN" | wc -l | tr -d ' ')"
if [[ "$input_count" -lt 2 ]]; then
  echo "Need at least two input files matching $MOSAIC_PATTERN under $INPUT_DIR, found $input_count." >&2
  exit 1
fi

seam_new_side_args=()
if [[ "$SEAM_MATCH_NEW_SIDE" != "1" ]]; then
  seam_new_side_args+=(--no-seam-color-match-new-side)
fi

run_auto_diagnostics() {
  local group_dir="$OUTPUT_DIR/groups"
  if [[ ! -d "$group_dir" ]]; then
    echo "  - skip diagnostics: no groups folder"
    return
  fi

  local group_tifs=("$group_dir"/*.tif)
  if [[ "${#group_tifs[@]}" -lt 2 ]]; then
    echo "  - skip diagnostics: fewer than two group TIFFs"
    return
  fi

  local pair_count=0
  local i
  local j
  for ((i = 0; i < ${#group_tifs[@]}; i++)); do
    for ((j = i + 1; j < ${#group_tifs[@]}; j++)); do
      if [[ "$pair_count" -ge "$MAX_DIAG_PAIRS" ]]; then
        return
      fi

      pair_count=$((pair_count + 1))
      local base_a
      local base_b
      base_a="$(basename "${group_tifs[$i]}" .tif)"
      base_b="$(basename "${group_tifs[$j]}" .tif)"
      local out_dir="$OUTPUT_DIR/diagnostics_auto/pair_${pair_count}_${base_a}_vs_${base_b}"

      echo "  - diagnostic pair $pair_count: $base_a vs $base_b"
      if ! "$PYTHON_BIN" diagnose_mosaic_seams.py "$OUTPUT_DIR" \
        --final "$FINAL_PATH" \
        --a "${group_tifs[$i]}" \
        --b "${group_tifs[$j]}" \
        --out-dir "$out_dir" \
        --max-samples "$DIAG_MAX_SAMPLES" \
        --window-size "$DIAG_WINDOW_SIZE"; then
        echo "    warning: diagnostic failed for $base_a vs $base_b; continuing"
      fi
    done
  done
}

echo "== Generic mosaic + color-fill pipeline =="
echo "Input:             $INPUT_DIR"
echo "Output:            $OUTPUT_DIR"
echo "Output prefix:     $OUTPUT_PREFIX"
echo "Input pattern:     $MOSAIC_PATTERN"
echo "Input TIFF count:  $input_count"
echo "Keep group TIFFs:  $KEEP_GROUP_TIFS"
echo "Run diagnostics:   $RUN_DIAGNOSTICS"
echo

echo "[1/5] Building final mosaic..."
"$PYTHON_BIN" mosaic_tiffs_hierarchical.py "$INPUT_DIR" \
  --output-dir "$OUTPUT_DIR" \
  --output-name "$FINAL_NAME" \
  --pattern "$MOSAIC_PATTERN" \
  --group-register-mode none \
  --group-method feather \
  --group-seam-register \
  --final-method feather \
  --final-seam-register \
  --seam-register-max-shift 220 \
  --seam-register-band 3000 \
  --seam-register-max-size 2600 \
  --final-radiometric-match \
  --final-radiometric-strength 0.28 \
  --final-radiometric-max-offset 24 \
  --final-radiometric-gain-strength 0.10 \
  --seam-color-match-strength 0.55 \
  --seam-color-match-max-offset 32 \
  --seam-color-match-gain-strength 0.20 \
  --seam-color-match-min-pixels 1600 \
  "${seam_new_side_args[@]}" \
  --resampling bilinear \
  --tile-size 1024 \
  --compress lzw \
  --ignore-read-errors \
  --overwrite

echo
if [[ "$RUN_DIAGNOSTICS" == "1" ]]; then
  echo "[2/5] Running automatic seam diagnostics..."
  run_auto_diagnostics
else
  echo "[2/5] Seam diagnostics skipped."
fi

echo
if [[ "$KEEP_GROUP_TIFS" == "1" ]]; then
  echo "[3/5] Keeping intermediate group TIFFs for review."
else
  echo "[3/5] Removing intermediate group TIFFs..."
  for tif in "$OUTPUT_DIR"/groups/*.tif; do
    rm -f "$tif"
  done
fi

echo
echo "[4/5] Running color balancing and small-hole filling..."
preview_input_args=()
if [[ -f "$FINAL_PREVIEW" ]]; then
  preview_input_args+=(--preview-input "$FINAL_PREVIEW")
fi

"$PYTHON_BIN" postprocess_mosaic_color_fill.py "$FINAL_PATH" \
  "${preview_input_args[@]}" \
  --output "$COLORFILL_PATH" \
  --preview-output "$COLORFILL_PREVIEW" \
  --comparison-output "$COLORFILL_COMPARE" \
  --strength "$COLOR_STRENGTH" \
  --blur-sigma "$COLOR_BLUR_SIGMA" \
  --max-offset "$COLOR_MAX_OFFSET" \
  --preview-hole-max-area 24000 \
  --preview-hole-max-span 260 \
  --hole-min-fill-ratio 0.65 \
  --compress lzw \
  --overwrite

echo
echo "[5/5] Done."
echo "Final GeoTIFF:     $COLORFILL_PATH"
echo "Preview JPG:       $COLORFILL_PREVIEW"
echo "Comparison JPG:    $COLORFILL_COMPARE"
echo "Original mosaic:   $FINAL_PATH"
if [[ "$RUN_DIAGNOSTICS" == "1" ]]; then
  echo "Diagnostics:       $OUTPUT_DIR/diagnostics_auto"
fi
