const state = {
  tools: [],
  selectedToolId: null,
  scannedItems: [],
  scanMessage: "",
  tasks: [],
  selectedTaskId: null,
  followLatestTask: true,
  gitUpdate: null,
};

const ACTIVE_TASK_STATUSES = new Set(["PENDING", "RUNNING", "CANCELING"]);
const FINISHED_TASK_STATUSES = new Set(["SUCCESS", "FAILED", "CANCELED"]);

function apiErrorMessage(text, fallback) {
  try {
    const data = JSON.parse(text);
    if (typeof data.detail === "string") {
      return data.detail;
    }
    if (Array.isArray(data.detail) && data.detail.length > 0) {
      return data.detail.map((item) => item.msg || JSON.stringify(item)).join("；");
    }
  } catch (error) {
    // Plain-text errors are handled below.
  }
  return text || fallback;
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(apiErrorMessage(text, `请求失败：${response.status}`));
  }
  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }
  return response.text();
}

function selectedTool() {
  return state.tools.find((tool) => tool.id === state.selectedToolId) || null;
}

function toolDisplayName(toolId) {
  return state.tools.find((tool) => tool.id === toolId)?.name || toolId;
}

function taskStatusLabel(status) {
  const labels = {
    PENDING: "排队中",
    RUNNING: "处理中",
    SUCCESS: "已完成",
    FAILED: "失败",
    CANCELING: "取消中",
    CANCELED: "已取消",
  };
  return labels[status] || status;
}

function canCancelTask(task) {
  return task && (task.status === "PENDING" || task.status === "RUNNING");
}

function canDeleteTask(task) {
  return task && FINISHED_TASK_STATUSES.has(task.status);
}

function setRunFeedback(message, type = "info") {
  const element = document.getElementById("run-feedback");
  element.textContent = message || "";
  element.className = `run-feedback ${message ? type : ""}`;
}

function getInputPath() {
  return document.getElementById("input-path").value.trim();
}

function renderInputHint() {
  const tool = selectedTool();
  document.getElementById("input-path").placeholder = tool?.input_hint || "/Users/.../输入目录";
}

function toolOptionValues() {
  const tool = selectedTool();
  const options = {};
  if (!tool) {
    return options;
  }
  for (const option of tool.options || []) {
    const element = document.getElementById(`option-${option.id}`);
    if (!element) {
      continue;
    }
    if (option.type === "boolean") {
      options[option.id] = element.checked;
    } else {
      options[option.id] = element.value;
    }
  }
  return options;
}

function renderTools() {
  const container = document.getElementById("tools-list");
  container.innerHTML = "";
  for (const tool of state.tools) {
    const isSelected = tool.id === state.selectedToolId;
    const card = document.createElement("div");
    card.className = `tool-card ${isSelected ? "active" : ""}`;
    card.innerHTML = `
      <div class="tool-card-top">
        <div class="tool-copy">
          <strong>${tool.name}</strong>
          <p class="task-message">${tool.description}</p>
        </div>
        <button type="button" class="tool-select-button ${isSelected ? "is-selected" : ""}">${isSelected ? "已选择" : "选择"}</button>
      </div>
    `;
    card.querySelector("button").addEventListener("click", () => {
      state.selectedToolId = tool.id;
      state.scannedItems = [];
      state.scanMessage = "";
      renderTools();
      renderOptions();
      renderInputHint();
      renderScanResults();
      setRunFeedback("");
    });
    container.appendChild(card);
  }
}

function renderOptions() {
  const container = document.getElementById("options-block");
  const tool = selectedTool();
  container.innerHTML = "";
  if (!tool) {
    return;
  }
  renderInputHint();
  for (const option of tool.options || []) {
    if (option.type === "boolean") {
      const row = document.createElement("label");
      row.className = "checkbox-row";
      row.innerHTML = `
        <input id="option-${option.id}" type="checkbox" ${option.default ? "checked" : ""}>
        <span>${option.label}</span>
      `;
      container.appendChild(row);
      continue;
    }
    const field = document.createElement("label");
    field.className = "field";
    field.innerHTML = `
      <span>${option.label}</span>
      <input id="option-${option.id}" type="text" value="${option.default ?? ""}">
    `;
    container.appendChild(field);
  }
}

function renderScanResults() {
  document.getElementById("scan-count").textContent = String(state.scannedItems.length);
  const list = document.getElementById("scan-list");
  list.innerHTML = "";
  if (state.scannedItems.length === 0 && state.scanMessage) {
    const li = document.createElement("li");
    li.className = "scan-item scan-empty";
    li.textContent = state.scanMessage;
    list.appendChild(li);
    return;
  }
  for (const item of state.scannedItems) {
    const li = document.createElement("li");
    li.className = "scan-item";
    li.textContent = item;
    list.appendChild(li);
  }
}

function taskActions(task) {
  const actions = [];
  if (canCancelTask(task)) {
    actions.push(`<button type="button" class="secondary danger" data-cancel-task="${task.id}">取消任务</button>`);
  }
  if (task.output_path && (task.status === "SUCCESS" || task.status === "FAILED")) {
    actions.push(`<button type="button" class="secondary" data-open-path="${task.output_path}">打开结果目录</button>`);
  }
  if (canDeleteTask(task)) {
    actions.push(`<button type="button" class="secondary danger" data-delete-task="${task.id}">删除记录</button>`);
  }
  return actions.join("");
}

function renderTaskCleanupState(tasks) {
  const button = document.getElementById("clear-finished-btn");
  if (!button) {
    return;
  }
  const count = tasks.filter(canDeleteTask).length;
  button.disabled = count === 0;
  button.textContent = count === 0 ? "暂无可清理" : `清空已结束（${count}）`;
}

function renderTasks(tasks) {
  const container = document.getElementById("tasks-list");
  container.innerHTML = "";
  renderTaskCleanupState(tasks);
  if (tasks.length === 0) {
    container.innerHTML = `<div class="task-empty">还没有任务。选择目录后，点击处理即可自动显示进度日志。</div>`;
    return;
  }
  for (const task of tasks) {
    const card = document.createElement("div");
    card.className = `task-card ${task.id === state.selectedTaskId ? "selected" : ""}`;
    card.innerHTML = `
      <div class="task-card-top">
        <div>
          <strong>${toolDisplayName(task.tool_id)}</strong>
          <p class="task-path">${task.input_path}</p>
        </div>
        <span class="task-status ${task.status}">${taskStatusLabel(task.status)}</span>
      </div>
      <div class="task-card-bottom">
        <p class="task-message">${task.message || ""}</p>
        <span class="task-time">${task.created_at}</span>
      </div>
      <div class="task-actions">${taskActions(task)}</div>
    `;
    card.addEventListener("click", (event) => {
      if (event.target.closest("button")) {
        return;
      }
      loadLog(task.id, { manual: true });
    });
    for (const button of card.querySelectorAll("[data-open-path]")) {
      button.addEventListener("click", async () => {
        await openTaskPath(button);
      });
    }
    for (const button of card.querySelectorAll("[data-cancel-task]")) {
      button.addEventListener("click", async () => {
        await cancelTask(button.dataset.cancelTask);
      });
    }
    for (const button of card.querySelectorAll("[data-delete-task]")) {
      button.addEventListener("click", async () => {
        await deleteTask(button.dataset.deleteTask);
      });
    }
    container.appendChild(card);
  }
}

function chooseTaskToShow(tasks) {
  if (tasks.length === 0) {
    state.selectedTaskId = null;
    state.followLatestTask = true;
    return;
  }
  const selectedStillExists = tasks.some((task) => task.id === state.selectedTaskId);
  if (!state.followLatestTask && selectedStillExists) {
    return;
  }
  const activeTask = tasks.find((task) => ACTIVE_TASK_STATUSES.has(task.status));
  state.selectedTaskId = (activeTask || tasks[0]).id;
}

async function openTaskPath(button) {
  const originalText = button.textContent;
  button.disabled = true;
  button.textContent = "正在打开...";
  try {
    await api("/api/open-path", {
      method: "POST",
      body: JSON.stringify({ path: button.dataset.openPath }),
    });
    button.textContent = "已打开";
    setRunFeedback("已打开结果目录。", "success");
  } catch (error) {
    button.textContent = "打开失败";
    setRunFeedback(`打开结果目录失败：${error.message}`, "error");
  } finally {
    window.setTimeout(() => {
      button.disabled = false;
      button.textContent = originalText;
    }, 1800);
  }
}

async function loadLog(taskId, options = {}) {
  if (options.manual) {
    state.followLatestTask = false;
  }
  state.selectedTaskId = taskId;
  const task = state.tasks.find((item) => item.id === taskId);
  if (task) {
    document.getElementById("log-title").textContent = `正在查看：${toolDisplayName(task.tool_id)}（${taskStatusLabel(task.status)}）`;
  } else {
    document.getElementById("log-title").textContent = "正在查看任务日志";
  }
  const text = await api(`/api/tasks/${taskId}/log`);
  const viewer = document.getElementById("log-viewer");
  viewer.textContent = text || "日志还没产生。";
  viewer.scrollTop = viewer.scrollHeight;
  renderTasks(state.tasks);
}

async function cancelTask(taskId) {
  if (!window.confirm("确定取消这个任务吗？")) {
    return;
  }
  await api(`/api/tasks/${taskId}/cancel`, { method: "POST" });
  state.selectedTaskId = taskId;
  state.followLatestTask = false;
  await refreshTasks();
}

async function deleteTask(taskId) {
  if (!window.confirm("确定删除这条任务记录和日志吗？结果文件不会删除。")) {
    return;
  }
  await api(`/api/tasks/${taskId}`, { method: "DELETE" });
  if (state.selectedTaskId === taskId) {
    state.selectedTaskId = null;
    state.followLatestTask = true;
  }
  await refreshTasks();
}

async function clearFinishedTasks() {
  const count = state.tasks.filter(canDeleteTask).length;
  if (count === 0) {
    return;
  }
  if (!window.confirm(`确定清空 ${count} 条已结束任务记录和日志吗？结果文件不会删除。`)) {
    return;
  }
  await api("/api/tasks/finished", { method: "DELETE" });
  state.selectedTaskId = null;
  state.followLatestTask = true;
  await refreshTasks();
}

async function refreshTasks() {
  const tasks = await api("/api/tasks");
  state.tasks = tasks;
  chooseTaskToShow(tasks);
  renderTasks(tasks);
  if (state.selectedTaskId) {
    try {
      await loadLog(state.selectedTaskId);
    } catch (error) {
      console.warn(error);
    }
  } else {
    document.getElementById("log-title").textContent = "最新任务日志会自动显示";
    document.getElementById("log-viewer").textContent = "";
  }
}

async function loadSystem() {
  const system = await api("/api/system");
  document.getElementById("platform-version").textContent = system.version;
  document.getElementById("tools-count").textContent = String(system.tools_count);
  document.getElementById("runtime-status").textContent = "正常";
  state.gitUpdate = system.git_update || null;
  renderGitUpdateStatus();
}

async function loadTools() {
  state.tools = await api("/api/tools");
  if (!state.selectedToolId && state.tools.length > 0) {
    state.selectedToolId = state.tools[0].id;
  }
  renderTools();
  renderOptions();
}

async function submitOne() {
  if (!state.selectedToolId) {
    setRunFeedback("请先选择工具。", "error");
    return;
  }
  const inputPath = getInputPath();
  if (!inputPath) {
    setRunFeedback("请先填写或选择输入目录。", "error");
    return;
  }
  setRunFeedback("正在提交任务...", "info");
  try {
    const task = await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({
        tool_id: state.selectedToolId,
        input_path: inputPath,
        options: toolOptionValues(),
      }),
    });
    if (task.id) {
      state.selectedTaskId = task.id;
      state.followLatestTask = false;
    }
    setRunFeedback("已加入任务队列，日志会自动显示。", "success");
    await refreshTasks();
  } catch (error) {
    setRunFeedback(`${error.message} 如果这个目录里是多张 GeoTIFF，请改选“TIFF 镶嵌 + 色彩填补”。`, "error");
  }
}

async function scanInputs() {
  if (!state.selectedToolId) {
    setRunFeedback("请先选择工具。", "error");
    return;
  }
  const rootPath = getInputPath();
  if (!rootPath) {
    setRunFeedback("请先填写或选择父目录。", "error");
    return;
  }
  setRunFeedback("正在扫描子目录...", "info");
  try {
    const result = await api("/api/scan", {
      method: "POST",
      body: JSON.stringify({
        tool_id: state.selectedToolId,
        root_path: rootPath,
      }),
    });
    state.scannedItems = result.items || [];
    state.scanMessage = state.scannedItems.length === 0
      ? "没有扫到可处理的影像场景。请确认目录下是否有场景子目录，或改选适合该目录的工具。"
      : "";
    renderScanResults();
    setRunFeedback(
      state.scannedItems.length === 0 ? state.scanMessage : `已扫描到 ${state.scannedItems.length} 个可处理目录。`,
      state.scannedItems.length === 0 ? "warning" : "success",
    );
  } catch (error) {
    state.scannedItems = [];
    state.scanMessage = error.message;
    renderScanResults();
    setRunFeedback(error.message, "error");
  }
}

async function submitBatch() {
  if (!state.selectedToolId) {
    setRunFeedback("请先选择工具。", "error");
    return;
  }
  if (state.scannedItems.length === 0) {
    setRunFeedback("请先扫描出可处理目录，再批量入队。", "error");
    return;
  }
  setRunFeedback("正在批量入队...", "info");
  try {
    const result = await api("/api/tasks/batch", {
      method: "POST",
      body: JSON.stringify({
        tool_id: state.selectedToolId,
        input_paths: state.scannedItems,
        options: toolOptionValues(),
      }),
    });
    if (result.tasks?.[0]?.id) {
      state.selectedTaskId = result.tasks[0].id;
      state.followLatestTask = false;
    }
    setRunFeedback(`已批量加入 ${result.count || 0} 个任务，日志会自动显示。`, "success");
    await refreshTasks();
  } catch (error) {
    setRunFeedback(error.message, "error");
  }
}

async function pickFolder() {
  setRunFeedback("正在打开文件夹选择器...", "info");
  try {
    const result = await api("/api/pick-folder", {
      method: "POST",
      body: JSON.stringify({ initial_dir: getInputPath() || "/" }),
    });
    if (result.path) {
      document.getElementById("input-path").value = result.path;
      setRunFeedback("已选择输入目录。", "success");
    } else {
      setRunFeedback("");
    }
  } catch (error) {
    setRunFeedback(error.message, "error");
  }
}

function formatDateTime(value) {
  if (!value) {
    return "-";
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }
  return date.toLocaleString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function renderGitUpdateStatus() {
  const status = state.gitUpdate || {};
  const stateText = status.message || "启动时会自动检查更新。";
  document.getElementById("app-version").textContent = document.getElementById("platform-version").textContent || "-";
  document.getElementById("update-status-text").textContent = stateText;
  document.getElementById("update-checked-at").textContent = formatDateTime(status.last_checked_at);
}

async function main() {
  await loadSystem();
  await loadTools();
  await refreshTasks();

  document.getElementById("submit-one-btn").addEventListener("click", submitOne);
  document.getElementById("scan-btn").addEventListener("click", scanInputs);
  document.getElementById("submit-batch-btn").addEventListener("click", submitBatch);
  document.getElementById("pick-folder-btn").addEventListener("click", pickFolder);
  document.getElementById("clear-finished-btn").addEventListener("click", clearFinishedTasks);

  setInterval(refreshTasks, 3000);
}

main().catch((error) => {
  console.error(error);
  alert(`启动失败：${error.message}`);
});
