#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"
PYTHON_BIN="${PYTHON:-python3}"
INSTALL_PROCESSING_DEPS="${INSTALL_PROCESSING_DEPS:-1}"
VERIFY_PROCESSING_ENV="${VERIFY_PROCESSING_ENV:-$INSTALL_PROCESSING_DEPS}"

if [ ! -d "$VENV_DIR" ]; then
  "$PYTHON_BIN" -m venv "$VENV_DIR"
fi

"$VENV_DIR/bin/python" -m pip install --upgrade pip
"$VENV_DIR/bin/python" -m pip install -r "$SCRIPT_DIR/requirements.txt"

if [ "$INSTALL_PROCESSING_DEPS" = "1" ]; then
  "$VENV_DIR/bin/python" -m pip install -r "$SCRIPT_DIR/requirements-processing.txt"
fi

if [ "$VERIFY_PROCESSING_ENV" = "1" ]; then
  "$VENV_DIR/bin/python" "$SCRIPT_DIR/common/verify_processing_env.py"
fi

echo "Setup complete."
echo "Start with: $SCRIPT_DIR/run_platform.sh"
