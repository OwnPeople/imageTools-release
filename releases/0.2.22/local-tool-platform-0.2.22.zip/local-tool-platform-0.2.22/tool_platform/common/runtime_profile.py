#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import platform
import shlex
import subprocess
from typing import Dict


def detect_total_ram_bytes() -> int | None:
    system = platform.system().lower()
    if system == "darwin":
        try:
            value = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True).strip()
            return int(value)
        except (OSError, subprocess.SubprocessError, ValueError):
            return None
    if system == "linux":
        try:
            with open("/proc/meminfo", "r", encoding="utf-8") as handle:
                for line in handle:
                    if line.startswith("MemTotal:"):
                        return int(line.split()[1]) * 1024
        except (OSError, ValueError):
            return None
    if system == "windows":
        try:
            import ctypes

            class MemoryStatus(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            status = MemoryStatus()
            status.dwLength = ctypes.sizeof(status)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return int(status.ullTotalPhys)
        except (AttributeError, OSError, ValueError):
            return None
    return None


def ram_gib(total_ram_bytes: int | None) -> float | None:
    if total_ram_bytes is None:
        return None
    return total_ram_bytes / (1024**3)


def performance_profile() -> Dict[str, str]:
    cpu_count = max(1, os.cpu_count() or 1)
    total_ram = detect_total_ram_bytes()
    ram = ram_gib(total_ram)

    if ram is None:
        threads = min(4, cpu_count)
        tile_size = 1024
        colorfill_tile_size = 1536
        gdal_cachemax = 768
        label = "auto-unknown"
    elif ram <= 8:
        threads = min(2, cpu_count)
        tile_size = 768
        colorfill_tile_size = 1024
        gdal_cachemax = 512
        label = "auto-small"
    elif ram <= 16:
        threads = min(4, cpu_count)
        tile_size = 1024
        colorfill_tile_size = 1536
        gdal_cachemax = 1024
        label = "auto-medium"
    elif ram <= 32:
        threads = min(6, cpu_count)
        tile_size = 1536
        colorfill_tile_size = 2048
        gdal_cachemax = 1536
        label = "auto-large"
    else:
        threads = min(8, cpu_count)
        tile_size = 2048
        colorfill_tile_size = 3072
        gdal_cachemax = 2048
        label = "auto-xl"

    return {
        "TOOL_PROFILE_LABEL": label,
        "TOOL_CPU_COUNT": str(cpu_count),
        "TOOL_RAM_GIB": "unknown" if ram is None else f"{ram:.1f}",
        "TOOL_THREADS": str(max(1, threads)),
        "TOOL_GDAL_CACHEMAX_MB": str(gdal_cachemax),
        "TOOL_MOSAIC_TILE_SIZE": str(tile_size),
        "TOOL_COLORFILL_TILE_SIZE": str(colorfill_tile_size),
    }


def print_shell_exports(values: Dict[str, str]) -> None:
    for key, value in values.items():
        print(f"{key}={shlex.quote(value)}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Print an automatic runtime profile for local tools.")
    parser.add_argument("--shell", action="store_true", help="Print shell assignments")
    args = parser.parse_args()
    values = performance_profile()
    if args.shell:
        print_shell_exports(values)
    else:
        for key, value in values.items():
            print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
