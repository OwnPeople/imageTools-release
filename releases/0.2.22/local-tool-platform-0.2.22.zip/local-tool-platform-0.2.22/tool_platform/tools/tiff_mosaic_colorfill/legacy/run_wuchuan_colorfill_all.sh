#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
WORKSPACE_DIR="$(cd "$SCRIPT_DIR/../../../.." && pwd)"
cd "$TOOL_DIR"

INPUT_DIR="${1:-$WORKSPACE_DIR/武川县}"
OUTPUT_DIR="${2:-$WORKSPACE_DIR/武川县_分层镶嵌_连通块}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
KEEP_GROUP_TIFS="${KEEP_GROUP_TIFS:-1}"
RUN_DIAGNOSTICS="${RUN_DIAGNOSTICS:-1}"

FINAL_NAME="武川县_hierarchical_merge_FINAL.tif"
COLORFILL_NAME="武川县_hierarchical_merge_FINAL_colorfill.tif"

FINAL_PATH="$OUTPUT_DIR/$FINAL_NAME"
FINAL_PREVIEW="$OUTPUT_DIR/武川县_hierarchical_merge_FINAL_preview.jpg"
COLORFILL_PATH="$OUTPUT_DIR/$COLORFILL_NAME"
COLORFILL_PREVIEW="$OUTPUT_DIR/武川县_hierarchical_merge_FINAL_colorfill_preview.jpg"
COLORFILL_COMPARE="$OUTPUT_DIR/武川县_hierarchical_merge_FINAL_colorfill_compare.jpg"

echo "== Wuchuan mosaic + color-fill pipeline =="
echo "Input:  $INPUT_DIR"
echo "Output: $OUTPUT_DIR"
echo "Keep group TIFFs: $KEEP_GROUP_TIFS"
echo "Run diagnostics:  $RUN_DIAGNOSTICS"
echo

if [[ ! -d "$INPUT_DIR" ]]; then
  echo "Input directory not found: $INPUT_DIR" >&2
  exit 1
fi

run_diag() {
  local name="$1"
  local final="$2"
  local source_a="$3"
  local source_b="$4"
  local center_lonlat="$5"
  local out_dir="$OUTPUT_DIR/diagnostics_auto/$name"

  if [[ ! -f "$final" || ! -f "$source_a" || ! -f "$source_b" ]]; then
    echo "  - skip $name: missing final/source file"
    return
  fi

  if ! "$PYTHON_BIN" diagnose_mosaic_seams.py "$OUTPUT_DIR" \
    --final "$final" \
    --a "$source_a" \
    --b "$source_b" \
    --out-dir "$out_dir" \
    --center-lonlat "$center_lonlat" \
    --window-size 2800; then
    echo "  - warning: diagnostic failed for $name; continuing pipeline"
  fi
}

echo "[1/5] Building final mosaic..."
"$PYTHON_BIN" mosaic_tiffs_hierarchical.py "$INPUT_DIR" \
  --output-dir "$OUTPUT_DIR" \
  --output-name "$FINAL_NAME" \
  --group-register-mode none \
  --group-method feather \
  --group-seam-register \
  --final-method feather \
  --final-seam-register \
  --seam-register-max-shift 220 \
  --seam-register-band 3000 \
  --seam-register-max-size 2600 \
  --final-radiometric-match \
  --final-radiometric-strength 0.28 \
  --final-radiometric-max-offset 24 \
  --final-radiometric-gain-strength 0.10 \
  --seam-color-match-strength 0.55 \
  --seam-color-match-max-offset 32 \
  --seam-color-match-gain-strength 0.20 \
  --seam-color-match-min-pixels 1600 \
  --no-seam-color-match-new-side \
  --resampling bilinear \
  --tile-size 1024 \
  --compress lzw \
  --ignore-read-errors \
  --overwrite

echo
if [[ "$RUN_DIAGNOSTICS" == "1" ]]; then
  echo "[2/5] Running seam diagnostics..."
  run_diag "gf7_internal_sw" \
    "$OUTPUT_DIR/groups/GF7_part01.tif" \
    "$INPUT_DIR/GF7_DLC_E110.9_N41.0_20250928_L1A0002119045-truecolor-rgb-pan-rpc-ortho-wgs84-sharp-browse.tif" \
    "$INPUT_DIR/GF7_DLC_E111.0_N41.2_20250928_L1A0002119044-truecolor-rgb-pan-rpc-ortho-wgs84-sharp-browse.tif" \
    "110.945,41.084"
  run_diag "gf7_internal_mid" \
    "$OUTPUT_DIR/groups/GF7_part01.tif" \
    "$INPUT_DIR/GF7_DLC_E111.0_N41.2_20250928_L1A0002119044-truecolor-rgb-pan-rpc-ortho-wgs84-sharp-browse.tif" \
    "$INPUT_DIR/GF7_DLC_E111.0_N41.4_20250928_L1A0002119043-truecolor-rgb-pan-rpc-ortho-wgs84-sharp-browse.tif" \
    "111.005,41.281"
  run_diag "gf2_top_mid" \
    "$OUTPUT_DIR/groups/GF2_part01.tif" \
    "$INPUT_DIR/GF2_Wuchuan_TrueColor_20250427_E111.7_N41.3_v3.tif" \
    "$INPUT_DIR/GF2_Wuchuan_TrueColor_20250427_E112.0_N41.3_v3.tif" \
    "111.8665,41.2899"
  run_diag "gf2_right_mid" \
    "$OUTPUT_DIR/groups/GF2_part01.tif" \
    "$INPUT_DIR/GF2_Wuchuan_TrueColor_20250427_E112.0_N41.3_v3.tif" \
    "$INPUT_DIR/GF2_Wuchuan_TrueColor_20250620_E112.1_N41.1_v3.tif" \
    "112.030,41.210"
else
  echo "[2/5] Seam diagnostics skipped."
fi

echo
if [[ "$KEEP_GROUP_TIFS" == "1" ]]; then
  echo "[3/5] Keeping intermediate group TIFFs for review."
else
  echo "[3/5] Removing large intermediate group TIFFs..."
  rm -f "$OUTPUT_DIR/groups/GF7_part01.tif"
  rm -f "$OUTPUT_DIR/groups/GF2_part01.tif"
fi

echo
echo "[4/5] Running color balancing and small-hole filling..."
"$PYTHON_BIN" postprocess_mosaic_color_fill.py "$FINAL_PATH" \
  --preview-input "$FINAL_PREVIEW" \
  --output "$COLORFILL_PATH" \
  --preview-output "$COLORFILL_PREVIEW" \
  --comparison-output "$COLORFILL_COMPARE" \
  --strength 0.45 \
  --blur-sigma 90 \
  --max-offset 36 \
  --preview-hole-max-area 24000 \
  --preview-hole-max-span 260 \
  --hole-min-fill-ratio 0.65 \
  --compress lzw \
  --overwrite

echo
echo "[5/5] Done."
echo "Final GeoTIFF:     $COLORFILL_PATH"
echo "Preview JPG:       $COLORFILL_PREVIEW"
echo "Comparison JPG:    $COLORFILL_COMPARE"
echo "Original mosaic:   $FINAL_PATH"
if [[ "$RUN_DIAGNOSTICS" == "1" ]]; then
  echo "Diagnostics:       $OUTPUT_DIR/diagnostics_auto"
fi
