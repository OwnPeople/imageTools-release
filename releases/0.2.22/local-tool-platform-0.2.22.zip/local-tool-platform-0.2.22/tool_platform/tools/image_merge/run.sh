#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

candidate_pythons=()
if [[ -n "${PYTHON_BIN:-}" ]]; then
  candidate_pythons+=("$PYTHON_BIN")
else
  candidate_pythons+=(
    "$PLATFORM_DIR/.venv/bin/python"
    "/opt/anaconda3/bin/python3"
    "/opt/anaconda3/bin/python"
    "/Users/jun/miniconda3/bin/python"
    "python3"
  )
fi

selected_python=""
for candidate in "${candidate_pythons[@]}"; do
  if [[ -x "$candidate" ]]; then
    resolved="$candidate"
  else
    resolved="$(command -v "$candidate" 2>/dev/null || true)"
  fi
  if [[ -z "$resolved" ]]; then
    continue
  fi
  if "$resolved" - <<'PY' >/dev/null 2>&1
import cv2
import numpy
import rasterio
PY
  then
    selected_python="$resolved"
    break
  fi
done

if [[ -z "$selected_python" ]]; then
  cat >&2 <<'EOF'
No Python runtime with cv2, numpy, and rasterio was found.
Set PYTHON_BIN to the Python executable used for image merge processing, for example:
  PYTHON_BIN=/opt/anaconda3/bin/python3 <launch command>
EOF
  exit 1
fi

exec "$selected_python" "$SCRIPT_DIR/rebuild_truecolor.py" "$@"
