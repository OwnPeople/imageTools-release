from __future__ import annotations

import os
import platform
import subprocess
import webbrowser
from pathlib import Path
from typing import Optional


def normalize_initial_dir(initial_dir: Optional[str] = None) -> Path:
    if initial_dir:
        path = Path(initial_dir).expanduser()
        if path.is_file():
            path = path.parent
        if path.exists():
            return path.resolve()
    return Path.home().resolve()


def pick_directory_macos(initial_dir: Optional[str] = None) -> str:
    script = [
        "on run argv",
        "set initialPath to item 1 of argv",
        "try",
        'set chosenFolder to choose folder with prompt "请选择输入目录" default location (POSIX file initialPath)',
        "return POSIX path of chosenFolder",
        "on error number -128",
        'return ""',
        "end try",
        "end run",
    ]
    command = ["osascript"]
    for line in script:
        command.extend(["-e", line])
    command.append(str(normalize_initial_dir(initial_dir)))
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or "Folder picker failed").strip())
    return result.stdout.strip()


def pick_directory_windows(initial_dir: Optional[str] = None) -> str:
    script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = "请选择输入目录"
$dialog.ShowNewFolderButton = $false
if ($args.Count -gt 0 -and (Test-Path -LiteralPath $args[0])) {
  $dialog.SelectedPath = $args[0]
}
$result = $dialog.ShowDialog()
if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
  [Console]::Out.Write($dialog.SelectedPath)
}
"""
    result = subprocess.run(
        ["powershell", "-NoProfile", "-STA", "-Command", script, str(normalize_initial_dir(initial_dir))],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stderr or "Folder picker failed").strip())
    return result.stdout.strip()


def pick_directory_tk(initial_dir: Optional[str] = None) -> str:
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        return filedialog.askdirectory(initialdir=str(normalize_initial_dir(initial_dir)), mustexist=True)
    finally:
        root.destroy()


def pick_directory(initial_dir: Optional[str] = None) -> str:
    system = platform.system()
    if system == "Darwin":
        return pick_directory_macos(initial_dir)
    if system == "Windows":
        return pick_directory_windows(initial_dir)
    return pick_directory_tk(initial_dir)


def open_path(path: Path) -> None:
    system = platform.system()
    if system == "Darwin":
        command = ["open", str(path)] if path.is_dir() else ["open", "-R", str(path)]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or "Open path failed").strip())
        return
    if system == "Windows":
        try:
            os.startfile(str(path))  # type: ignore[attr-defined]
        except OSError as exc:
            raise RuntimeError(str(exc)) from exc
        return
    result = subprocess.run(["xdg-open", str(path)], capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "Open path failed").strip())


def open_external(target: str) -> None:
    if target.startswith("http://") or target.startswith("https://"):
        webbrowser.open(target)
        return
    open_path(Path(target).expanduser().resolve())
