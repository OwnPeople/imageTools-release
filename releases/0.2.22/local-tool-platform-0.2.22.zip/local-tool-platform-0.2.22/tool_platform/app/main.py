from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from .config import DB_PATH, LOG_DIR, PLATFORM_VERSION, STATIC_DIR, TEMPLATES_DIR, ensure_runtime_dirs, load_settings, save_settings
from .git_update_status import get_git_update_status
from .storage import TaskStore
from .system_ops import open_external, open_path, pick_directory
from .task_queue import TaskQueue
from .tool_registry import ToolRegistry
from .update_service import check_updates_from_settings


ensure_runtime_dirs()
store = TaskStore(DB_PATH)
registry = ToolRegistry()
task_queue = TaskQueue(store, registry)
task_queue.start()

app = FastAPI(title="Local Tool Platform", version="0.1.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


class CreateTaskRequest(BaseModel):
    tool_id: str
    input_path: str = Field(min_length=1)
    options: Dict[str, Any] = Field(default_factory=dict)


class BatchTaskRequest(BaseModel):
    tool_id: str
    input_paths: List[str]
    options: Dict[str, Any] = Field(default_factory=dict)


class ScanRequest(BaseModel):
    tool_id: str
    root_path: str = Field(min_length=1)


class OpenPathRequest(BaseModel):
    path: str = Field(min_length=1)


class SettingsRequest(BaseModel):
    settings: Dict[str, Any]


class OpenExternalRequest(BaseModel):
    target: str = Field(min_length=1)


class UpdateCheckRequest(BaseModel):
    manifest_url: str = ""


@app.on_event("shutdown")
def shutdown_task_queue() -> None:
    task_queue.shutdown()


@app.get("/", response_class=HTMLResponse)
def home(request: Request) -> HTMLResponse:
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/system")
def get_system() -> dict:
    settings = load_settings()
    return {
        "platform_name": "本地工具平台",
        "version": PLATFORM_VERSION,
        "tools_count": len(registry.list_tools()),
        "runtime_dir": str(LOG_DIR.parent),
        "settings": settings,
        "git_update": get_git_update_status(),
    }


@app.get("/api/tools")
def get_tools() -> List[Dict[str, Any]]:
    return [
        {
            "id": tool.tool_id,
            "name": tool.name,
            "description": tool.description,
            "input_hint": tool.input_hint,
            "output_dir_name": tool.output_dir_name,
            "options": tool.options,
        }
        for tool in registry.list_tools()
    ]


@app.post("/api/pick-folder")
def api_pick_folder(payload: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
    initial_dir = ""
    if payload:
        initial_dir = str(payload.get("initial_dir") or "")
    chosen = pick_directory(initial_dir)
    return {"path": chosen}


@app.post("/api/scan")
def scan_inputs(body: ScanRequest) -> dict:
    root = Path(body.root_path).expanduser().resolve()
    items = registry.scan_inputs(body.tool_id, root)
    return {
        "root_path": str(root),
        "count": len(items),
        "items": [str(item) for item in items],
    }


@app.get("/api/tasks")
def list_tasks() -> List[Dict[str, Any]]:
    return task_queue.list_tasks()


@app.post("/api/tasks")
def create_task(body: CreateTaskRequest) -> dict:
    input_path = Path(body.input_path).expanduser().resolve()
    try:
        registry.get(body.tool_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    is_valid, message = registry.validate_input(body.tool_id, input_path)
    if not is_valid:
        raise HTTPException(status_code=400, detail=message)
    return task_queue.submit(body.tool_id, input_path, body.options)


@app.post("/api/tasks/batch")
def create_batch_tasks(body: BatchTaskRequest) -> dict:
    created = []
    for item in body.input_paths:
        input_path = Path(item).expanduser().resolve()
        try:
            is_valid, _ = registry.validate_input(body.tool_id, input_path)
        except KeyError:
            is_valid = False
        if not is_valid:
            continue
        created.append(task_queue.submit(body.tool_id, input_path, body.options))
    return {"count": len(created), "tasks": created}


@app.delete("/api/tasks/finished")
def delete_finished_tasks() -> dict:
    return task_queue.delete_finished_tasks()


@app.get("/api/tasks/{task_id}")
def get_task(task_id: str) -> dict:
    task = store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.delete("/api/tasks/{task_id}")
def delete_finished_task(task_id: str) -> dict:
    try:
        return task_queue.delete_finished_task(task_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Task not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/tasks/{task_id}/cancel")
def cancel_task(task_id: str) -> dict:
    try:
        return task_queue.cancel(task_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Task not found") from exc


@app.get("/api/tasks/{task_id}/log", response_class=PlainTextResponse)
def get_task_log(task_id: str) -> str:
    task = store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    log_path = Path(task["log_path"])
    if not log_path.exists():
        return ""
    return log_path.read_text(encoding="utf-8", errors="replace")


@app.post("/api/open-path")
def api_open_path(body: OpenPathRequest) -> JSONResponse:
    path = Path(body.path).expanduser().resolve()
    if not path.exists():
        raise HTTPException(status_code=400, detail="Path does not exist")
    try:
        open_path(path)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=f"Open path failed: {exc}") from exc
    return JSONResponse({"ok": True, "path": str(path)})


@app.post("/api/open-external")
def api_open_external(body: OpenExternalRequest) -> JSONResponse:
    open_external(body.target)
    return JSONResponse({"ok": True})


@app.get("/api/settings")
def get_settings() -> dict:
    return load_settings()


@app.put("/api/settings")
def put_settings(body: SettingsRequest) -> dict:
    save_settings(body.settings)
    return {"ok": True, "settings": load_settings()}


@app.post("/api/updates/check")
def api_check_updates(body: Optional[UpdateCheckRequest] = None) -> Dict[str, Any]:
    if body and body.manifest_url.strip():
        settings = load_settings()
        settings.setdefault("server", {})
        settings["server"]["manifest_url"] = body.manifest_url.strip()
        save_settings(settings)
    return check_updates_from_settings()
