from __future__ import annotations

import os
import queue
import signal
import subprocess
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from .config import LOG_DIR
from .storage import TaskStore
from .tool_registry import ToolRegistry


ACTIVE_STATUSES = {"PENDING", "RUNNING", "CANCELING"}
FINISHED_STATUSES = {"SUCCESS", "FAILED", "CANCELED"}


def utc_now_text() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


@dataclass
class QueuedTask:
    task_id: str
    tool_id: str
    input_path: Path
    options: Dict[str, Any]


class TaskQueue:
    def __init__(self, store: TaskStore, registry: ToolRegistry) -> None:
        self.store = store
        self.registry = registry
        self._queue: queue.Queue[QueuedTask] = queue.Queue()
        self._thread = threading.Thread(target=self._run_forever, daemon=True, name="tool-platform-worker")
        self._process_lock = threading.Lock()
        self._active_processes: Dict[str, subprocess.Popen[str]] = {}
        self._cancel_requested: set[str] = set()
        self._started = False

    def start(self) -> None:
        if not self._started:
            self._mark_interrupted_tasks()
            self._thread.start()
            self._started = True

    def shutdown(self) -> None:
        with self._process_lock:
            active = list(self._active_processes.items())
            for task_id, _process in active:
                self._cancel_requested.add(task_id)
        for task_id, process in active:
            self._append_log(task_id, "\n平台关闭，任务已停止。\n")
            self._terminate_process_tree(process)
            self.store.update_task(
                task_id,
                status="CANCELED",
                finished_at=utc_now_text(),
                message="平台关闭，任务已停止",
            )

    def submit(self, tool_id: str, input_path: Path, options: Dict[str, Any]) -> Dict[str, Any]:
        task_id = uuid.uuid4().hex
        log_path = LOG_DIR / f"{task_id}.log"
        self.store.create_task(
            task_id=task_id,
            tool_id=tool_id,
            input_path=str(input_path),
            status="PENDING",
            created_at=utc_now_text(),
            log_path=str(log_path),
            options=options,
        )
        self._queue.put(QueuedTask(task_id=task_id, tool_id=tool_id, input_path=input_path, options=options))
        return self.store.get_task(task_id) or {"id": task_id}

    def cancel(self, task_id: str) -> Dict[str, Any]:
        task = self.store.get_task(task_id)
        if task is None:
            raise KeyError(task_id)

        status = task["status"]
        if status in FINISHED_STATUSES:
            return task

        with self._process_lock:
            self._cancel_requested.add(task_id)
            process = self._active_processes.get(task_id)

        self._append_log(task_id, "\n用户取消了任务。\n")
        if status == "PENDING":
            self.store.update_task(
                task_id,
                status="CANCELED",
                finished_at=utc_now_text(),
                message="任务已取消",
            )
            return self.store.get_task(task_id) or task

        if process is None:
            self._append_log(task_id, "任务进程已停止，取消完成。\n")
            self.store.update_task(
                task_id,
                status="CANCELED",
                finished_at=utc_now_text(),
                message="任务已取消",
            )
            return self.store.get_task(task_id) or task

        self.store.update_task(task_id, status="CANCELING", message="正在取消任务...")
        self._terminate_process_tree(process)
        return self.store.get_task(task_id) or task

    def list_tasks(self, limit: int = 100) -> list[Dict[str, Any]]:
        self._repair_stale_canceling_tasks()
        return self.store.list_tasks(limit=limit)

    def delete_finished_task(self, task_id: str) -> Dict[str, Any]:
        task = self.store.get_task(task_id)
        if task is None:
            raise KeyError(task_id)
        if task["status"] not in FINISHED_STATUSES:
            raise ValueError("任务还没有结束，不能删除记录")
        self._delete_task_record(task)
        return {"ok": True, "deleted": 1}

    def delete_finished_tasks(self) -> Dict[str, Any]:
        tasks = self.store.list_tasks_by_statuses(sorted(FINISHED_STATUSES))
        for task in tasks:
            self._delete_task_record(task)
        return {"ok": True, "deleted": len(tasks)}

    def _mark_interrupted_tasks(self) -> None:
        tasks = self.store.list_tasks_by_statuses(sorted(ACTIVE_STATUSES))
        for task in tasks:
            if task["status"] == "CANCELING":
                self._append_log(task["id"], "\n任务进程已停止，取消完成。\n")
                self.store.update_task(
                    task["id"],
                    status="CANCELED",
                    finished_at=utc_now_text(),
                    message="任务已取消",
                )
                continue
            self._append_log(task["id"], "\n平台上次关闭时任务未完成，请重新提交。\n")
            self.store.update_task(
                task["id"],
                status="FAILED",
                finished_at=utc_now_text(),
                message="平台上次关闭时任务未完成，请重新提交",
            )

    def _run_forever(self) -> None:
        while True:
            task = self._queue.get()
            try:
                self._execute(task)
            finally:
                self._queue.task_done()

    def _execute(self, task: QueuedTask) -> None:
        if self._is_cancel_requested(task.task_id):
            self._finish_canceled_task(task.task_id, "任务在开始前已取消。")
            return

        tool = self.registry.get(task.tool_id)
        output_dir = tool.resolve_output_dir(task.input_path)
        command = tool.build_command(task.input_path, task.options, output_path=output_dir)
        environment_overrides = tool.build_environment(task.options)
        task_data = self.store.get_task(task.task_id)
        if task_data is None:
            return
        log_path = Path(task_data["log_path"])
        log_path.parent.mkdir(parents=True, exist_ok=True)

        if task_data.get("status") == "CANCELED":
            self._finish_canceled_task(task.task_id, "任务在开始前已取消。")
            return

        self.store.update_task(task.task_id, status="RUNNING", started_at=utc_now_text(), message="任务开始处理")
        if self._is_cancel_requested(task.task_id):
            self._finish_canceled_task(task.task_id, "任务在开始前已取消。")
            return

        with log_path.open("w", encoding="utf-8") as log_fh:
            log_fh.write(f"工具：{tool.name}\n")
            log_fh.write(f"输入目录：{task.input_path}\n\n")
            if environment_overrides:
                log_fh.write("Environment:\n")
                for key in sorted(environment_overrides):
                    log_fh.write(f"{key}={environment_overrides[key]}\n")
                log_fh.write("\n")
            log_fh.flush()
            process_env = os.environ.copy()
            process_env.update(environment_overrides)
            popen_kwargs: Dict[str, Any] = {}
            if os.name == "nt":
                popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            else:
                popen_kwargs["start_new_session"] = True
            process = subprocess.Popen(
                command,
                cwd=str(task.input_path.parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                env=process_env,
                **popen_kwargs,
            )
            with self._process_lock:
                self._active_processes[task.task_id] = process
            try:
                if self._is_cancel_requested(task.task_id):
                    self._terminate_process_tree(process)
                assert process.stdout is not None
                for line in process.stdout:
                    log_fh.write(line)
                    log_fh.flush()
                code = process.wait()
            finally:
                with self._process_lock:
                    self._active_processes.pop(task.task_id, None)

        if self._is_cancel_requested(task.task_id):
            self._finish_canceled_task(task.task_id, "任务已取消。")
            return

        if code == 0:
            self.store.update_task(
                task.task_id,
                status="SUCCESS",
                finished_at=utc_now_text(),
                output_path=str(output_dir),
                message="任务已完成",
            )
            return

        self.store.update_task(
            task.task_id,
            status="FAILED",
            finished_at=utc_now_text(),
            output_path=str(output_dir),
            message=self._failure_message(code, log_path),
        )

    def _append_log(self, task_id: str, message: str) -> None:
        task = self.store.get_task(task_id)
        if task is None or not task.get("log_path"):
            return
        log_path = Path(task["log_path"])
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as log_fh:
            log_fh.write(message)

    def _delete_task_record(self, task: Dict[str, Any]) -> None:
        log_path_text = str(task.get("log_path") or "")
        if log_path_text:
            try:
                Path(log_path_text).unlink(missing_ok=True)
            except OSError:
                pass
        self.store.delete_task(task["id"])
        with self._process_lock:
            self._cancel_requested.discard(task["id"])

    def _finish_canceled_task(self, task_id: str, log_message: str) -> None:
        self._append_log(task_id, f"{log_message}\n")
        self.store.update_task(
            task_id,
            status="CANCELED",
            finished_at=utc_now_text(),
            message="任务已取消",
        )
        with self._process_lock:
            self._cancel_requested.discard(task_id)

    def _is_cancel_requested(self, task_id: str) -> bool:
        with self._process_lock:
            return task_id in self._cancel_requested

    def _repair_stale_canceling_tasks(self) -> None:
        tasks = self.store.list_tasks_by_statuses(["CANCELING"])
        if not tasks:
            return
        with self._process_lock:
            running_ids = set(self._active_processes)
        for task in tasks:
            if task["id"] in running_ids:
                continue
            self._append_log(task["id"], "任务进程已停止，取消完成。\n")
            self.store.update_task(
                task["id"],
                status="CANCELED",
                finished_at=utc_now_text(),
                message="任务已取消",
            )

    def _failure_message(self, code: int, log_path: Path) -> str:
        fallback = f"任务失败，退出码 {code}"
        try:
            text = log_path.read_text(encoding="utf-8", errors="replace")[-12000:]
        except OSError:
            return fallback
        if "No space left on device" in text:
            return "磁盘空间不足，写入失败，请清理空间后重试"
        if "Permission denied" in text:
            return "没有目录写入权限，请换一个有权限的位置后重试"
        return fallback

    def _terminate_process_tree(self, process: subprocess.Popen[str]) -> None:
        if process.poll() is not None:
            return

        if os.name == "nt":
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
                return
            except OSError:
                process.terminate()
                return

        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                return
