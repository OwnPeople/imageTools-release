#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"
PYTHON_BIN="${PYTHON:-python3}"
NEEDS_SETUP_FLAG="$SCRIPT_DIR/runtime/.needs_setup"
OPEN_BROWSER="${OPEN_BROWSER:-1}"
PLATFORM_URL="${PLATFORM_URL:-http://127.0.0.1:8765}"
PLATFORM_PORT="${PLATFORM_PORT:-8765}"

restore_script_permissions() {
  chmod +x \
    "$SCRIPT_DIR/bootstrap_setup.sh" \
    "$SCRIPT_DIR/setup_platform.sh" \
    "$SCRIPT_DIR/update_from_git.sh" \
    "$SCRIPT_DIR/run_platform.sh" \
    "$SCRIPT_DIR/tools/image_merge/run.sh" \
    "$SCRIPT_DIR/tools/tiff_mosaic_colorfill/run.sh" \
    "$SCRIPT_DIR/tools/tiff_mosaic_colorfill/legacy/run_wuchuan_colorfill_all.sh" \
    2>/dev/null || true
}

restore_script_permissions

open_platform_browser() {
  if command -v open >/dev/null 2>&1; then
    open "$PLATFORM_URL" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$PLATFORM_URL" >/dev/null 2>&1 || true
  fi
}

platform_is_running() {
  command -v curl >/dev/null 2>&1 && curl -fsS "$PLATFORM_URL/api/system" >/dev/null 2>&1
}

port_is_busy() {
  command -v lsof >/dev/null 2>&1 && lsof -nP -iTCP:"$PLATFORM_PORT" -sTCP:LISTEN >/dev/null 2>&1
}

if platform_is_running; then
  echo "本地工具平台已经在运行：$PLATFORM_URL"
  echo "正在打开网页..."
  open_platform_browser
  exit 0
fi

if [ -f "$SCRIPT_DIR/update_from_git.sh" ]; then
  bash "$SCRIPT_DIR/update_from_git.sh" || true
fi

if [ ! -x "$VENV_DIR/bin/python" ]; then
  echo "Virtualenv not found. Running bootstrap setup..."
  bash "$SCRIPT_DIR/bootstrap_setup.sh"
fi

if [ -f "$SCRIPT_DIR/update_from_http.py" ]; then
  "$VENV_DIR/bin/python" "$SCRIPT_DIR/update_from_http.py" || true
fi

if [ -f "$NEEDS_SETUP_FLAG" ]; then
  echo "Code was updated. Refreshing local environment..."
  restore_script_permissions
  bash "$SCRIPT_DIR/bootstrap_setup.sh"
  rm -f "$NEEDS_SETUP_FLAG"
fi

if platform_is_running; then
  echo "本地工具平台已经在运行：$PLATFORM_URL"
  echo "正在打开网页..."
  open_platform_browser
  exit 0
fi

if port_is_busy; then
  echo "端口 $PLATFORM_PORT 已被其他程序占用，无法启动本地工具平台。"
  echo "请关闭占用端口的程序后再启动。"
  exit 1
fi

if [ "$OPEN_BROWSER" = "1" ]; then
  (
    sleep 2
    open_platform_browser
  ) &
fi

exec "$VENV_DIR/bin/python" -m uvicorn app.main:app --app-dir "$SCRIPT_DIR" --host 127.0.0.1 --port "$PLATFORM_PORT"
