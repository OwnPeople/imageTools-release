#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parent
APP_ROOT = BASE_DIR.parent
RUNTIME_DIR = BASE_DIR / "runtime"
DOWNLOAD_DIR = RUNTIME_DIR / "downloads"
LOG_PATH = RUNTIME_DIR / "update_http.log"
NEEDS_SETUP_FLAG = RUNTIME_DIR / ".needs_setup"
MANIFEST_URL_PATH = RUNTIME_DIR / "update_url.txt"
CONFIG_PATH = BASE_DIR / "app" / "config.py"
DEFAULT_MANIFEST_URL = "https://ownpeople.github.io/imageTools-release/manifest.json"
EXECUTABLE_RELATIVE_PATHS = (
    "make_macos_app.sh",
    "make_release.sh",
    "package_tool_platform.sh",
    "tool_platform/bootstrap_setup.sh",
    "tool_platform/setup_platform.sh",
    "tool_platform/run_platform.sh",
    "tool_platform/update_from_git.sh",
    "tool_platform/tools/image_merge/run.sh",
    "tool_platform/tools/tiff_mosaic_colorfill/run.sh",
    "tool_platform/tools/tiff_mosaic_colorfill/legacy/run_wuchuan_colorfill_all.sh",
)
STALE_RELATIVE_PATHS = (
    "run_gf7_clean.sh",
    "run_mosaic_all.sh",
    "run_wuchuan_colorfill_all.sh",
    "rebuild_gf7_truecolor_clean.py",
    "mosaic_gf2_batch.py",
    "mosaic_gf2_geotiffs.py",
    "mosaic_tiffs_hierarchical.py",
    "postprocess_mosaic_color_fill.py",
    "diagnose_mosaic_seams.py",
    "verify_processing_env.py",
    "tool_platform/tools/gf7_sharp_browse",
)


def log(message: str) -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    line = f"{datetime.utcnow().replace(microsecond=0).isoformat()}Z {message}"
    with LOG_PATH.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")
    print(message)


def parse_version(version: str) -> list[int]:
    parts = [int(item) for item in re.findall(r"\d+", version or "")]
    return parts or [0]


def compare_versions(left: str, right: str) -> int:
    left_parts = parse_version(left)
    right_parts = parse_version(right)
    size = max(len(left_parts), len(right_parts))
    left_parts.extend([0] * (size - len(left_parts)))
    right_parts.extend([0] * (size - len(right_parts)))
    return (left_parts > right_parts) - (left_parts < right_parts)


def current_version() -> str:
    text = CONFIG_PATH.read_text(encoding="utf-8")
    match = re.search(r'^PLATFORM_VERSION = "([^"]+)"', text, flags=re.MULTILINE)
    return match.group(1) if match else "0.0.0"


def resolve_manifest_url() -> str:
    value = os.environ.get("TOOL_PLATFORM_MANIFEST_URL", "").strip()
    if value:
        MANIFEST_URL_PATH.write_text(value + "\n", encoding="utf-8")
        return value
    if MANIFEST_URL_PATH.exists():
        return MANIFEST_URL_PATH.read_text(encoding="utf-8").strip()
    return DEFAULT_MANIFEST_URL


def fetch_json(url: str) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=20) as response:
        payload = response.read().decode(response.headers.get_content_charset() or "utf-8")
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("manifest must be a JSON object")
    return data


def download_file(url: str, target: Path) -> None:
    request = urllib.request.Request(url)
    with urllib.request.urlopen(request, timeout=120) as response, target.open("wb") as fh:
        shutil.copyfileobj(response, fh)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def unpack_root(zip_path: Path, work_dir: Path) -> Path:
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(work_dir)
    items = [item for item in work_dir.iterdir() if item.name != "__MACOSX"]
    if len(items) == 1 and items[0].is_dir():
        return items[0]
    return work_dir


def copy_update(source_root: Path) -> None:
    ignore_names = {".git", ".venv", "runtime", "__pycache__"}
    for item in source_root.iterdir():
        if item.name in ignore_names or item.name == ".DS_Store":
            continue
        target = APP_ROOT / item.name
        if item.is_dir():
            shutil.copytree(
                item,
                target,
                dirs_exist_ok=True,
                ignore=shutil.ignore_patterns(".git", ".venv", "runtime", "__pycache__", "*.pyc", ".DS_Store"),
            )
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def restore_executable_permissions() -> None:
    if os.name == "nt":
        return
    for relative_path in EXECUTABLE_RELATIVE_PATHS:
        path = APP_ROOT / relative_path
        if path.exists():
            path.chmod(path.stat().st_mode | 0o111)


def remove_stale_paths() -> None:
    for relative_path in STALE_RELATIVE_PATHS:
        path = APP_ROOT / relative_path
        if not path.exists():
            continue
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            try:
                path.unlink()
            except OSError:
                pass


def main() -> int:
    manifest_url = resolve_manifest_url()
    if not manifest_url:
        log("HTTP auto-update disabled: no TOOL_PLATFORM_MANIFEST_URL.")
        return 0
    if (APP_ROOT / ".git").exists() and os.environ.get("TOOL_PLATFORM_ALLOW_HTTP_UPDATE_IN_GIT") != "1":
        log("HTTP auto-update skipped in git checkout.")
        return 0

    try:
        manifest = fetch_json(manifest_url)
        latest_version = str(manifest.get("version") or "").strip()
        download_url = str(manifest.get("download_url") or "").strip()
        expected_sha256 = str(manifest.get("sha256") or "").strip().lower()
        installed_version = current_version()

        if not latest_version or not download_url:
            raise ValueError("manifest must include version and download_url")
        if compare_versions(installed_version, latest_version) >= 0:
            log(f"Already up to date: {installed_version}")
            return 0

        DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        zip_path = DOWNLOAD_DIR / f"local-tool-platform-{latest_version}.zip"
        log(f"Downloading update: {installed_version} -> {latest_version}")
        download_file(download_url, zip_path)
        if expected_sha256:
            actual_sha256 = sha256_file(zip_path)
            if actual_sha256 != expected_sha256:
                raise ValueError("download sha256 does not match manifest")

        with tempfile.TemporaryDirectory(prefix="tool-platform-update-") as temp_name:
            source_root = unpack_root(zip_path, Path(temp_name))
            copy_update(source_root)
            remove_stale_paths()
            restore_executable_permissions()

        NEEDS_SETUP_FLAG.touch()
        log(f"HTTP update applied: {latest_version}")
        return 0
    except Exception as exc:
        log(f"HTTP update failed; continue with current code. {exc}")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
